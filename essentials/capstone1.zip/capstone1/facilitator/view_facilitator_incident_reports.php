<?php
session_start();
include '../db.php';

// Ensure the user is logged in and is a facilitator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'facilitator') {
    header("Location: ../login.php");
    exit();
}

$facilitator_id = $_SESSION['user_id'];

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 10;
$offset = ($page - 1) * $records_per_page;

// Handle date filter
$date_filter = $_GET['date_filter'] ?? 'all';
$date_condition = '';
switch ($date_filter) {
    case 'today':
        $date_condition = "AND DATE(ir.date_reported) = CURDATE()";
        break;
    case 'last_week':
        $date_condition = "AND ir.date_reported >= DATE_SUB(CURDATE(), INTERVAL 1 WEEK)";
        break;
    case 'last_month':
        $date_condition = "AND ir.date_reported >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)";
        break;
    default:
        $date_condition = "";
}

// Handle course filter
$course_filter = $_GET['course_filter'] ?? 'all';
$course_condition = '';
if ($course_filter !== 'all') {
    $course_condition = "AND c.id = '$course_filter'";
}

// Handle reporter filter
$reporter_filter = $_GET['reporter_filter'] ?? 'all';
$reporter_condition = '';
if ($reporter_filter !== 'all') {
    $reporter_condition = "AND ir.reported_by_type = '$reporter_filter'";
}

// Handle search
$search = $_GET['search'] ?? '';
$search_condition = '';
if (!empty($search)) {
    $search_condition = "AND (s.first_name LIKE ? OR s.last_name LIKE ? OR ir.description LIKE ?)";
}

// Fetch all courses for the filter dropdown
$courses_query = "SELECT id, name FROM courses ORDER BY name";
$courses_result = $connection->query($courses_query);
$courses = $courses_result->fetch_all(MYSQLI_ASSOC);

// Count total records for pagination - Only pending reports
$count_query = "SELECT COUNT(*) as total FROM incident_reports ir
                LEFT JOIN student_violations sv ON ir.id = sv.incident_report_id
                LEFT JOIN tbl_student s ON sv.student_id = s.student_id
                LEFT JOIN sections sec ON s.section_id = sec.id
                LEFT JOIN courses c ON sec.course_id = c.id
                WHERE ir.status = 'pending' $date_condition $course_condition $reporter_condition $search_condition";

$count_stmt = $connection->prepare($count_query);
if (!empty($search)) {
    $search_param = "%$search%";
    $count_stmt->bind_param("sss", $search_param, $search_param, $search_param);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_records = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_records / $records_per_page);

// Fetch incident reports with pagination and all filters - Only pending reports
$query = "SELECT ir.*, 
            GROUP_CONCAT(DISTINCT CONCAT(s.first_name, ' ', s.last_name)) AS student_names,
            GROUP_CONCAT(DISTINCT CONCAT(c.name, ' - ', sec.year_level, ' - Section ', sec.section_no)) AS course_info,
            ir.reported_by,
            ir.reported_by_type
          FROM incident_reports ir
          LEFT JOIN student_violations sv ON ir.id = sv.incident_report_id
          LEFT JOIN tbl_student s ON sv.student_id = s.student_id
          LEFT JOIN sections sec ON s.section_id = sec.id
          LEFT JOIN courses c ON sec.course_id = c.id
          WHERE ir.status = 'pending' $date_condition $course_condition $reporter_condition $search_condition
          GROUP BY ir.id
          ORDER BY ir.date_reported DESC
          LIMIT ? OFFSET ?";

$stmt = $connection->prepare($query);
if (!empty($search)) {
    $search_param = "%$search%";
    $stmt->bind_param("sssii", $search_param, $search_param, $search_param, $records_per_page, $offset);
} else {
    $stmt->bind_param("ii", $records_per_page, $offset);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Incident Reports - Facilitator View</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   <style>
        body {
            background: linear-gradient(135deg, #0d693e, #004d4d);
            min-height: 100vh;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            margin: 0;
            color: #333;
        }
        .container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            margin-top: 50px;
            margin-bottom: 50px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #0d693e;
            border-bottom: 2px solid #0d693e;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .btn-primary {
            background-color: #0d693e;
            border-color: #0d693e;
        }
        .btn-primary:hover {
            background-color: #094e2e;
            border-color: #094e2e;
        }
        .btn-secondary {
            background-color: #F4A261;
            border-color: #F4A261;
            color: #fff;
            padding: 10px 20px;
        }
        .btn-secondary:hover {
            background-color: #E76F51;
            border-color: #E76F51;
        }
        .pagination {
            justify-content: center;
            margin-top: 20px;
        }
        .page-item.active .page-link {
            background-color: #0d693e;
            border-color: #0d693e;
        }
        .page-link {
            color: #0d693e;
        }
        .page-link:hover {
            color: #094e2e;
        }
        .filter-container {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <a href="guidanceservice.html" class="btn btn-secondary mb-4">
            <i class="fas fa-arrow-left"></i> Back to Guidance Services
        </a>
        <h2>Pending Incident Reports</h2>

        <div class="filter-container">
            <form action="" method="GET" class="form-inline mb-3">
                <label for="date_filter" class="mr-2">Date:</label>
                <select name="date_filter" id="date_filter" class="form-control mr-2">
                    <option value="all" <?php echo $date_filter === 'all' ? 'selected' : ''; ?>>All Dates</option>
                    <option value="today" <?php echo $date_filter === 'today' ? 'selected' : ''; ?>>Today</option>
                    <option value="last_week" <?php echo $date_filter === 'last_week' ? 'selected' : ''; ?>>Last Week</option>
                    <option value="last_month" <?php echo $date_filter === 'last_month' ? 'selected' : ''; ?>>Last Month</option>
                </select>

                <label for="course_filter" class="mr-2">Course:</label>
                <select name="course_filter" id="course_filter" class="form-control mr-2">
                    <option value="all">All Courses</option>
                    <?php foreach ($courses as $course): ?>
                        <option value="<?php echo $course['id']; ?>" <?php echo $course_filter == $course['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($course['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="reporter_filter" class="mr-2">Reported By:</label>
                <select name="reporter_filter" id="reporter_filter" class="form-control mr-2">
                    <option value="all" <?php echo $reporter_filter === 'all' ? 'selected' : ''; ?>>All Reporters</option>
                    <option value="facilitator" <?php echo $reporter_filter === 'facilitator' ? 'selected' : ''; ?>>Facilitator</option>
                    <option value="adviser" <?php echo $reporter_filter === 'adviser' ? 'selected' : ''; ?>>Adviser</option>
                    <option value="instructor" <?php echo $reporter_filter === 'instructor' ? 'selected' : ''; ?>>Instructor</option>
                    <option value="student" <?php echo $reporter_filter === 'student' ? 'selected' : ''; ?>>Student</option>
                    <option value="guard" <?php echo $reporter_filter === 'guard' ? 'selected' : ''; ?>>Guard</option>    
                </select>

                <input type="text" name="search" class="form-control mr-2" placeholder="Search..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="btn btn-primary">Apply Filters</button>
            </form>
        </div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Date Reported</th>
                    <th>Students Involved</th>
                    <th>Course - Year - Section</th>
                    <th>Description</th>
                    <th>Reported By</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['date_reported']); ?></td>
                        <td><?php echo htmlspecialchars($row['student_names']); ?></td>
                        <td><?php echo htmlspecialchars($row['course_info']); ?></td>
                        <td><?php echo htmlspecialchars(substr($row['description'], 0, 50)) . '...'; ?></td>
                        <td>
                            <?php 
                            echo htmlspecialchars($row['reported_by']) . 
                                 ' (' . ucfirst(htmlspecialchars($row['reported_by_type'])) . ')'; 
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                        <td>
                            <a href="view_report_details.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">View Details</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <nav aria-label="Page navigation">
            <ul class="pagination">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=1&date_filter=<?php echo $date_filter; ?>&status_filter=<?php echo $status_filter; ?>&course_filter=<?php echo $course_filter; ?>&reporter_filter=<?php echo $reporter_filter; ?>&search=<?php echo urlencode($search); ?>" aria-label="First">
                            <span aria-hidden="true">&laquo;&laquo;</span>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>&date_filter=<?php echo $date_filter; ?>&status_filter=<?php echo $status_filter; ?>&course_filter=<?php echo $course_filter; ?>&reporter_filter=<?php echo $reporter_filter; ?>&search=<?php echo urlencode($search); ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php
                $start_page = max(1, $page - 2);
                $end_page = min($total_pages, $page + 2);

                for ($i = $start_page; $i <= $end_page; $i++):
                ?>
                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&date_filter=<?php echo $date_filter; ?>&status_filter=<?php echo $status_filter; ?>&course_filter=<?php echo $course_filter; ?>&reporter_filter=<?php echo $reporter_filter; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>&date_filter=<?php echo $date_filter; ?>&status_filter=<?php echo $status_filter; ?>&course_filter=<?php echo $course_filter; ?>&reporter_filter=<?php echo $reporter_filter; ?>&search=<?php echo urlencode($search); ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $total_pages; ?>&date_filter=<?php echo $date_filter; ?>&status_filter=<?php echo $status_filter; ?>&course_filter=<?php echo $course_filter; ?>&reporter_filter=<?php echo $reporter_filter; ?>&search=<?php echo urlencode($search); ?>" aria-label="Last">
                            <span aria-hidden="true">&raquo;&raquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>

    <script>
    $(document).ready(function() {
        // Auto-submit form when filters change
        $('#date_filter, #course_filter, #reporter_filter').change(function() {
            $(this).closest('form').submit();
        });
    });
    </script>
</body>
</html>