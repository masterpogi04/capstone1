<?php
session_start();
include '../db.php';

// Check if the user is logged in as a facilitator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'facilitator') {
    header("Location: login.php");
    exit();
}

// Fetch distinct referral reasons
$stmt = $connection->query("SELECT DISTINCT reason_for_referral FROM referrals");
$referralReasons = [];
while($row = $stmt->fetch_assoc()) {
    $referralReasons[] = $row['reason_for_referral'];
}

$filterReason = isset($_GET['filter_reason']) ? $_GET['filter_reason'] : '';
$sortOrder = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'DESC';

// Prepare base query
$sql = "";
$params = [];
$types = "";

if ($filterReason) {
    $sql = "SELECT r1.* FROM (
            SELECT incident_report_id, MIN(date) as date, 
                   GROUP_CONCAT(CONCAT(first_name, ' ', IFNULL(middle_name,''), ' ', last_name) SEPARATOR ', ') as names,
                   MIN(reason_for_referral) as reason_for_referral,
                   GROUP_CONCAT(violation_details SEPARATOR '; ') as violation_details,
                   GROUP_CONCAT(other_concerns SEPARATOR '; ') as other_concerns,
                   NULL as id
            FROM referrals 
            WHERE incident_report_id IS NOT NULL AND reason_for_referral = ?
            GROUP BY incident_report_id
            UNION ALL
            SELECT NULL as incident_report_id, date, 
                   CONCAT(first_name, ' ', IFNULL(middle_name,''), ' ', last_name) as names,
                   reason_for_referral, violation_details, other_concerns, id
            FROM referrals 
            WHERE incident_report_id IS NULL AND reason_for_referral = ?
        ) r1 ORDER BY date " . $sortOrder;
    
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("ss", $filterReason, $filterReason);
} else {
    $sql = "SELECT r1.* FROM (
            SELECT incident_report_id, MIN(date) as date, 
                   GROUP_CONCAT(CONCAT(first_name, ' ', IFNULL(middle_name,''), ' ', last_name) SEPARATOR ', ') as names,
                   MIN(reason_for_referral) as reason_for_referral,
                   GROUP_CONCAT(violation_details SEPARATOR '; ') as violation_details,
                   GROUP_CONCAT(other_concerns SEPARATOR '; ') as other_concerns,
                   NULL as id
            FROM referrals 
            WHERE incident_report_id IS NOT NULL
            GROUP BY incident_report_id
            UNION ALL
            SELECT NULL as incident_report_id, date, 
                   CONCAT(first_name, ' ', IFNULL(middle_name,''), ' ', last_name) as names,
                   reason_for_referral, violation_details, other_concerns, id
            FROM referrals 
            WHERE incident_report_id IS NULL
        ) r1 ORDER BY date " . $sortOrder;
    
    $stmt = $connection->prepare($sql);
}

$stmt->execute();
$result = $stmt->get_result();
$referrals = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Student Referrals</title>
   <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
   <style>
    body {
        background: linear-gradient(to right, #0d693e, #004d4d);
        min-height: 100vh;
        padding-top: 20px;
    }
    .header {
        background-color: #ff9f1c;
        padding: 10px;
        text-align: center;
        font-size: 24px;
        font-weight: bold;
        color: white;
        margin-bottom: 20px;
    }
    .table-container {
        background-color: #ffffff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .btn-view {
        background-color: #007bff;
        border: none;
        border-radius: 20px;
        padding: 5px 10px;
        font-weight: bold;
        color: white;
    }
    .filter-form {
        background-color: #f8f9fa;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
    }
    </style>
</head>
<body>
   <div class="container">
       <div class="header">STUDENT REFERRALS</div>
       <a href="guidanceservice.html" class="btn btn-secondary mb-3">Back</a>
       
       <div class="filter-form">
           <form method="GET" class="form-inline">
               <div class="form-group mr-2">
                   <label for="filter_reason" class="mr-2">Filter by Reason:</label>
                   <select name="filter_reason" id="filter_reason" class="form-control">
                       <option value="">All Reasons</option>
                       <?php foreach ($referralReasons as $reason): ?>
                           <option value="<?= htmlspecialchars($reason) ?>" <?= $filterReason === $reason ? 'selected' : '' ?>>
                               <?= htmlspecialchars($reason) ?>
                           </option>
                       <?php endforeach; ?>
                   </select>
               </div>
               <div class="form-group mr-2">
                   <label for="sort_order" class="mr-2">Sort Order:</label>
                   <select name="sort_order" id="sort_order" class="form-control">
                       <option value="DESC" <?= $sortOrder === 'DESC' ? 'selected' : '' ?>>Newest to Oldest</option>
                       <option value="ASC" <?= $sortOrder === 'ASC' ? 'selected' : '' ?>>Oldest to Newest</option>
                   </select>
               </div>
               <button type="submit" class="btn btn-primary">Apply Filters</button>
           </form>
       </div>

       <div class="table-container">
           <table class="table table-striped">
               <thead>
                   <tr>
                       <th>Date</th>
                       <th>Student Name(s)</th>
                       <th>Reason for Referral</th>
                       <th>Action</th>
                   </tr>
               </thead>
               <tbody>
                   <?php foreach ($referrals as $referral): ?>
                   <tr>
                       <td><?= htmlspecialchars($referral['date']) ?></td>
                       <td>
                           <?php if (isset($referral['names'])): ?>
                               <?= htmlspecialchars($referral['names']) ?>
                           <?php else: ?>
                               <?= htmlspecialchars($referral['first_name'] . ' ' . 
                                   ($referral['middle_name'] ? $referral['middle_name'] . ' ' : '') . 
                                   $referral['last_name']) ?>
                           <?php endif; ?>
                       </td>
                       <td>
                           <?= htmlspecialchars($referral['reason_for_referral']) ?>
                           <?php if (!empty($referral['violation_details'])): ?>
                               <br>
                               <strong>Specific Violation:</strong> <?= htmlspecialchars($referral['violation_details']) ?>
                           <?php endif; ?>
                           <?php if (!empty($referral['other_concerns'])): ?>
                               <br>
                               <strong>Specific Concerns:</strong> <?= htmlspecialchars($referral['other_concerns']) ?>
                           <?php endif; ?>
                       </td>
                      
                        <td>
                            <?php if (isset($referral['incident_report_id'])): ?>
                                <a href="generate_referral_pdf.php?id=<?= $referral['incident_report_id'] ?>" 
                                   class="btn btn-primary" target="_blank">
                                    <i class="fas fa-file-pdf"></i> Generate PDF
                                </a>
                            <?php else: ?>
                                <a href="generate_referral_pdf.php?id=<?= $referral['id'] ?>" 
                                   class="btn btn-primary" target="_blank">
                                    <i class="fas fa-file-pdf"></i> Generate PDF
                                </a>
                            <?php endif; ?>
                        </td>
                   </tr>
                   <?php endforeach; ?>
               </tbody>
           </table>
       </div>
   </div>
   <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>