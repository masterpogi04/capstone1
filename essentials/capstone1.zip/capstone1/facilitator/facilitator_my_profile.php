<?php
session_start();
include '../db.php';

// Ensure the user is logged in and is a facilitator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'facilitator') {
    header("Location: ../login.php");
    exit();
}

$facilitator_id = $_SESSION['user_id'];

// Fetch current facilitator details
$stmt = $connection->prepare("SELECT username, email, name, profile_picture FROM tbl_facilitator WHERE id = ?");
$stmt->bind_param("i", $facilitator_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $facilitator = $result->fetch_assoc();
    $username = $facilitator['username'];
    $email = $facilitator['email'];
    $name = $facilitator['name'];
    $profile_picture = $facilitator['profile_picture'];
} else {
    die("facilitator not found.");
}
$stmt->close();

$update_successful = false;
$error_message = [];

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_username = trim($_POST['username']);
    $new_email = trim($_POST['email']);
    $new_name = trim($_POST['name']);
    $new_password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    // Update profile
    $update_stmt = $connection->prepare("UPDATE tbl_facilitator SET username = ?, email = ?, name = ?, updated_at = NOW() WHERE id = ?");
    $update_stmt->bind_param("sssi", $new_username, $new_email, $new_name, $facilitator_id);
    if ($update_stmt->execute()) {
        $username = $new_username;
        $email = $new_email;
        $name = $new_name;
        $update_successful = true;
    }
    $update_stmt->close();
    
             // Update password
            if (!empty($new_password)) {
                if ($new_password === $confirm_password) {
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_stmt = $connection->prepare("UPDATE tbl_facilitator SET password = ?, updated_at = NOW() WHERE id = ?");
                    $update_stmt->bind_param("si", $hashed_password, $facilitator_id);
                    if ($update_stmt->execute()) {
                        $update_successful = true;
                    }
                    $update_stmt->close();
                } else {
                    $error_message[] = "Passwords do not match.";
                }
            }
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>facilitator Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #FAF3E0;
            font-family: Arial, sans-serif;
            display: flex;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }
        .sidebar {
    background-color: #00563B;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    width: 255px;
    padding: 20px 0;
    box-shadow: 2px 0 5px rgba(0,0,0,0.1);
    overflow-y: auto;
    z-index: 1000;
}

.sidebar a {
    list-style-type: none;
    padding: 0;
    margin: 20px 0;
}

.sidebar a {
    display: block;
    padding: 12px 20px;
    color: #ecf0f1;
    text-decoration: none;
    transition: background-color 0.3s ease;
    border-left: 4px solid transparent;
}

.sidebar a:hover, .sidebar a.active {
            background-color: #2c3e50;
            border-left-color: #3498db;
        }

  .profile-section {
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
}

.avatar {
  width: 80px;
  height: 80px;
  background-color: #4A90E2;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  font-weight: bold;
  color: white;
  text-transform: uppercase;
  user-select: none;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.profile-section p {
    margin-top: 15px;
    font-size: 18px;
    color: #ecf0f1;
    font-weight: 500;
}
        .main-content {
            flex: 1;
            margin-left: 250px;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }


        .header {
    background-color: #ff9042;
    width: calc(100% - 250px); /* Full width minus sidebar width */
    padding: 10px;
    color: black;
    font-family: 'Georgia', serif;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: fixed;
    top: 0;
    left: 255px;
    z-index: 1000;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}   

        .header h1{
    margin: 0;
    font-size: 2rem;
    font-weight: 400;
}
        .content-wrapper {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }
        .footer {
        background-color: #ff9042;
        color: #ecf0f1;
        text-align: center;
        padding: 15px;
        position: fixed;
        bottom: 0;
        left: 255px;
        right: 0;
        height: 50px;
        z-index: 1000;
}
        .btn-primary {
            background-color: #1A6E47;
            border-color: #1A6E47;
        }
        .btn-primary:hover {
            background-color: #145A3A;
            border-color: #145A3A;
        }
        .form-container {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .profile-section img {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 3px solid #ecf0f1;
    object-fit: cover;
    backface-visibility: hidden;  /* Prevents flickering */
    transform: translateZ(0);     /* Forces GPU acceleration */
    -webkit-transform: translateZ(0);
    will-change: transform;       /* Optimizes for animations */
}
    </style>
</head>
<body>
    <nav class="sidebar">
    <div class="profile-section text-center">
  <div class="avatar">
    <?php 
      // Get first letter of first and last name
      $nameParts = explode(' ', $name);
      $initials = '';
      if (!empty($nameParts[0])) {
        $initials .= substr($nameParts[0], 0, 1);
      }
      if (!empty($nameParts[1])) {
        $initials .= substr($nameParts[1], 0, 1);
      }
      echo htmlspecialchars(strtoupper($initials));
    ?>
  </div>
  <p><?php echo htmlspecialchars($name); ?></p>
</div>
    <a href="facilitator_homepage.php">Home</a>
    <a href="facilitator_dashboard.php">Dashboard</a>
    <a href="facilitator_my_profile.php" class="active">My Profile</a>
    <a href="help_support_facilitator.php" >Help & Support</a>
    <a href="../login.php" onclick="return confirm('Are you sure you want to log out?')">Log Out</a>
  </nav>

    <div class="main-content">
        <header class="header">
            <h1>CEIT - GUIDANCE OFFICE</h1>
        </header>

        <div class="content-wrapper">
            <h2 class="mb-4">Update Profile</h2>

            <div class="form-container">
                <form id="updateProfileForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
                    </div>
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>">
                    </div>
                    <div class="form-group">
                        <label for="password">New Password:</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="password" name="password">
                            <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                    <i class="fa fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password:</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                            <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="button" id="toggleConfirmPassword">
                                    <i class="fa fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Profile</button>
                </form>
            </div>
        </div>

        <footer class="footer">
            <p>&copy; 2024 All Rights Reserved</p>
        </footer>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($update_successful): ?>
            Swal.fire({
                title: 'Success!',
                text: 'Your profile has been updated successfully.',
                icon: 'success',
                confirmButtonText: 'OK'
            });
            <?php endif; ?>

            <?php if (!empty($error_message)): ?>
            Swal.fire({
                title: 'Error!',
                text: '<?php echo implode(" ", $error_message); ?>',
                icon: 'error',
                confirmButtonText: 'OK'
            });
            <?php endif; ?>

            function togglePasswordVisibility(inputId, toggleId) {
                const input = document.getElementById(inputId);
                const toggle = document.getElementById(toggleId);
                
                toggle.addEventListener('click', function (e) {
                    e.preventDefault();
                    const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
                    input.setAttribute('type', type);
                    this.querySelector('i').classList.toggle('fa-eye');
                    this.querySelector('i').classList.toggle('fa-eye-slash');
                });
            }

            togglePasswordVisibility('password', 'togglePassword');
            togglePasswordVisibility('confirm_password', 'toggleConfirmPassword');

            var form = document.getElementById('updateProfileForm');
            var originalFormData = new FormData(form);

            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                var currentFormData = new FormData(form);
                var hasChanges = false;

                for (var pair of currentFormData.entries()) {
                    if (pair[1] !== originalFormData.get(pair[0])) {
                        hasChanges = true;
                        break;
                    }
                }

                if (!hasChanges) {
                    Swal.fire({
                        title: 'No Changes',
                        text: 'No changes were made to your profile.',
                        icon: 'info',
                        confirmButtonText: 'OK'
                    });
                    return;
                }

                var password = document.getElementById('password').value;
                var confirmPassword = document.getElementById('confirm_password').value;

                if (password !== confirmPassword) {
                    Swal.fire({
                        title: 'Error!',
                        text: 'Passwords do not match.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                    return;
                }

                Swal.fire({
                    title: 'Confirm Update',
                    text: 'Are you sure you want to update your profile?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, update it!',
                    cancelButtonText: 'No, cancel!',
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    </script>
</body>
</html>