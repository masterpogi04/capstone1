<?php
// Ensure the user is logged in and is a facilitator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'facilitator') {
    header("Location: ../login.php");
    exit();
}
?>

<div class="sidebar">
    <div class="profile-section text-center">
        <!-- Display profile picture and name -->
        <img src="<?php echo htmlspecialchars($profile_picture); ?>" class="rounded-circle" alt="Profile Picture" style="width: 100px; height: 100px; object-fit: cover;">
        <p><?php echo htmlspecialchars($name); ?></p>
    </div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link" href="facilitator_dashboard.php">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="manage_events.php">Manage Events</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="track_participants.php">Track Participants</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="view_feedback.php">View Feedback</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="my_profile.php">My Profile</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="help_support.php">Help & Support</a>
        </li>
       <li class="nav-item">
            <a class="nav-link" href="../login.php" onclick="return confirm('Are you sure you want to log out?')">Log Out</a>
        </li>
    </ul>
</div>

<style>
/* Add your sidebar styles here */
.sidebar {
    width: 250px;
    background-color: #f8f9fa;
    height: 100vh;
    padding: 15px;
    position: fixed;
}

.profile-section {
    margin-bottom: 20px;
}

.nav-link {
    color: #333;
    font-weight: 500;
}

.nav-link:hover {
    color: #007bff;
}
</style>

<script>
function confirmLogout() {
    return confirm('Are you sure you want to log out?');
}
</script>