<?php
session_start();
include '../db.php';

// Check if user is logged in as facilitator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'facilitator') {
    header("Location: ../login.php");
    exit();
}

// Get facilitator name
$facilitator_id = $_SESSION['user_id'];
$stmt = $connection->prepare("SELECT name FROM tbl_facilitator WHERE id = ?");
$stmt->bind_param("i", $facilitator_id);
$stmt->execute();
$result = $stmt->get_result();
$facilitator = $result->fetch_assoc();
$facilitator_name = $facilitator['name'];

// Get counselor name
$stmt = $connection->prepare("SELECT name FROM tbl_counselor LIMIT 1");
$stmt->execute();
$result = $stmt->get_result();
$counselor = $result->fetch_assoc();
$counselor_name = $counselor['name'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'];
    $student_id = $_POST['student_id'];
    
    // Get the student info again to ensure data integrity
    $stmt = $connection->prepare("SELECT first_name, middle_name, last_name FROM tbl_student WHERE student_id = ?");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
    
    $first_name = $student['first_name'];
    $middle_name = $student['middle_name'];
    $last_name = $student['last_name'];
    
    $course_year = $_POST['course_year'];
    $reason_for_referral = $_POST['referralReason'];
    $violation_details = '';
    $other_concerns = '';

    switch ($reason_for_referral) {
        case 'academicConcern':
            $reason_for_referral = 'Academic concern';
            break;
        case 'behavioralMaladjustment':
            $reason_for_referral = 'Behavior maladjustment';
            break;
        case 'violation':
            $reason_for_referral = 'Violation to school rules';
            $violation_details = $_POST['violation_details'];
            break;
        case 'otherConcerns':
            $reason_for_referral = 'Other concern';
            $other_concerns = $_POST['other_concerns'];
            break;
    }

    $sql = "INSERT INTO referrals (date, student_id, first_name, middle_name, last_name, course_year, 
            reason_for_referral, violation_details, other_concerns, faculty_name, acknowledged_by) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("sssssssssss", 
        $date, 
        $student_id,
        $first_name, 
        $middle_name, 
        $last_name, 
        $course_year, 
        $reason_for_referral, 
        $violation_details, 
        $other_concerns, 
        $facilitator_name, 
        $counselor_name
    );
    
    if ($stmt->execute()) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit();
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => $stmt->error]);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Referral Form</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
    body {
        background: linear-gradient(to right, #0d693e, #004d4d);
        min-height: 100vh;
        font-family: Arial, sans-serif;
        padding-top: 60px;
    }
    .header {
        background-color: #ff9f1c;
        padding: 10px;
        text-align: center;
        font-size: 24px;
        font-weight: bold;
        position: fixed;
        right: 0;
        top: 0;
        width: 100%;
        color: white;
        z-index: 1000;
    }
    .back-btn {
        position: fixed;
        top: 10px;
        left: 10px;
        background-color: #6c757d;
        border: none;
        border-radius: 20px;
        padding: 5px 15px;
        font-weight: bold;
        color: white;
        z-index: 1001;
    }
    .form-container {
        background-color: #ffffff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .form-label {
        font-weight: bold;
    }
    .form-control {
        border: none;
        border-bottom: 1px solid #ccc;
        border-radius: 0;
        margin-bottom: 10px;
        width: 100%;
        display: inline-block;
    }
    .form-check-label {
        margin-left: 30px;
    }
    .btn-submit {
        background-color: #007bff;
        border: none;
        border-radius: 20px;
        padding: 10px 20px;
        font-weight: bold;
        color: white;
    }
    </style>
</head>
<body>
    <div class="header">REFERRAL FORM</div>
    <div class="container">
        <a href="guidanceservice.html" class="btn btn-secondary mb-3">Back</a>
        <div class="form-container">
            <form method="POST" action="" id="referralForm">
                <div class="form-group">
                    <label for="date">Date:</label>
                    <input type="date" class="form-control" id="date" name="date" required>
                </div>

                <div class="form-group">
                    <label for="student_id">Student ID:</label>
                    <input type="text" class="form-control" id="student_id" name="student_id" required>
                </div>

                <p>To the GUIDANCE COUNSELOR:</p>
                <p>This is to refer the student,</p>
                <div class="form-group">
                    <input type="text" class="form-control" name="student_name" id="student_name" placeholder="Student Name" readonly required>
                    <input type="text" class="form-control" name="course_year" id="course_year" placeholder="Course/Year" readonly required>
                    to your office for counselling.
                </div>

                <p>Reason for referral, please select one:</p>
                <div class="form-check">
                    <input type="radio" class="form-check-input" id="academicConcern" name="referralReason" value="academicConcern" required>
                    <label class="form-check-label" for="academicConcern">Academic concern</label>
                </div>
                <div class="form-check">
                    <input type="radio" class="form-check-input" id="behavioralMaladjustment" name="referralReason" value="behavioralMaladjustment">
                    <label class="form-check-label" for="behavioralMaladjustment">Behaviour maladjustment</label>
                </div>
                <div class="form-check">
                    <input type="radio" class="form-check-input" id="violation" name="referralReason" value="violation">
                    <label class="form-check-label" for="violation">Violation to school rules</label>
                </div>
                <div class="form-group" id="violationDetailsGroup" style="display: none;">
                    <input type="text" class="form-control" name="violation_details" id="violationDetails" placeholder="Specify violation">
                </div>
                <div class="form-check">
                    <input type="radio" class="form-check-input" id="otherConcerns" name="referralReason" value="otherConcerns">
                    <label class="form-check-label" for="otherConcerns">Other concerns</label>
                </div>
                <div class="form-group" id="otherConcernsGroup" style="display: none;">
                    <input type="text" class="form-control" name="other_concerns" id="otherConcernsDetails" placeholder="Specify other concerns">
                </div>

                <p>Thank you.</p>
                <div class="form-group">
                    <label>Signature over printed name of Faculty/Employee:</label>
                    <input type="text" class="form-control" name="faculty_name" value="<?php echo htmlspecialchars($facilitator_name); ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Acknowledged by:</label>
                    <input type="text" class="form-control" name="acknowledged_by" value="<?php echo htmlspecialchars($counselor_name); ?>" readonly>
                </div>
                <button type="submit" class="btn btn-primary">SUBMIT</button>
            </form>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Set today's date and max date
            var today = new Date().toISOString().split('T')[0];
            $('#date').val(today).attr('max', today);

            // Student ID lookup using existing get_student_info-facilitator.php
            $('#student_id').on('blur', function() {
                var studentId = $(this).val();
                if (studentId) {
                    $.ajax({
                        url: 'referral_get_student_info.php',
                        method: 'POST',
                        data: { student_id: studentId },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                var fullName = response.name;
                                $('#student_name').val(fullName);
                                $('#course_year').val(response.year_course);
                            } else {
                                Swal.fire({
                                    title: 'Student Not Found',
                                    text: 'Please check the student ID.',
                                    icon: 'warning',
                                    confirmButtonColor: '#3085d6'
                                });
                                $('#student_name, #course_year').val('');
                            }
                        },
                        error: function() {
                            Swal.fire({
                                title: 'Error',
                                text: 'Error fetching student information.',
                                icon: 'error',
                                confirmButtonColor: '#3085d6'
                            });
                        }
                    });
                }
            });

            // Handle reason for referral radio buttons
            $('input[name="referralReason"]').change(function() {
                var selectedReason = $(this).val();
                $('#violationDetailsGroup, #otherConcernsGroup').hide();
                $('#violationDetails, #otherConcernsDetails').prop('required', false);

                if (selectedReason === 'violation') {
                    $('#violationDetailsGroup').show();
                    $('#violationDetails').prop('required', true);
                } else if (selectedReason === 'otherConcerns') {
                    $('#otherConcernsGroup').show();
                    $('#otherConcernsDetails').prop('required', true);
                }
            });

            // Add form submission handler
            $('#referralForm').on('submit', function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Submit Referral',
                    text: 'Are you sure you want to submit this referral?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, submit it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: $(this).attr('action'),
                            type: 'POST',
                            data: $(this).serialize(),
                            dataType: 'json',
                            success: function(response) {
                                if (response.success) {
                                    Swal.fire({
                                        title: 'Success!',
                                        text: 'Referral has been submitted successfully.',
                                        icon: 'success',
                                        confirmButtonColor: '#3085d6'
                                    }).then(() => {
                                        window.location.reload();
                                    });
                                } else {
                                    Swal.fire({
                                        title: 'Error!',
                                        text: 'Failed to submit referral. Please try again.',
                                        icon: 'error',
                                        confirmButtonColor: '#3085d6'
                                    });
                                }
                            },
                            error: function() {
                                Swal.fire({
                                    title: 'Error!',
                                    text: 'An error occurred. Please try again.',
                                    icon: 'error',
                                    confirmButtonColor: '#3085d6'
                                });
                            }
                        });
                    }
                });
            });
        });
</script>
</body>
</html>