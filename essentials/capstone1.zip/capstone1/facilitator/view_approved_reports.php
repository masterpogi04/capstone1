<?php
//view_approved_reports.php
session_start();
include '../db.php';

// Check if the user is logged in as a facilitator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'facilitator') {
    header("Location: login.php");
    exit();
}

$search = isset($_GET['search']) ? $connection->real_escape_string($_GET['search']) : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'meeting_date';
$order = isset($_GET['order']) ? $_GET['order'] : 'ASC';
$filter_schedule = isset($_GET['filter_schedule']) ? $_GET['filter_schedule'] : '';
$filter_course = isset($_GET['filter_course']) ? $connection->real_escape_string($_GET['filter_course']) : '';

// Modified query to only count meetings with actual minutes
$query = "SELECT ir.*, sv.status as violation_status, s.first_name, s.last_name, 
          GROUP_CONCAT(DISTINCT iw.witness_name SEPARATOR ', ') as witnesses,
          ir.description, 
          (SELECT meeting_date FROM meetings WHERE incident_report_id = ir.id ORDER BY meeting_date DESC LIMIT 1) as meeting_date,
          (SELECT COUNT(*) FROM meetings 
           WHERE incident_report_id = ir.id 
           AND meeting_minutes IS NOT NULL 
           AND TRIM(meeting_minutes) != '') as meeting_minutes_count,
          c.name as course_name
          FROM incident_reports ir 
          JOIN student_violations sv ON ir.id = sv.incident_report_id
          JOIN tbl_student s ON sv.student_id = s.student_id
          LEFT JOIN incident_witnesses iw ON ir.id = iw.incident_report_id
          LEFT JOIN sections sec ON s.section_id = sec.id
          LEFT JOIN courses c ON sec.course_id = c.id
          WHERE (ir.status = 'For Meeting' OR ir.status = 'Approved' OR ir.status = 'Rescheduled')";

if (!empty($search)) {
    $query .= " AND (s.first_name LIKE '%$search%' OR s.last_name LIKE '%$search%' OR ir.description LIKE '%$search%')";
}

if ($filter_schedule === 'scheduled') {
    $query .= " AND EXISTS (SELECT 1 FROM meetings m WHERE m.incident_report_id = ir.id)";
} elseif ($filter_schedule === 'unscheduled') {
    $query .= " AND NOT EXISTS (SELECT 1 FROM meetings m WHERE m.incident_report_id = ir.id)";
}

if (!empty($filter_course)) {
    $query .= " AND c.name = '$filter_course'";
}

$query .= " GROUP BY ir.id ORDER BY $sort $order";

$result = $connection->query($query);

if ($result === false) {
    die("Query failed: " . $connection->error);
}

// Fetch all courses for the filter dropdown
$course_query = "SELECT DISTINCT name FROM courses ORDER BY name";
$course_result = $connection->query($course_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incident Reports for Meeting</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
         body {
            background: linear-gradient(135deg, #0d693e, #004d4d);
            min-height: 100vh;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            margin: 0;
            color: #333;
        }
        .container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            margin-top: 50px;
            margin-bottom: 50px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #0d693e;
            border-bottom: 2px solid #0d693e;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        dt {
            font-weight: bold;
            color: #0d693e;
        }
        dd {
            margin-bottom: 15px;
        }
        .btn-primary {
            background-color: #0d693e;
            border-color: #0d693e;
        }
        .btn-primary:hover {
            background-color: #094e2e;
            border-color: #094e2e;
        }
         .btn-secondary {
            background-color: #F4A261;
            border-color: #F4A261;
            color: #fff;
            padding: 10px 20px;
        }
        .btn-secondary:hover {
            background-color: #E76F51;
            border-color: #E76F51;
        }
        .search-filter-container {
            margin-bottom: 20px;
        }

        .btn-info {
            background-color: #0d693e;
            border-color: #0d693e;
        }

        .btn-info:hover {
            background-color: #094e2e;
            border-color: #094e2e;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <a href="guidanceservice.html" class="btn btn-secondary mb-4">
            <i class="fas fa-arrow-left"></i> Back to Guidance Services
        </a>
        <h1>Incident Reports for Meeting</h1>
        
        <form action="" method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-3">
                    <input type="text" name="search" class="form-control" placeholder="Search student or violation" value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2">
                    <select name="filter_schedule" class="form-control">
                        <option value="">All Schedules</option>
                        <option value="scheduled" <?php echo $filter_schedule === 'scheduled' ? 'selected' : ''; ?>>Scheduled</option>
                        <option value="unscheduled" <?php echo $filter_schedule === 'unscheduled' ? 'selected' : ''; ?>>Unscheduled</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="filter_course" class="form-control">
                        <option value="">All Courses</option>
                        <?php while ($course = $course_result->fetch_assoc()): ?>
                            <option value="<?php echo htmlspecialchars($course['name']); ?>" <?php echo $filter_course === $course['name'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($course['name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="sort" class="form-control">
                        <option value="meeting_date" <?php echo $sort === 'meeting_date' ? 'selected' : ''; ?>>Meeting Date</option>
                        <option value="date_reported" <?php echo $sort === 'date_reported' ? 'selected' : ''; ?>>Date Reported</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="order" class="form-control">
                        <option value="ASC" <?php echo $order === 'ASC' ? 'selected' : ''; ?>>Ascending</option>
                        <option value="DESC" <?php echo $order === 'DESC' ? 'selected' : ''; ?>>Descending</option>
                    </select>
                </div>
                <div class="col-md-1">
                    <button type="submit" class="btn btn-primary">Apply</button>
                </div>
            </div>
        </form>
        
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Date Reported</th>
                    <th>Student</th>
                    <th>Course</th>
                    <th>Violation</th>
                    <th>Witnesses</th>
                    <th>Meeting Date</th>
                    <th>Resolution Notes</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['date_reported']); ?></td>
                        <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['course_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        <td><?php echo htmlspecialchars($row['witnesses']); ?></td>
                        <td><?php echo $row['meeting_date'] ? htmlspecialchars(date('F j, Y, g:i A', strtotime($row['meeting_date']))) : 'Not scheduled'; ?></td>
                        <td>
                            <?php if ($row['meeting_minutes_count'] > 0): ?>
                                <button class="btn btn-info btn-sm" onclick="window.location.href='view_all_minutes.php?id=<?php echo $row['id']; ?>'">
                                    <i class="fas fa-eye"></i> View All Minutes (<?php echo $row['meeting_minutes_count']; ?> Meetings)
                                </button>
                            <?php else: ?>
                                <?php if ($row['meeting_date']): ?>
                                    No minutes recorded yet
                                <?php else: ?>
                                    No meeting scheduled
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="schedule_generator.php?report_id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">
                                <?php echo $row['meeting_date'] ? 'Reschedule Meeting' : 'Schedule Meeting'; ?>
                            </a>
                            <button class="btn btn-success btn-sm" onclick="window.location.href='add_meeting_minutes.php?id=<?php echo $row['id']; ?>'">
                                <i class="fas fa-plus"></i> Add Minutes
                            </button>
                           <form action="referral_incident_reports.php" method="GET" style="display: inline;">
                                <input type="hidden" name="report_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" class="btn btn-warning btn-sm">
                                    Refer to Counselor
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>


</body>
</html>