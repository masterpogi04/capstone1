<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'facilitator') {
    header("Location: ../login.php");
    exit();
}

$facilitator_id = $_SESSION['user_id'];
$stmt = $connection->prepare("SELECT name, profile_picture FROM tbl_facilitator WHERE id = ?");
if ($stmt === false) {
    die("Prepare failed: " . $connection->error);
}
$stmt->bind_param("i", $facilitator_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $facilitator = $result->fetch_assoc();
    $name = $facilitator['name'];
    $profile_picture = $facilitator['profile_picture'];
} else {
    die("Facilitator not found.");
}

// Handle notification deletion
if (isset($_POST['delete_notification'])) {
    $notification_id = $_POST['notification_id'];
    $delete_stmt = $connection->prepare("DELETE FROM notifications WHERE id = ? AND user_type = 'facilitator' AND user_id = ?");
    $delete_stmt->bind_param("ii", $notification_id, $facilitator_id);
    $delete_stmt->execute();
}

// Fetch all notifications (both read and unread)
$stmt = $connection->prepare("SELECT *, 
    CASE 
        WHEN created_at > NOW() - INTERVAL 24 HOUR THEN DATE_FORMAT(created_at, '%l:%i %p')
        WHEN created_at > NOW() - INTERVAL 7 DAY THEN CONCAT(DATEDIFF(NOW(), created_at), ' days ago')
        ELSE DATE_FORMAT(created_at, '%M %d, %Y')
    END as formatted_date 
    FROM notifications 
    WHERE user_type = 'facilitator' AND user_id = ? 
    ORDER BY created_at DESC");
$stmt->bind_param("s", $facilitator_id);
$stmt->execute();
$result = $stmt->get_result();
$notifications = $result->fetch_all(MYSQLI_ASSOC);

// Get count of unread notifications
$unread_stmt = $connection->prepare("SELECT COUNT(*) as unread_count FROM notifications WHERE user_type = 'facilitator' AND user_id = ? AND is_read = 0");
$unread_stmt->bind_param("s", $facilitator_id);
$unread_stmt->execute();
$unread_result = $unread_stmt->get_result();
$unread_count = $unread_result->fetch_assoc()['unread_count'];

$connection->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CEIT - Guidance Office</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <style>
    
        body {
            font-family: 'Roboto', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
            min-height: 100vh;
            display: flex;
        }
        .sidebar {
        background-color: #00563B;
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        width: 255px;
        padding: 20px 0;
        box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        overflow-y: auto;
        z-index: 1000;
    }
    .sidebar a{
    list-style-type: none;
    padding: 0;
    margin: 20px 0;
}

.sidebar  a {
    display: block;
    padding: 12px 20px;
    color: #ecf0f1;
    text-decoration: none;
    transition: background-color 0.3s ease;
    border-left: 4px solid transparent;
}

.sidebar a:hover, .sidebar nav ul li a.active {
    background-color: #2c3e50;
    border-left-color: #3498db;
}
.header {
    background-color: #ff9042;
    width: calc(100% - 250px); /* Full width minus sidebar width */
    padding: 10px;
    color: black;
    font-family: 'Georgia', serif;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: fixed;
    top: 0;
    left: 255px;
    z-index: 1000;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}
.header h1{
    margin: 0;
    font-size: 2rem;
    font-weight: 400;
}

.main-content {
    margin-left: 250px;
    padding: 57px 20px 69px;
    flex: 1;
    min-height: calc(100vh - 130px);
    box-sizing: border-box;
}
 
.welcome-text {
        position: relative;
        background-image: url('cvsu1.jpg');
        background-size: cover;
        background-position: center;
        color: white;
        padding: 50px;
        text-align: left;
        margin-top: 2;
        margin-bottom: 20px;
        width: 104%; /* Double the width of the parent container */
        box-sizing: border-box; /* Includes padding in the width calculation */
        left: -2%; /* Move half of the extra width to the left */
        right: auto; /* Remove right property */
        }

    .welcome-text::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 128, 0, 0.7);
      z-index: 0;
    }

    .welcome-text h1 {
      position: relative;
      z-index: 1;
      font-size: 48px;
      font-weight: 700;
      margin-bottom: 0;
    }
        .h2 {
            font-family: serif;
            font-size: 60px;
            font-weight: 700;
        }
        h3 {
            font-family: serif;
            font-size: 40px;
        }
        .button-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-top: 20px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            padding: 20px;
        }

        .custom-btn {
            padding: 20px;
            font-size: 1rem;
            color: #ffffff;
            background-color: #1A6E47;
            border: none;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            height: 80px;
        }

        .custom-btn i {
            margin-right: 10px;
            font-size: 1.2rem;
        }

        .custom-btn:hover {
            background-color: #15573A;
            transform: translateY(-3px);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        }

        @media (max-width: 768px) {
            .button-container {
                grid-template-columns: 1fr;
            }
        }
        .footer {
        background-color: #ff9042;
        color: #ecf0f1;
        text-align: center;
        padding: 15px;
        position: fixed;
        bottom: 0;
        left: 255px;
        right: 0;
        height: 50px;
        z-index: 1000;
        }

@media (max-width: 768px) {
    body {
        flex-direction: column;
    }

    .sidebar {
        width: 100%;
        height: auto;
        position: relative;
        padding-top: 0;
    }

    .header {
        width: 100%;
        left: 0;
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .footer {
        left: 0;
        width: 100%;
    }
}
        .profile-section {
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
}

.avatar {
  width: 80px;
  height: 80px;
  background-color: #4A90E2;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  font-weight: bold;
  color: white;
  text-transform: uppercase;
  user-select: none;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.profile-section p {
    margin-top: 15px;
    font-size: 18px;
    color: #ecf0f1;
    font-weight: 500;
}
     .notification-icon {
        position: relative;
    }
    
    .notification-badge {
        position: absolute;
        top: -8px;
        right: -8px;
        background-color: #dc3545;
        color: white;
        border-radius: 50%;
        padding: 2px 6px;
        font-size: 12px;
    }
    
    .notification-panel {
        position: fixed;
        top: 60px;
        right: 20px;
        width: 350px;
        background-color: #ffffff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        padding: 15px;
        max-height: 500px;
        overflow-y: auto;
        z-index: 1000;
        display: none;
    }
    
    .notification-item {
        padding: 12px;
        border-bottom: 1px solid #eee;
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        transition: background-color 0.3s;
    }
    
    .notification-item:hover {
        background-color: #f8f9fa;
    }
    
    .notification-content {
        flex-grow: 1;
        margin-right: 10px;
    }
    
    .notification-message {
        color: #333;
        text-decoration: none;
        font-size: 14px;
        margin-bottom: 4px;
        display: block;
    }
    
    .notification-time {
        color: #6c757d;
        font-size: 12px;
    }
    
    .notification-unread {
        background-color: #f0f7ff;
    }
    
    .delete-notification {
        background: none;
        border: none;
        color: #dc3545;
        cursor: pointer;
        padding: 4px;
        opacity: 0.7;
        transition: opacity 0.3s;
    }
    
    .delete-notification:hover {
        opacity: 1;
    }
    
    .notifications-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #eee;
    }
    
    .no-notifications {
        text-align: center;
        color: #6c757d;
        padding: 20px;
        font-style: italic;
    }
    </style>
  </style>
</head>
<body>
  <nav class="sidebar">
  <div class="sidebar-content">
  <div class="profile-section text-center">
  <div class="avatar">
    <?php 
      // Get first letter of first and last name
      $nameParts = explode(' ', $name);
      $initials = '';
      if (!empty($nameParts[0])) {
        $initials .= substr($nameParts[0], 0, 1);
      }
      if (!empty($nameParts[1])) {
        $initials .= substr($nameParts[1], 0, 1);
      }
      echo htmlspecialchars(strtoupper($initials));
    ?>
  </div>
  <p><?php echo htmlspecialchars($name); ?></p>
</div>


    <a href="facilitator_homepage.php" class="active">Home</a>
        <a class="nav-item" href="facilitator_dashboard.php" >Dashboard</a>
        <a class="nav-item" href="facilitator_my_profile.php">My Profile</a>
        <a class="nav-item" href="help_support_facilitator.php">Help & Support</a>
        <a class="nav-item" href="../login.php" onclick="return confirm('Are you sure you want to log out?')">Log Out</a>
  </nav>
  
  <div class="main-content">
    <header class="header">
        <h1>CEIT - GUIDANCE OFFICE</h1>
        <i class="fa fa-bell notification-icon" onclick="toggleNotifications()"></i>
    </header>

    <div class="notification-panel" id="notificationPanel">
        <div class="notifications-header">
            <h5 style="margin: 0;">Notifications</h5>
            <?php if ($unread_count > 0): ?>
                <span class="badge bg-primary"><?php echo $unread_count; ?> new</span>
            <?php endif; ?>
        </div>
        <?php if (empty($notifications)): ?>
            <div class="no-notifications">
                <p>No notifications</p>
            </div>
        <?php else: ?>
            <?php foreach ($notifications as $notif): ?>
                <div class="notification-item <?php echo $notif['is_read'] ? '' : 'notification-unread'; ?>" 
                     id="notification-<?php echo $notif['id']; ?>">
                    <div class="notification-content">
                        <a href="<?php echo htmlspecialchars($notif['link']); ?>" 
                           class="notification-message">
                            <?php echo htmlspecialchars($notif['message']); ?>
                        </a>
                        <div class="notification-time">
                            <?php echo htmlspecialchars($notif['formatted_date']); ?>
                        </div>
                    </div>
                    <button class="delete-notification" 
                            onclick="deleteNotification(<?php echo $notif['id']; ?>)">
                        <i class="fa fa-trash"></i>
                    </button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

   <main>
      <div class="welcome-text">
        <h1>WELCOME, <?php echo htmlspecialchars($name); ?>!</h1>
      </div>
      <div class="button-container">
        <a class="custom-btn" href="facilitator_incident_report.php">Submit an Incident Report</a>
        <a class="custom-btn" href="incident_reports-facilitator.php">View my Submitted Incident Reports</a>
        <a class="custom-btn" href="view_profiles.php">View Student Profile</a>
        <a class="custom-btn" href="guidanceservice.html">Guidance Services</a>
      </div>
    </main>
    <footer class="footer">
      <p>&copy; 2024 All Rights Reserved</p>
    </footer>
  </div>

  <script>
    function toggleNotifications() {
      var panel = document.getElementById('notificationPanel');
      panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }

    function deleteNotification(notificationId) {
      if (confirm('Are you sure you want to delete this notification?')) {
        $.ajax({
          url: 'facilitator_homepage.php',
          type: 'POST',
          data: {
            delete_notification: true,
            notification_id: notificationId
          },
          success: function(response) {
            $('#notification-' + notificationId).remove();
            if ($('.notification-item').length === 0) {
              $('#notificationPanel').html('<h5>Notifications</h5><p>No new notifications</p>');
            }
          },
          error: function() {
            alert('Error deleting notification. Please try again.');
          }
        });
      }
    }
  </script>
</body>
</html>