<?php
session_start();
include '../db.php';

// Check if user is logged in as facilitator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'facilitator') {
    header("Location: login.php");
    exit();
}

// Function to check student violations
function checkStudentViolations($student_number, $connection) {
    $query = "SELECT ir.id, ir.description, ir.status, ir.date_reported 
              FROM incident_reports ir
              JOIN student_violations sv ON ir.id = sv.incident_report_id
              WHERE sv.student_id = ? 
              AND (ir.status != 'Settled' AND ir.status != 'Resolved')";
              
    $stmt = $connection->prepare($query);
    $stmt->bind_param("s", $student_number);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $violations = array();
    while($row = $result->fetch_assoc()) {
        $violations[] = $row;
    }
    
    return $violations;
}

// Function to send notification
function sendNotification($student_id, $status, $document_type) {
    global $connection;
    $message = "Your request for $document_type has been $status.";
    $sql = "INSERT INTO notifications (user_id, user_type, message, is_read) VALUES (?, 'student', ?, 0)";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("ss", $student_id, $message);
    $stmt->execute();
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $request_id = $_POST['request_id'];
    $status = $_POST['status'];
    
    // First get the student number for the request
    $fetch_student = $connection->prepare("SELECT student_number, document_request FROM document_requests WHERE request_id = ?");
    $fetch_student->bind_param("s", $request_id);
    $fetch_student->execute();
    $student_result = $fetch_student->get_result();
    $student_data = $student_result->fetch_assoc();
    
    // Check for violations if trying to approve
    if ($status === 'Approved') {
        $violations = checkStudentViolations($student_data['student_number'], $connection);
        if (!empty($violations)) {
            echo json_encode([
                'error' => true,
                'message' => 'Cannot approve request. Student has pending violations.',
                'violations' => $violations
            ]);
            exit;
        }
    }
    
    // If no violations or not approving, proceed with update
    $update_stmt = $connection->prepare("UPDATE document_requests SET status = ? WHERE request_id = ?");
    $update_stmt->bind_param("ss", $status, $request_id);
    
    if ($update_stmt->execute()) {
        sendNotification($student_data['student_number'], $status, $student_data['document_request']);
        
        if ($status === 'Approved') {
            echo json_encode(['success' => true, 'redirect' => "approved_request.php?id=$request_id"]);
        } elseif ($status === 'Rejected') {
            echo json_encode(['success' => true, 'redirect' => "rejected_request.php?id=$request_id"]);
        } else {
            echo json_encode(['success' => true]);
        }
    } else {
        echo json_encode(['error' => true, 'message' => 'Failed to update status']);
    }
    exit;
}

// Handle delete action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    $ids_to_delete = $_POST['delete'];
    
    $delete_stmt = $connection->prepare("DELETE FROM document_requests WHERE request_id = ?");
    
    $success_count = 0;
    $error_count = 0;
    
    foreach ($ids_to_delete as $id) {
        $delete_stmt->bind_param("s", $id);
        
        if ($delete_stmt->execute()) {
            $success_count++;
        } else {
            $error_count++;
        }
    }
    
    $delete_stmt->close();
    
    if ($success_count > 0) {
        $_SESSION['message'] = "Successfully deleted $success_count request(s).";
        if ($error_count > 0) {
            $_SESSION['message'] .= " Failed to delete $error_count request(s).";
        }
    } else {
        $_SESSION['message'] = "Failed to delete any requests.";
    }
}

// Get filter values
$department_filter = isset($_GET['department']) ? $_GET['department'] : '';
$course_filter = isset($_GET['course']) ? $_GET['course'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$time_filter = isset($_GET['time_filter']) ? $_GET['time_filter'] : '';
$document_filter = isset($_GET['document_filter']) ? $_GET['document_filter'] : '';

// Pagination setup
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 10; //here we can edit, how many content to display
$offset = ($page - 1) * $perPage;

// Modified base query to include violation check
$query = "SELECT dr.*, 
          CASE 
              WHEN EXISTS (
                  SELECT 1 
                  FROM student_violations sv 
                  JOIN incident_reports ir ON sv.incident_report_id = ir.id 
                  WHERE sv.student_id = dr.student_number 
                  AND (ir.status != 'Settled' AND ir.status != 'Resolved')
              ) THEN 'Yes' 
              ELSE 'No' 
          END as has_violations
          FROM document_requests dr 
          WHERE 1=1";

// Add filter conditions
if (!empty($department_filter)) {
    $query .= " AND dr.department = ?";
}
if (!empty($course_filter)) {
    $query .= " AND dr.course = ?";
}
if (!empty($status_filter)) {
    $query .= " AND dr.status = ?";
}
if (!empty($time_filter)) {
    switch ($time_filter) {
        case 'today':
            $query .= " AND DATE(dr.request_time) = CURDATE()";
            break;
        case 'this_week':
            $query .= " AND YEARWEEK(dr.request_time) = YEARWEEK(CURDATE())";
            break;
        case 'this_month':
            $query .= " AND MONTH(dr.request_time) = MONTH(CURDATE()) AND YEAR(dr.request_time) = YEAR(CURDATE())";
            break;
    }
}
if (!empty($document_filter)) {
    $query .= " AND dr.document_request = ?";
}

$query .= " ORDER BY dr.request_time DESC LIMIT ? OFFSET ?";

// Prepare and execute the statement
$stmt = $connection->prepare($query);
if ($stmt === false) {
    die("Prepare failed: " . $connection->error);
}

// Bind parameters if filters are set
$types = "";
$params = array();

if (!empty($department_filter)) {
    $types .= "s";
    $params[] = $department_filter;
}
if (!empty($course_filter)) {
    $types .= "s";
    $params[] = $course_filter;
}
if (!empty($status_filter)) {
    $types .= "s";
    $params[] = $status_filter;
}
if (!empty($document_filter)) {
    $types .= "s";
    $params[] = $document_filter;
}

// Add LIMIT and OFFSET parameters
$types .= "ii";
$params[] = $perPage;
$params[] = $offset;

if (!empty($types)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$requests = $result->fetch_all(MYSQLI_ASSOC);

// Modified count query to match the main query structure
$countQuery = "SELECT COUNT(*) as total FROM document_requests dr WHERE 1=1";
$countParams = [];
$countTypes = "";

if (!empty($department_filter)) {
    $countQuery .= " AND department = ?";
    $countParams[] = $department_filter;
    $countTypes .= "s";
}
if (!empty($course_filter)) {
    $countQuery .= " AND course = ?";
    $countParams[] = $course_filter;
    $countTypes .= "s";
}
if (!empty($status_filter)) {
    $countQuery .= " AND status = ?";
    $countParams[] = $status_filter;
    $countTypes .= "s";
}
if (!empty($document_filter)) {
    $countQuery .= " AND document_request = ?";
    $countParams[] = $document_filter;
    $countTypes .= "s";
}

$countStmt = $connection->prepare($countQuery);
if ($countStmt === false) {
    die("Prepare failed: " . $connection->error);
}

if (!empty($countTypes)) {
    $countStmt->bind_param($countTypes, ...$countParams);
}

$countStmt->execute();
$countResult = $countStmt->get_result();
$totalRows = $countResult->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $perPage);
// Fetch departments and courses
$dept_query = "SELECT DISTINCT department FROM document_requests";
$dept_result = $connection->query($dept_query);
$departments = $dept_result->fetch_all(MYSQLI_ASSOC);

$course_query = "SELECT DISTINCT department, course FROM document_requests ORDER BY department, course";
$course_result = $connection->query($course_query);
$courses = $course_result->fetch_all(MYSQLI_ASSOC);

// Organize courses by department
$courses_by_dept = [];
foreach ($courses as $course) {
    $courses_by_dept[$course['department']][] = $course['course'];
}

// Fetch unique document types
$doc_query = "SELECT DISTINCT document_request FROM document_requests ORDER BY document_request";
$doc_result = $connection->query($doc_query);
$document_types = $doc_result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facilitator Dashboard - Document Requests</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #0d693e, #004d4d);
            min-height: 100vh;
            font-family: 'Arial', sans-serif;
            display: flex;
            flex-direction: column;
            margin: 0;
            color: #333;
        }
        .header {
            background-color: #ff9f1c;
            padding: 15px;
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            color: white;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .form-container {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }
        .form-content {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            width: 100%;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .form-group label {
            font-weight: bold;
            color: #0d693e;
        }
        .form-control[readonly] {
            background-color: #f8f9fa;
            color: #495057;
        }
        .btn-update {
            background-color: #28a745;
            color: white;
            transition: all 0.3s ease;
        }
        .btn-update:hover {
            background-color: #218838;
            transform: translateY(-2px);
        }
        .back-button {
            align-self: flex-start;
            margin-bottom: 20px;
            background-color: #ff9f1c;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .back-button:hover {
            background-color: #e88e00;
            transform: translateY(-2px);
        }
        .table {
            font-size: 0.9rem;
            width: 100%;
            margin-bottom: 2rem;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .table th,
        .table td {
            padding: 12px;
            vertical-align: middle;
            border: none;
        }
        .table thead th {
            background-color: #0d693e;
            color: #ffffff;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .table tbody tr:nth-of-type(even) {
            background-color: #f8f9fa;
        }
        .table tbody tr:hover {
            background-color: #e9ecef;
        }
        .table-responsive {
            margin-bottom: 20px;
        }
        .filter-form {
            margin-bottom: 30px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }
        .filter-form select {
            flex: 1;
            min-width: 150px;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            background-color: #fff;
        }
        .filter-form button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .filter-form button:hover {
            background-color: #0056b3;
        }
        .delete-btn {
            margin-top: 20px;
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .delete-btn:hover {
            background-color: #c82333;
        }
        .action-buttons {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        
        .generate-report-btn {
            background-color: #17a2b8;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .generate-report-btn:hover {
            background-color: #138496;
            transform: translateY(-2px);
        }
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        .pagination a, .pagination span {
            padding: 8px 16px;
            margin: 0 4px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .pagination a {
            background-color: #ff9f1c; /* Using the orange color from your header */
            color: white;
            border: 1px solid #ff9f1c;
        }

        .pagination a:hover {
            background-color: #e88e00;
            border-color: #e88e00;
        }

        .pagination .active {
            background-color: #0d693e; /* Using the green color from your background */
            color: white;
            border: 1px solid #0d693e;
        }

        .pagination .disabled {
            background-color: #f1f1f1;
            color: #888;
            cursor: not-allowed;
        }
    </style>
</head>
<body>
    <div class="header">
        STUDENT DOCUMENT REQUEST
    </div>
    <div class="form-container">
        <div class="action-buttons">
            <a href="guidanceservice.html" class="btn back-button">
                <i class="fas fa-arrow-left"></i> Back
            </a>
            <a href="facilitator_generate_reports.php" class="btn generate-report-btn">
                <i class="fas fa-file-alt"></i> Generate Report
            </a>
        </div>
        <div class="form-content">
           <form class="filter-form" method="GET">
                <select name="department" id="department" class="form-control">
                    <option value="">All Departments</option>
                    <?php foreach ($departments as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept['department']); ?>" <?php echo $dept['department'] === $department_filter ? 'selected' : ''; ?>><?php echo htmlspecialchars($dept['department']); ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="course" id="course" class="form-control">
                    <option value="">All Courses</option>
                </select>
                <select name="status" class="form-control">
                    <option value="">All Statuses</option>
                    <option value="Pending" <?php echo 'Pending' === $status_filter ? 'selected' : ''; ?>>Pending</option>
                    <option value="Processing" <?php echo 'Processing' === $status_filter ? 'selected' : ''; ?>>Processing</option>
                    <option value="Approved" <?php echo 'Approved' === $status_filter ? 'selected' : ''; ?>>Approved</option>
                    <option value="Rejected" <?php echo 'Rejected' === $status_filter ? 'selected' : ''; ?>>Rejected</option>
                </select>
                <select name="time_filter" class="form-control">
                    <option value="">All Time</option>
                    <option value="today" <?php echo 'today' === $time_filter ? 'selected' : ''; ?>>Today</option>
                    <option value="this_week" <?php echo 'this_week' === $time_filter ? 'selected' : ''; ?>>This Week</option>
                    <option value="this_month" <?php echo 'this_month' === $time_filter ? 'selected' : ''; ?>>This Month</option>
                </select>
                <select name="document_filter" class="form-control">
                    <option value="">All Documents</option>
                    <?php foreach ($document_types as $doc): ?>
                        <option value="<?php echo htmlspecialchars($doc['document_request']); ?>" <?php echo $doc['document_request'] === $document_filter ? 'selected' : ''; ?>><?php echo htmlspecialchars($doc['document_request']); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </form>
            <form id="deleteForm" method="POST">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="selectAll"></th>
                                <th>Request ID</th>
                                <th>Student Name</th>
                                <th>Student Number</th>
                                <th>Department</th>
                                <th>Course</th>
                                <th>Document</th>
                                <th>Purpose</th>
                                <th>Contact Email</th>
                                <th>Request Time</th>
                                <th>Status</th>
                                <th>Has Violations</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($requests as $request): ?>
                            <tr>
                                <td><input type="checkbox" name="delete[]" value="<?php echo $request['request_id']; ?>"></td>
                                <td><?php echo htmlspecialchars($request['request_id']); ?></td>
                                <td><?php echo htmlspecialchars($request['first_name'] . ' ' . $request['last_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['student_number']); ?></td>
                                <td><?php echo htmlspecialchars($request['department']); ?></td>
                                <td><?php echo htmlspecialchars($request['course']); ?></td>
                                <td><?php echo htmlspecialchars($request['document_request']); ?></td>
                                <td><?php echo htmlspecialchars($request['purpose']); ?></td>
                                <td><?php echo htmlspecialchars($request['contact_email']); ?></td>
                                <td><?php echo htmlspecialchars($request['request_time']); ?></td>
                                <td><?php echo htmlspecialchars($request['status']); ?></td>
                                <td style="color: <?php echo $request['has_violations'] === 'Yes' ? 'red' : 'green'; ?>">
                                    <?php echo htmlspecialchars($request['has_violations']); ?>
                                </td>
                                <td>
                                    <button type="button" onclick="updateStatus('<?php echo $request['request_id']; ?>')" class="btn btn-update btn-sm">
                                        <i class="fas fa-edit"></i> Update
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <button type="submit" class="btn delete-btn">
                    <i class="fas fa-trash-alt"></i> Delete Selected
                </button>
            </form>
        </div>
        
        <!-- Pagination -->
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=1<?php echo isset($_GET['department']) ? '&department='.$_GET['department'] : ''; ?><?php echo isset($_GET['course']) ? '&course='.$_GET['course'] : ''; ?><?php echo isset($_GET['status']) ? '&status='.$_GET['status'] : ''; ?><?php echo isset($_GET['time_filter']) ? '&time_filter='.$_GET['time_filter'] : ''; ?><?php echo isset($_GET['document_filter']) ? '&document_filter='.$_GET['document_filter'] : ''; ?>">&laquo; First</a>
                <a href="?page=<?php echo $page-1; ?><?php echo isset($_GET['department']) ? '&department='.$_GET['department'] : ''; ?><?php echo isset($_GET['course']) ? '&course='.$_GET['course'] : ''; ?><?php echo isset($_GET['status']) ? '&status='.$_GET['status'] : ''; ?><?php echo isset($_GET['time_filter']) ? '&time_filter='.$_GET['time_filter'] : ''; ?><?php echo isset($_GET['document_filter']) ? '&document_filter='.$_GET['document_filter'] : ''; ?>">&laquo;</a>
            <?php endif; ?>
            
            <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="active"><?php echo $i; ?></span>
                <?php else: ?>
                    <a href="?page=<?php echo $i; ?><?php echo isset($_GET['department']) ? '&department='.$_GET['department'] : ''; ?><?php echo isset($_GET['course']) ? '&course='.$_GET['course'] : ''; ?><?php echo isset($_GET['status']) ? '&status='.$_GET['status'] : ''; ?><?php echo isset($_GET['time_filter']) ? '&time_filter='.$_GET['time_filter'] : ''; ?><?php echo isset($_GET['document_filter']) ? '&document_filter='.$_GET['document_filter'] : ''; ?>"><?php echo $i; ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?php echo $page+1; ?><?php echo isset($_GET['department']) ? '&department='.$_GET['department'] : ''; ?><?php echo isset($_GET['course']) ? '&course='.$_GET['course'] : ''; ?><?php echo isset($_GET['status']) ? '&status='.$_GET['status'] : ''; ?><?php echo isset($_GET['time_filter']) ? '&time_filter='.$_GET['time_filter'] : ''; ?><?php echo isset($_GET['document_filter']) ? '&document_filter='.$_GET['document_filter'] : ''; ?>">&raquo;</a>
                <a href="?page=<?php echo $totalPages; ?><?php echo isset($_GET['department']) ? '&department='.$_GET['department'] : ''; ?><?php echo isset($_GET['course']) ? '&course='.$_GET['course'] : ''; ?><?php echo isset($_GET['status']) ? '&status='.$_GET['status'] : ''; ?><?php echo isset($_GET['time_filter']) ? '&time_filter='.$_GET['time_filter'] : ''; ?><?php echo isset($_GET['document_filter']) ? '&document_filter='.$_GET['document_filter'] : ''; ?>">Last &raquo;</a>
            <?php endif; ?>
        </div>
    </div>

   <script>
    $(document).ready(function() {
        var coursesByDept = <?php echo json_encode($courses_by_dept); ?>;
        var selectedDepartment = "<?php echo $department_filter; ?>";
        var selectedCourse = "<?php echo $course_filter; ?>";

        function updateCourseOptions() {
            var department = $('#department').val();
            var courseSelect = $('#course');
            courseSelect.empty().append('<option value="">All Courses</option>');

            if (department && coursesByDept[department]) {
                $.each(coursesByDept[department], function(i, course) {
                    courseSelect.append($('<option>', {
                        value: course,
                        text: course,
                        selected: (course === selectedCourse)
                    }));
                });
            }
        }

        $('#department').change(updateCourseOptions);

        // Initial course population
        updateCourseOptions();

        // Set the selected department and trigger change to populate courses
        if (selectedDepartment) {
            $('#department').val(selectedDepartment).trigger('change');
        }

        // Select all checkbox functionality
        $('#selectAll').click(function() {
            $('input[name="delete[]"]').prop('checked', this.checked);
        });

        // Submit delete form with confirmation
        $('#deleteForm').submit(function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit();
                }
            });
        });

        // Show message if set
        <?php if (isset($_SESSION['message'])): ?>
        Swal.fire({
            title: 'Info',
            text: '<?php echo $_SESSION['message']; ?>',
            icon: 'info'
        });
        <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
    });

    // Modified updateStatus function to handle violations
    function updateStatus(requestId) {
        Swal.fire({
            title: 'Update Status',
            input: 'select',
            inputOptions: {
                'Pending': 'Pending',
                'Processing': 'Processing',
                'Approved': 'Approved',
                'Rejected': 'Rejected'
            },
            showCancelButton: true,
            confirmButtonText: 'Update',
            showLoaderOnConfirm: true,
            preConfirm: (status) => {
                return $.ajax({
                    url: '<?php echo $_SERVER['PHP_SELF']; ?>',
                    method: 'POST',
                    data: {
                        action: 'update_status',
                        request_id: requestId,
                        status: status
                    },
                    dataType: 'json'
                }).then(response => {
                    if (response.error) {
                        if (response.violations) {
                            let violationText = 'Violations found:\n';
                            response.violations.forEach(v => {
                                violationText += `- ${v.description} (${v.date_reported})\n`;
                            });
                            throw new Error(response.message + '\n\n' + violationText);
                        }
                        throw new Error(response.message);
                    }
                    return response;
                }).catch(error => {
                    Swal.showValidationMessage(`${error}`);
                });
            },
            allowOutsideClick: () => !Swal.isLoading()
        }).then((result) => {
            if (result.isConfirmed) {
                if (result.value.redirect) {
                    window.location.href = result.value.redirect;
                } else {
                    Swal.fire({
                        title: 'Success!',
                        text: 'Status updated successfully',
                        icon: 'success'
                    }).then(() => {
                        location.reload();
                    });
                }
            }
        });
    }
</script>
</body>
</html>