<?php
session_start();
include '../db.php';

// Ensure the user is logged in and is a facilitator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'facilitator') {
    header("Location: ../login.php");
    exit();
}

// Fetch all departments
$stmt = $connection->prepare("SELECT id, name FROM departments");
$stmt->execute();
$result = $stmt->get_result();
$departments = $result->fetch_all(MYSQLI_ASSOC);

// Fetch facilitator name
$facilitator_id = $_SESSION['user_id'];
$stmt = $connection->prepare("SELECT name FROM tbl_facilitator WHERE id = ?");
$stmt->bind_param("i", $facilitator_id);
$stmt->execute();
$result = $stmt->get_result();
$facilitator = $result->fetch_assoc();
$facilitator_name = $facilitator['name'];

// Handle search
$search_results = [];
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_term = '%' . $_GET['search'] . '%';
    $stmt = $connection->prepare("
        SELECT ts.student_id, ts.first_name, ts.last_name, 
               d.id AS department_id, d.name AS department_name, 
               c.id AS course_id, c.name AS course_name, 
               s.id AS section_id, s.year_level, s.section_no
        FROM tbl_student ts
        JOIN sections s ON ts.section_id = s.id
        JOIN departments d ON s.department_id = d.id
        JOIN courses c ON s.course_id = c.id
        WHERE ts.student_id LIKE ? OR ts.first_name LIKE ? OR ts.last_name LIKE ?
        LIMIT 50
    ");
    $stmt->bind_param("sss", $search_term, $search_term, $search_term);
    $stmt->execute();
    $result = $stmt->get_result();
    $search_results = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student Profiles - CEIT Guidance Office</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #FAF3E0;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .header {
            background-color: #F4A261;
            color: black;
            padding: 10px 20px;
            text-align: left;
            font-size: 24px;
            font-weight: bold;
        }
        .content-wrapper {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        .content {
            background-color: white;
            border: 2px solid #0f6a1a;
            border-radius: 10px;
            padding: 20px;
            max-width: 800px;
            width: 100%;
        }
        .btn-custom {
            background-color: #0f6a1a;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
        .btn-back {
            align-self: flex-start;
            background-color: #F4A261;
            color: black;
            border: none;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .btn-back:hover {
            background-color: #e76f51;
        }
        .form-group label {
            font-weight: bold;
            color: #004d4d;
        }
        .btn-primary {
            background-color: #0f6a1a;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
        }
        .btn-primary:hover {
            background-color:#218838;
        }
        #studentList {
            margin-top: 30px;
        }
        .footer {
            background-color: #F4A261;
            color: black;
            text-align: center;
            padding: 10px;
            width: 100%;
        }
        .search-container {
            margin-bottom: 20px;
        }
        #searchResults {
            margin-top: 20px;
        }
        .btn-analytics {
            background-color: #1A6E47;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            margin-bottom: 20px;
            transition: background-color 0.3s ease;
        }
        .btn-analytics:hover {
            background-color: #145A3A;
            color: white;
            text-decoration: none;
        }
        .action-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .btn-group .btn {
            margin: 0 2px;
        }
        .table td {
            vertical-align: middle !important;
        }
        .btn-info {
            background-color: #17a2b8;
            border-color: #17a2b8;
            color: white;
        }
        .btn-info:hover {
            background-color: #138496;
            border-color: #117a8b;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        CEIT - GUIDANCE OFFICE
        
    </div>

    <div class="content-wrapper">
        <div class="action-buttons">
            <a href="facilitator_homepage.php" class="btn btn-back">
                <i class="fas fa-arrow-left"></i> Back to Homepage
            </a>
            
        </div>
        <div class="content">
            <h2 class="text-center mb-4">View Student Profile Form Inventory</h2>
            
            <!-- Search form -->
            <div class="search-container">
                <form id="searchForm" action="" method="GET" class="form-inline justify-content-center">
                    <input type="text" name="search" id="searchInput" class="form-control mr-sm-2" placeholder="Search by ID, First Name, or Last Name" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
            </div>

            <!-- Display search results -->
            <div id="searchResults">
                <?php if (!empty($search_results)): ?>
                    <h3>Search Results</h3>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Department</th>
                                <th>Course</th>
                                <th>Year Level</th>
                                <th>Section</th>
                                <th style="width: 250px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($search_results as $student): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                    <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['department_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['course_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['year_level']); ?></td>
                                    <td><?php echo htmlspecialchars($student['section_no']); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="view_student_incident_history.php?student_id=<?php echo urlencode($student['student_id']); ?>" 
                                               class="btn btn-info btn-sm ml-1">
                                                <i class="fas fa-history"></i> View History
                                            </a>
                                            <a href="view_student_profile.php?student_id=<?php echo urlencode($student['student_id']); ?>&department_id=<?php echo urlencode($student['department_id']); ?>&course_id=<?php echo urlencode($student['course_id']); ?>&year_level=<?php echo urlencode($student['year_level']); ?>&section_id=<?php echo urlencode($student['section_id']); ?>" 
                                               class="btn btn-primary btn-sm">
                                                <i class="fas fa-user"></i> View Profile
                                            </a>
                                            
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php elseif (isset($_GET['search'])): ?>
                    <p class="text-center">No results found.</p>
                <?php endif; ?>
            </div>

            <!-- Existing form for department, course, and year level selection -->
            <form id="profileSelector" action="view_select_sections.php" method="GET">
                <div class="form-group">
                    <label for="department">Department:</label>
                    <select class="form-control" id="department" name="department_id" required>
                        <option value="">Select a department</option>
                        <?php foreach ($departments as $department): ?>
                            <option value="<?php echo $department['id']; ?>">
                                <?php echo htmlspecialchars($department['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="course">Course:</label>
                    <select class="form-control" id="course" name="course_id" required disabled>
                        <option value="">Select a course</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="year_level">Year Level:</label>
                    <select class="form-control" id="year_level" name="year_level" required disabled>
                        <option value="">Select a year level</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-custom btn-block">Next</button>
            </form>
        </div>
    </div>

    <div class="footer">
        Contact number | Email | Copyright
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {
            // Existing JavaScript for handling department, course, and year level selection
            $('#department').change(function() {
                var departmentId = $(this).val();
                if(departmentId) {
                    $.ajax({
                        url: 'get_data.php',
                        type: 'GET',
                        data: {action: 'get_courses', department_id: departmentId},
                        success: function(data) {
                            $('#course').html(data);
                            $('#course').prop('disabled', false);
                            $('#year_level').html('<option value="">Select a year level</option>');
                            $('#year_level').prop('disabled', true);
                        }
                    });
                } else {
                    $('#course').html('<option value="">Select a course</option>');
                    $('#course').prop('disabled', true);
                    $('#year_level').html('<option value="">Select a year level</option>');
                    $('#year_level').prop('disabled', true);
                }
            });

            $('#course').change(function() {
                var courseId = $(this).val();
                var departmentId = $('#department').val();
                if(courseId) {
                    $.ajax({
                        url: 'get_data.php',
                        type: 'GET',
                        data: {action: 'get_year_levels', department_id: departmentId, course_id: courseId},
                        success: function(data) {
                            $('#year_level').html(data);
                            $('#year_level').prop('disabled', false);
                        }
                    });
                } else {
                    $('#year_level').html('<option value="">Select a year level</option>');
                    $('#year_level').prop('disabled', true);
                }
            });

            // New JavaScript for handling search with AJAX
            $('#searchForm').submit(function(e) {
                e.preventDefault();
                var searchTerm = $('#searchInput').val();
                $.ajax({
                    url: 'get_data.php',
                    type: 'GET',
                    data: {action: 'search_students', search: searchTerm},
                    success: function(data) {
                        $('#searchResults').html(data);
                    }
                });
            });
        });
    </script>
</body>
</html>