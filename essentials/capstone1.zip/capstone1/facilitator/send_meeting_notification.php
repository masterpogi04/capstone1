<?php
session_start();
include '../db.php';
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: view_approved_reports.php");
    exit();
}

$report_id = $_POST['report_id'] ?? null;
$notification_type = $_POST['notification_type'] ?? '';
$adviser_message = $_POST['adviser_message'] ?? '';
$student_email_message = $_POST['student_email_message'] ?? '';
$sms_message = $_POST['sms_message'] ?? '';

if (!$report_id || !$notification_type) {
    die("Missing required parameters");
}

// Initialize PHPMailer
function setupMailer() {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'ceitguidanceoffice@gmail.com'; 
    $mail->Password = 'qapb ebhc owts ioel';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    $mail->setFrom('ceitguidanceoffice@gmail.com', 'CEIT Guidance Office');
    return $mail;
}

// Function to send SMS
function sendSMS($phoneNumber, $message) {
    $baseUrl = 'qdegk3.api.infobip.com';
    $apiKey = 'a16b18666a35b086606b44c04022de4f-60d793ce-bae3-4e9e-9118-eb5794edc95b'; //babaguhin if meron ng new free

    // Format phone number
    $phoneNumber = preg_replace('/[^0-9]/', '', $phoneNumber);
    if (substr($phoneNumber, 0, 1) === '0') {
        $phoneNumber = '+63' . substr($phoneNumber, 1);
    } elseif (substr($phoneNumber, 0, 2) !== '63') {
        $phoneNumber = '+63' . $phoneNumber;
    }

    $curl = curl_init();
    
    $payload = json_encode([
        "messages" => [
            [
                "destinations" => [["to" => $phoneNumber]],
                "from" => "CEIT-GUIDANCE",
                "text" => $message
            ]
        ]
    ]);

    curl_setopt_array($curl, [
        CURLOPT_URL => "https://" . $baseUrl . "/sms/2/text/advanced",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => [
            "Authorization: App " . $apiKey,
            "Content-Type: application/json",
            "Accept: application/json"
        ],
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload
    ]);

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    return !$err;
}

// Fetch relevant information
$query = "SELECT 
    s.student_id,
    s.first_name as student_fname,
    s.last_name as student_lname,
    sp.contact_number,
    sp.email as student_email,
    a.email as adviser_email,
    a.id as adviser_id,
    a.name as adviser_name,
    m.meeting_date,
    m.venue
    FROM incident_reports ir
    JOIN student_violations sv ON ir.id = sv.incident_report_id
    JOIN tbl_student s ON sv.student_id = s.student_id
    LEFT JOIN student_profiles sp ON s.student_id = sp.student_id
    LEFT JOIN sections sec ON s.section_id = sec.id
    LEFT JOIN tbl_adviser a ON sec.adviser_id = a.id
    LEFT JOIN meetings m ON ir.id = m.incident_report_id
    WHERE ir.id = ?";

$stmt = $connection->prepare($query);
$stmt->bind_param("s", $report_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

$success = true;
$errors = [];

switch($notification_type) {
    case 'adviser':
        if (!empty($data['adviser_email']) && !empty($adviser_message)) {
            try {
                $mail = setupMailer();
                $mail->addAddress($data['adviser_email']);
                $mail->isHTML(false);
                $mail->Subject = 'Student Meeting Notification';
                $mail->Body = $adviser_message;
                $mail->send();
                
                // Create notification for adviser
                $adviserNotifQuery = "INSERT INTO notifications (user_type, user_id, message, link) 
                                    VALUES (?, ?, ?, ?)";
                $stmt = $connection->prepare($adviserNotifQuery);
                $user_type = 'adviser';
                $notif_message = "Meeting notification sent for student " . $data['student_fname'] . " " . $data['student_lname'];
                $link = "view_meeting_details.php?id=" . $report_id;
                $stmt->bind_param("ssss", $user_type, $data['adviser_id'], $notif_message, $link);
                $stmt->execute();
            } catch (Exception $e) {
                $success = false;
                $errors[] = "Failed to send email to adviser: " . $e->getMessage();
            }
        }
        break;

    case 'student_email':
        if (!empty($data['student_email']) && !empty($student_email_message)) {
            try {
                $mail = setupMailer();
                $mail->addAddress($data['student_email']);
                $mail->isHTML(false);
                $mail->Subject = 'Meeting Schedule';
                $mail->Body = $student_email_message;
                $mail->send();
            } catch (Exception $e) {
                $success = false;
                $errors[] = "Failed to send email to student: " . $e->getMessage();
            }
        }
        break;

    case 'sms':
        if (!empty($data['contact_number']) && !empty($sms_message)) {
            if (!sendSMS($data['contact_number'], $sms_message)) {
                $success = false;
                $errors[] = "Failed to send SMS to student";
            }
        }
        break;
}

// Create notification for student if email or SMS was sent successfully
if ($success && ($notification_type == 'student_email' || $notification_type == 'sms')) {
    try {
        $studentNotifQuery = "INSERT INTO notifications (user_type, user_id, message, link) 
                             VALUES (?, ?, ?, ?)";
        $stmt = $connection->prepare($studentNotifQuery);
        $user_type = 'student';
        $notif_message = "You have a scheduled meeting on " . date('F j, Y \a\t g:i A', strtotime($data['meeting_date']));
        $link = "view_meeting_details.php?id=" . $report_id;
        $stmt->bind_param("ssss", $user_type, $data['student_id'], $notif_message, $link);
        $stmt->execute();
    } catch (Exception $e) {
        $success = false;
        $errors[] = "Failed to create student notification: " . $e->getMessage();
    }
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode([
    'success' => $success,
    'message' => $success ? 'Notification sent successfully' : 'Failed to send notification',
    'errors' => $errors
]);
?>