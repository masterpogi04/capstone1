<?php
session_start();
include '../db.php';

// Check if the user is logged in as a facilitator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'facilitator') {
    header("Location: login.php");
    exit();
}

$report_id = isset($_GET['report_id']) ? $_GET['report_id'] : null;

// In compose_meeting_notification.php, modify the query to get latest meeting
$query = "SELECT 
    ir.id as report_id,
    ir.date_reported,
    ir.description,
    s.student_id,
    s.first_name as student_fname,
    s.last_name as student_lname,
    sp.contact_number,
    sp.email as student_email,
    a.email as adviser_email,
    a.name as adviser_name,
    m.meeting_date,
    m.venue
    FROM incident_reports ir
    JOIN student_violations sv ON ir.id = sv.incident_report_id
    JOIN tbl_student s ON sv.student_id = s.student_id
    LEFT JOIN student_profiles sp ON s.student_id = sp.student_id
    LEFT JOIN sections sec ON s.section_id = sec.id
    LEFT JOIN tbl_adviser a ON sec.adviser_id = a.id
    LEFT JOIN meetings m ON ir.id = m.incident_report_id
    WHERE ir.id = ?
    ORDER BY m.meeting_date DESC LIMIT 1";  

$stmt = $connection->prepare($query);
$stmt->bind_param("s", $report_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if (!$data) {
    die("Report not found");
}

// Format meeting date and time for display
$meeting_datetime = new DateTime($data['meeting_date']);
$formatted_date = $meeting_datetime->format('F j, Y');
$formatted_time = $meeting_datetime->format('g:i A');

// Adviser email template
$default_message = "Dear {$data['adviser_name']},\n\n";
$default_message .= "I hope this email finds you well. This is to inform you that your advisee, {$data['student_fname']} {$data['student_lname']}, ";
$default_message .= "has a scheduled meeting at the Guidance Office.\n\n";
$default_message .= "Meeting Details:\n";
$default_message .= "Date: {$formatted_date}\n";
$default_message .= "Time: {$formatted_time}\n";
$default_message .= "Venue: {$data['venue']}\n\n";
$default_message .= "Please ensure that the student is informed and will attend this important meeting.\n\n";
$default_message .= "Best regards,\nCEIT Guidance Office";

// Student email template
$student_email_message = "Dear {$data['student_fname']},\n\n";
$student_email_message .= "This is to inform you that you have a scheduled meeting at the Guidance Office.\n\n";
$student_email_message .= "Meeting Details:\n";
$student_email_message .= "Date: {$formatted_date}\n";
$student_email_message .= "Time: {$formatted_time}\n";
$student_email_message .= "Venue: {$data['venue']}\n\n";
$student_email_message .= "Please ensure to attend this important meeting.\n\n";
$student_email_message .= "Best regards,\nCEIT Guidance Office";

// SMS template (shorter version)
$sms_message = "Hi {$data['student_fname']}, you have a scheduled meeting at CEIT Guidance Office on {$formatted_date} at {$formatted_time}. Please be on time.";

// Add this after fetching the data
if (empty($data['meeting_date'])) {
    $_SESSION['error_message'] = "No active meeting found for this report.";
    header("Location: view_approved_reports.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compose Meeting Notification</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: linear-gradient(135deg, #0d693e, #004d4d);
            min-height: 100vh;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            margin: 0;
            color: #333;
        }
        .container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            margin-top: 50px;
            margin-bottom: 50px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .btn-secondary {
            background-color: #F4A261;
            border-color: #F4A261;
            color: #fff;
            padding: 10px 20px;
        }
        .btn-secondary:hover {
            background-color: #E76F51;
            border-color: #E76F51;
        }
        .notification-details {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9em;
        }
        .status-badge.has-contact {
            background-color: #28a745;
            color: white;
        }
        .status-badge.no-contact {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
    <div class="row mb-4">
    <div class="col">
        <a href="schedule_generator.php?report_id=<?php echo $report_id; ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Schedule
        </a>
    </div>
</div>

        <h2 class="mb-4">Compose Meeting Notification</h2>

        <div class="notification-details">
            <h4>Student Information</h4>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($data['student_fname'] . ' ' . $data['student_lname']); ?></p>
            <p>
                <strong>Contact:</strong> 
                <?php if (!empty($data['contact_number'])): ?>
                    <span class="status-badge has-contact">
                        <i class="fas fa-phone"></i> <?php echo htmlspecialchars($data['contact_number']); ?>
                    </span>
                <?php else: ?>
                    <span class="status-badge no-contact">No contact number available</span>
                <?php endif; ?>
            </p>
            <p>
                <strong>Email:</strong>
                <?php if (!empty($data['student_email'])): ?>
                    <span class="status-badge has-contact">
                        <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($data['student_email']); ?>
                    </span>
                <?php else: ?>
                    <span class="status-badge no-contact">No email available</span>
                <?php endif; ?>
            </p>
        </div>

        <div class="notification-details">
            <h4>Adviser Information</h4>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($data['adviser_name']); ?></p>
            <p>
                <strong>Email:</strong>
                <?php if (!empty($data['adviser_email'])): ?>
                    <span class="status-badge has-contact">
                        <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($data['adviser_email']); ?>
                    </span>
                <?php else: ?>
                    <span class="status-badge no-contact">No email available</span>
                <?php endif; ?>
            </p>
        </div>

        <form id="notificationForm" action="send_meeting_notification.php" method="POST">
            <input type="hidden" name="report_id" value="<?php echo $report_id; ?>">
            
            <?php if (!empty($data['adviser_email'])): ?>
                <div class="notification-section mb-4">
                    <h4>Adviser Email Notification</h4>
                    <div class="form-group">
                        <label>Email to: <?php echo htmlspecialchars($data['adviser_email']); ?></label>
                        <textarea class="form-control" name="adviser_message" rows="8" required><?php echo htmlspecialchars($default_message); ?></textarea>
                        <button type="button" class="btn btn-primary mt-2" onclick="sendNotification('adviser')">
                            <i class="fas fa-envelope"></i> Send to Adviser
                        </button>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($data['student_email'])): ?>
                <div class="notification-section mb-4">
                    <h4>Student Email Notification</h4>
                    <div class="form-group">
                        <label>Email to: <?php echo htmlspecialchars($data['student_email']); ?></label>
                        <textarea class="form-control" name="student_email_message" rows="8"><?php echo htmlspecialchars($student_email_message); ?></textarea>
                        <button type="button" class="btn btn-primary mt-2" onclick="sendNotification('student_email')">
                            <i class="fas fa-envelope"></i> Send Email to Student
                        </button>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($data['contact_number'])): ?>
                <div class="notification-section mb-4">
                    <h4>Student SMS Notification</h4>
                    <div class="form-group">
                        <label>SMS to: <?php echo htmlspecialchars($data['contact_number']); ?></label>
                        <textarea class="form-control" name="sms_message" rows="4"><?php echo htmlspecialchars($sms_message); ?></textarea>
                        <small class="form-text text-muted">SMS messages should be brief and concise</small>
                        <button type="button" class="btn btn-primary mt-2" onclick="sendNotification('sms')">
                            <i class="fas fa-sms"></i> Send SMS to Student
                        </button>
                    </div>
                </div>
            <?php endif; ?>
        </form>
    </div>

   <script>
function sendNotification(type) {
    Swal.fire({
        title: 'Send Notification?',
        text: 'Are you sure you want to send this notification?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, send it!',
        showLoaderOnConfirm: true,
        preConfirm: () => {
            const formData = new FormData(document.getElementById('notificationForm'));
            formData.append('notification_type', type);
            
            return fetch('send_meeting_notification.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    throw new Error(data.message || 'Failed to send notification');
                }
                return data;
            });
        }
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                title: 'Success!',
                text: 'Notification sent successfully',
                icon: 'success'
            });
        }
    }).catch(error => {
        Swal.fire({
            title: 'Error!',
            text: error.message,
            icon: 'error'
        });
    });
}
</script>
</body>
</html>