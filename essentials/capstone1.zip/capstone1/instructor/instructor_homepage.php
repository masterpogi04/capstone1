<?php
session_start();
include '../db.php'; // Ensure database connection is established

// Ensure the user is logged in and is an instructor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

// Get the instructor's ID from the session
$instructor_id = $_SESSION['user_id'];

// Fetch the instructor's details from the database
$stmt = $connection->prepare("SELECT name, profile_picture FROM tbl_instructor WHERE id = ?");
if ($stmt === false) {
    die("Prepare failed: " . $connection->error); // Output the error message
}
$stmt->bind_param("i", $instructor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $instructor = $result->fetch_assoc();
    $name = $instructor['name'];
    $profile_picture = $instructor['profile_picture'];
} else {
    die("Instructor not found.");
}

mysqli_close($connection);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CEIT - Guidance Office</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        body {
            background-color: #FAF3E0;
            font-family: Arial;
        }
        .sidebar {
            height: 100vh;
            background-color: #1A6E47;
            color: white;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            display: block;
            padding: 10px 15px;
            text-decoration: none;
        }
        .sidebar a:hover, .sidebar a.active {
            background-color: #F2A54B;
        }
        .header {
            background-color: #F4A261;
            padding: 10px;
            color: black;
            font-family: Arial;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .main-content {
            padding: 0;
            position: relative;
            min-height: 100vh;
        }  
        .welcome-text {
            position: relative;
            background-image: url('cvsu1.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 50px;
            text-align: left;
            margin-bottom: 20px;
        }
        .welcome-text::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 128, 0, 0.7);
            z-index: 0;
        }
        .welcome-text h2, .welcome-text h3 {
            position: relative;
            z-index: 1;
        }
        .h2 {
            font-family: serif;
            font-size: 60px;
            font-weight: 700;
        }
        h3 {
            font-family: serif;
            font-size: 40px;
        }
        .manage-buttons {
            display: flex;
            justify-content: center;
            padding: 20px;
        }
        .manage-buttons a {
            margin: 0 10px;
        }
        .manage-buttons button {
            background-color: #0f6a1a;
            color: white;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s, transform 0.3s;
        }
        .manage-buttons button:hover {
            background-color: #218838;
            transform: translateY(-3px);
        }
        .footer {
            background-color: #F4A261;
            padding: 10px;
            color: black;
            text-align: center;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
        .profile-section {
            display: flex;
            align-items: center;
            flex-direction: column;
            padding: 15px;
        }
        .profile-section img {
            margin-top: 20px;
            width: 100px;
            height: 100px;
            border: 2px solid white;
            border-radius: 50%;
        }
        .profile-section p {
            margin-top: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 sidebar">
                <div class="profile-section text-center">
                    <img src="<?php echo htmlspecialchars($profile_picture); ?>" class="rounded-circle" alt="Profile Picture">
                    <p><?php echo htmlspecialchars($name); ?></p>
                </div>
                <a href="instructor_homepage.php">Home</a>
                <a href="instructor_myprofile.php">My Profile</a>
                <a href="help_support_instructor.php">Help & Support</a>
                <a class="nav-link" href="../login.php" onclick="return confirm('Are you sure you want to log out?')">Log Out</a>
            </nav>
            <main class="col-md-10 main-content">
                <div class="header">
                    <h1>CEIT - GUIDANCE OFFICE</h1>
                    <i class="fa fa-bell" style="font-size:36px;color:WHITE"></i>
                </div>
                <div class="welcome-text">
                    <h2 class='h2'>WELCOME, CEIT <?php echo htmlspecialchars($name); ?>!!</h2>
                </div>
               <div class="manage-buttons">

                    <a href="instructor_incident_report.php"><button>Submit Student Violation</button></a>
                    <a href="view_incident_reports.php"><button>View Submitted Student Violation</button></a>
                   
                </div>
                <div class="footer">
                   <p>&copy; 2024 All Rights Reserved</p> 
                </div>
            </main>
        </div>
    </div>
</body>
</html>
