<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['token']) && isset($_GET['table'])) {
    $token = $_GET['token'];
    $table = $_GET['table'];
    
    // Verify token and check if it's still valid
    $stmt = $connection->prepare("SELECT " . ($table === 'tbl_student' ? 'student_id' : 'id') . " FROM $table WHERE reset_token = ? AND reset_token_expires > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        $error_message = "Invalid or expired token.";
    }
} elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $table = $_POST['table'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    
    // Update password and clear token
    $stmt = $connection->prepare("UPDATE $table SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE reset_token = ?");
    $stmt->bind_param("ss", $new_password, $token);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        $message = "Your password has been successfully reset. You can now login with your new password.";
    } else {
        $error_message = "Password reset failed. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - CEIT Guidance Office</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #00a85a, #004d4d);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #333;
        }
        .header {
            background-color: #ff7f00;
            color: #000;
            text-align: center;
            padding: 15px 0;
            font-size: 28px;
            font-family: 'Georgia', serif;
            letter-spacing: 7px;
            font-weight: bold;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .content-wrapper {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
            width: 350px;
            text-align: center;
            transition: transform 0.3s ease;
        }
        .container:hover {
            transform: translateY(-5px);
        }
        h2 {
            color: #00a85a;
            margin-bottom: 25px;
            font-size: 28px;
        }
        input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 2px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }
        input[type="password"]:focus {
            border-color: #00a85a;
            outline: none;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #00a85a;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }
        button:hover {
            background-color: #008c4a;
        }
        button:active {
            transform: scale(0.98);
        }
        .message {
            margin-top: 20px;
            color: #00a85a;
            font-weight: bold;
            padding: 10px;
            border-radius: 4px;
            background-color: #e8f5e9;
        }
        .error {
            margin-top: 20px;
            color: #ff0000;
            font-weight: bold;
            padding: 10px;
            border-radius: 4px;
            background-color: #ffebee;
        }
        .login-link {
            display: inline-block;
            margin-top: 20px;
            color: #00a85a;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .login-link:hover {
            color: #ff7f00;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">CAVITE STATE UNIVERSITY-MAIN</div>
    <div class="content-wrapper">
        <div class="container">
            <h2>Reset Password</h2>
            <?php if (isset($message)): ?>
                <p class="message"><?php echo $message; ?></p>
            <?php elseif (isset($error_message)): ?>
                <p class="error"><?php echo $error_message; ?></p>
            <?php else: ?>
                <form method="post" onsubmit="return validatePassword()">
                    <input type="hidden" name="token" value="<?php echo $token; ?>">
                    <input type="hidden" name="table" value="<?php echo $table; ?>">
                    <input type="password" id="new_password" name="new_password" placeholder="New Password" required>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm New Password" required>
                    <button type="submit">Reset Password</button>
                </form>
            <?php endif; ?>
            <a href="login.php" class="login-link">Back to Login</a>
        </div>
    </div>

    <script>
    function validatePassword() {
        var newPassword = document.getElementById("new_password").value;
        var confirmPassword = document.getElementById("confirm_password").value;
        if (newPassword != confirmPassword) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
    }
    </script>
</body>
</html>