-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2024 at 04:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capstone1`
--

-- --------------------------------------------------------

--
-- Table structure for table `cavite_barangays`
--

CREATE TABLE `cavite_barangays` (
  `id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `barangay_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cavite_barangays`
--

INSERT INTO `cavite_barangays` (`id`, `city_id`, `barangay_name`) VALUES
(1, 2, 'Banaybanay'),
(2, 2, 'Barangay 1'),
(3, 2, 'Barangay 2'),
(4, 2, 'Barangay 3'),
(5, 2, 'Barangay 4'),
(6, 2, 'Barangay 5'),
(7, 2, 'Barangay 6'),
(8, 2, 'Barangay 7'),
(9, 2, 'Barangay 8'),
(10, 2, 'Barangay 9'),
(11, 2, 'Barangay 10'),
(12, 2, 'Barangay 11'),
(13, 2, 'Barangay 12'),
(14, 2, 'Bucal'),
(15, 2, 'Buho'),
(16, 2, 'Dagatan'),
(17, 2, 'Halang'),
(18, 2, 'Loma'),
(19, 2, 'Maitim 1'),
(20, 2, 'Maymangga'),
(21, 2, 'Minantok Kanluran'),
(22, 2, 'Minantok Silangan'),
(23, 2, 'Pangil'),
(24, 2, 'Poblacion 1'),
(25, 2, 'Poblacion 2'),
(26, 2, 'Salaban'),
(27, 2, 'Talon'),
(28, 2, 'Tamacan'),
(32, 1, 'Amuyong'),
(33, 1, 'Barangay 1'),
(34, 1, 'Barangay 2'),
(35, 1, 'Barangay 3'),
(36, 1, 'Barangay 4'),
(37, 1, 'Barangay 5'),
(38, 1, 'Bilog'),
(39, 1, 'Buck Estate'),
(40, 1, 'Esperanza, Ibaba'),
(41, 1, 'Esperanza, Ilaya'),
(42, 1, 'Kaysuyo'),
(43, 1, 'Kaytitinga 1'),
(44, 1, 'Kaytitinga 2'),
(45, 1, 'Kaytitinga 3'),
(46, 1, 'Luksuhin'),
(47, 1, 'Luksuhin Ilaya'),
(48, 1, 'Mangas 1'),
(49, 1, 'Mangas 2'),
(50, 1, 'Marahan 1'),
(51, 1, 'Marahan 2'),
(52, 1, 'Matagbak 1'),
(53, 1, 'Matagbak 2'),
(54, 1, 'Pajo'),
(55, 1, 'Palumlum'),
(56, 1, 'Santa Teresa'),
(57, 1, 'Sikat'),
(58, 1, 'Sinaliw Malaki'),
(59, 1, 'Sinaliw na Munti'),
(60, 1, 'Sulsugin'),
(61, 1, 'Taywanak Ibaba'),
(62, 1, 'Taywanak Ilaya'),
(63, 1, 'Upli'),
(64, 3, 'Aniban I'),
(65, 3, 'Aniban II'),
(66, 3, 'Aniban III'),
(67, 3, 'Banalo'),
(68, 3, 'Bayanan'),
(69, 3, 'Campo Santo'),
(70, 3, 'Dulong Bayan'),
(71, 3, 'Habay I'),
(72, 3, 'Kaingin'),
(73, 3, 'Ligas I'),
(74, 3, 'Ligas II'),
(75, 3, 'Mabolo I'),
(76, 3, 'Mabolo II'),
(77, 3, 'Maliksi I'),
(78, 3, 'Maliksi II'),
(79, 3, 'Maliksi III'),
(80, 3, 'Mambog I'),
(81, 3, 'Mambog II'),
(82, 3, 'Mambog III'),
(83, 3, 'Molino I'),
(84, 3, 'Molino II'),
(85, 3, 'Molino III'),
(86, 3, 'Niog I'),
(87, 3, 'Niog II'),
(88, 3, 'P. F. Espiritu I'),
(89, 3, 'P. F. Espiritu II'),
(90, 3, 'P. F. Espiritu III'),
(91, 3, 'Queens Row Central'),
(92, 3, 'Queens Row East'),
(93, 3, 'Real I'),
(94, 3, 'Real II'),
(95, 3, 'Salinas I'),
(96, 3, 'Salinas II'),
(97, 3, 'San Nicolas I'),
(98, 3, 'San Nicolas II'),
(99, 3, 'Sineguelasan'),
(100, 3, 'Tabing Dagat'),
(101, 3, 'Talaba I'),
(102, 3, 'Talaba II'),
(103, 3, 'Talaba III'),
(104, 3, 'Talaba IV'),
(105, 3, 'Talaba V'),
(106, 3, 'Zapote I'),
(107, 3, 'Zapote II'),
(108, 3, 'Zapote III'),
(109, 3, 'Zapote IV'),
(110, 3, 'Zapote V'),
(127, 4, 'Bancal'),
(128, 4, 'Barangay 1'),
(129, 4, 'Barangay 2'),
(130, 4, 'Barangay 3'),
(131, 4, 'Barangay 4'),
(132, 4, 'Barangay 5'),
(133, 4, 'Barangay 6'),
(134, 4, 'Barangay 7'),
(135, 4, 'Barangay 8'),
(136, 4, 'Cabilang Baybay'),
(137, 4, 'Lantic'),
(138, 4, 'Mabuhay'),
(139, 4, 'Maduya'),
(140, 4, 'Milagrosa'),
(142, 5, 'Barangay 1'),
(143, 5, 'Barangay 10'),
(144, 5, 'Barangay 10-A'),
(145, 5, 'Barangay 10-B'),
(146, 5, 'Barangay 11'),
(147, 5, 'Barangay 12'),
(148, 5, 'Barangay 13'),
(149, 5, 'Barangay 14'),
(150, 5, 'Barangay 15'),
(151, 5, 'Barangay 16'),
(152, 5, 'Barangay 17'),
(153, 5, 'Barangay 18'),
(154, 5, 'Barangay 19'),
(155, 5, 'Barangay 2'),
(156, 5, 'Barangay 20'),
(157, 5, 'Barangay 21'),
(158, 5, 'Barangay 23'),
(159, 5, 'Barangay 24'),
(160, 5, 'Barangay 25'),
(161, 5, 'Barangay 26'),
(162, 5, 'Barangay 27'),
(163, 5, 'Barangay 28'),
(164, 5, 'Barangay 3'),
(165, 5, 'Barangay 30'),
(166, 5, 'Barangay 31'),
(167, 5, 'Barangay 32'),
(168, 5, 'Barangay 33'),
(169, 5, 'Barangay 34'),
(170, 5, 'Barangay 35'),
(171, 5, 'Barangay 4'),
(172, 5, 'Barangay 41'),
(173, 5, 'Barangay 42'),
(174, 5, 'Barangay 43'),
(175, 5, 'Barangay 44'),
(176, 5, 'Barangay 45'),
(177, 5, 'Barangay 5'),
(178, 5, 'Barangay 50'),
(179, 5, 'Barangay 51'),
(180, 5, 'Barangay 52'),
(181, 5, 'Barangay 53'),
(182, 5, 'Barangay 54'),
(183, 5, 'Barangay 55'),
(184, 5, 'Barangay 6'),
(185, 5, 'Barangay 60'),
(186, 5, 'Barangay 61'),
(187, 5, 'Barangay 62'),
(188, 5, 'Barangay 62-A'),
(189, 5, 'Barangay 7'),
(190, 5, 'Barangay 8'),
(191, 5, 'Barangay 9'),
(205, 6, 'Burol'),
(206, 6, 'Burol I'),
(207, 6, 'Burol II'),
(208, 6, 'Datu Esmael'),
(209, 6, 'Emmanuel Bergado I'),
(210, 6, 'Emmanuel Bergado II'),
(211, 6, 'Fatima I'),
(212, 6, 'Fatima II'),
(213, 6, 'H-2'),
(214, 6, 'Langkaan I'),
(215, 6, 'Langkaan II'),
(216, 6, 'Luzviminda I'),
(217, 6, 'Luzviminda II'),
(218, 6, 'Paliparan I'),
(219, 6, 'Paliparan II'),
(220, 6, 'Sabang'),
(221, 6, 'Saint Peter I'),
(222, 6, 'Saint Peter II'),
(223, 6, 'Salawag'),
(224, 6, 'Salitran I'),
(225, 6, 'Salitran II'),
(226, 6, 'Salitran III'),
(227, 6, 'Sampaloc I'),
(228, 6, 'Sampaloc II'),
(229, 6, 'Sampaloc III'),
(230, 6, 'Sampaloc IV'),
(231, 6, 'San Agustin I'),
(232, 6, 'San Agustin II'),
(233, 6, 'San Andres I'),
(234, 6, 'San Andres II'),
(235, 6, 'San Antonio de Padua I'),
(236, 6, 'San Antonio de Padua II'),
(237, 6, 'San Dionisio'),
(238, 6, 'San Esteban'),
(239, 6, 'San Isidro Labrador I'),
(240, 6, 'San Isidro Labrador II'),
(241, 6, 'San Jose'),
(242, 6, 'San Lorenzo Ruiz I'),
(243, 6, 'San Lorenzo Ruiz II'),
(244, 6, 'San Nicolas I'),
(245, 6, 'San Nicolas II'),
(246, 6, 'Santa Cruz I'),
(247, 6, 'Santa Fe'),
(248, 6, 'Santa Lucia'),
(249, 6, 'Santo Cristo'),
(250, 6, 'Victoria Reyes'),
(251, 6, 'Zone I'),
(252, 6, 'Zone II'),
(253, 6, 'Zone III'),
(268, 7, 'Alingaro'),
(269, 7, 'Arnaldo'),
(270, 7, 'Bacao I'),
(271, 7, 'Bacao II'),
(272, 7, 'Bagumbayan'),
(273, 7, 'Biclatan'),
(274, 7, 'Buenavista I'),
(275, 7, 'Buenavista II'),
(276, 7, 'Gov. Ferrer Poblacion'),
(277, 7, 'Javalera'),
(278, 7, 'Manggahan'),
(279, 7, 'Navarro'),
(280, 7, 'Panungyanan'),
(281, 7, 'Pasong Camachile I'),
(282, 7, 'Pasong Camachile II'),
(283, 7, 'Pasong Kawayan I'),
(284, 7, 'Pinagtipunan'),
(285, 7, 'Prinza Poblacion'),
(286, 7, 'San Francisco'),
(287, 7, 'San Juan I'),
(288, 7, 'San Juan II'),
(289, 7, 'Santa Clara'),
(290, 7, 'Santiago'),
(291, 7, 'Tapia'),
(292, 7, 'Tejero'),
(293, 7, 'Vibora Poblacion'),
(299, 8, 'Alapan I-A'),
(300, 8, 'Alapan I-B'),
(301, 8, 'Alapan I-C'),
(302, 8, 'Alapan II-A'),
(303, 8, 'Alapan II-B'),
(304, 8, 'Anabu I-A'),
(305, 8, 'Anabu I-B'),
(306, 8, 'Anabu I-C'),
(307, 8, 'Anabu I-D'),
(308, 8, 'Anabu I-E'),
(309, 8, 'Anabu II-A'),
(310, 8, 'Anabu II-B'),
(311, 8, 'Anabu II-C'),
(312, 8, 'Anabu II-D'),
(313, 8, 'Bayan Luma I'),
(314, 8, 'Bayan Luma II'),
(315, 8, 'Bayan Luma III'),
(316, 8, 'Bayan Luma IV'),
(317, 8, 'Bayan Luma V'),
(318, 8, 'Bucandala I'),
(319, 8, 'Bucandala II'),
(320, 8, 'Bucandala III'),
(321, 8, 'Bucandala IV'),
(322, 8, 'Buhay na Tubig'),
(323, 8, 'Maharlika'),
(324, 8, 'Malagasang I-A'),
(325, 8, 'Malagasang I-B'),
(326, 8, 'Malagasang I-C'),
(327, 8, 'Malagasang I-D'),
(328, 8, 'Malagasang II-A'),
(329, 8, 'Malagasang II-B'),
(330, 8, 'Malagasang II-C'),
(331, 8, 'Malagasang II-D'),
(332, 8, 'Mariano Espeleta I'),
(333, 8, 'Mariano Espeleta II'),
(334, 8, 'Medicion I-A'),
(335, 8, 'Medicion I-B'),
(336, 8, 'Medicion I-C'),
(337, 8, 'Medicion II-A'),
(338, 8, 'Medicion II-B'),
(339, 8, 'Medicion II-C'),
(340, 8, 'Medicion II-D'),
(341, 8, 'Pag-Asa I'),
(342, 8, 'Pag-Asa II'),
(343, 8, 'Palico I'),
(344, 8, 'Palico II'),
(345, 8, 'Pasong Buaya I'),
(346, 8, 'Pasong Buaya II'),
(347, 8, 'Poblacion I-A'),
(348, 8, 'Poblacion I-B'),
(349, 8, 'Poblacion I-C'),
(350, 8, 'Poblacion II-A'),
(351, 8, 'Poblacion II-B'),
(352, 8, 'Poblacion III-A'),
(353, 8, 'Poblacion III-B'),
(354, 8, 'Poblacion IV-A'),
(355, 8, 'Poblacion IV-B'),
(356, 8, 'Poblacion IV-C'),
(357, 8, 'Tanzang Luma I'),
(358, 8, 'Tanzang Luma II'),
(359, 8, 'Tanzang Luma III'),
(360, 8, 'Tanzang Luma IV'),
(361, 8, 'Tanzang Luma VI'),
(362, 8, 'Toclong I-A'),
(363, 8, 'Toclong I-B'),
(364, 8, 'Toclong I-C'),
(365, 8, 'Toclong II-A'),
(366, 8, 'Toclong II-B'),
(426, 9, 'Asisan'),
(427, 9, 'Bagong Tubig'),
(428, 9, 'Calabuso'),
(429, 9, 'Dapdap East'),
(430, 9, 'Dapdap West'),
(431, 9, 'Francisco'),
(432, 9, 'Guinhawa North'),
(433, 9, 'Guinhawa South'),
(434, 9, 'Iruhin East'),
(435, 9, 'Iruhin South'),
(436, 9, 'Iruhin West'),
(437, 9, 'Kaybagal East'),
(438, 9, 'Kaybagal North'),
(439, 9, 'Kaybagal South'),
(440, 9, 'Mag-Asawang Ilat'),
(441, 9, 'Maharlika East'),
(442, 9, 'Maharlika West'),
(443, 9, 'Maitim 2nd Central'),
(444, 9, 'Maitim 2nd West'),
(445, 9, 'Mendez Crossing East'),
(446, 9, 'Mendez Crossing West'),
(447, 9, 'NeoganI'),
(448, 9, 'Patutong Malaki North'),
(449, 9, 'Patutong Malaki South'),
(450, 9, 'Sambong'),
(451, 9, 'Silang Junction North'),
(452, 9, 'Silang Junction South'),
(453, 9, 'Sungay North'),
(454, 9, 'Sungay South'),
(455, 9, 'Tolentino East'),
(456, 9, 'Tolentino West'),
(457, 9, 'Zambal'),
(489, 10, 'Aguado'),
(490, 10, 'Cabezas'),
(491, 10, 'Cabuco'),
(492, 10, 'Conchu'),
(493, 10, 'De Ocampo'),
(494, 10, 'Gregorio'),
(495, 10, 'Inocencio'),
(496, 10, 'Lallana'),
(497, 10, 'Lapidario'),
(498, 10, 'Luciano'),
(499, 10, 'Osorio'),
(500, 10, 'Perez'),
(501, 10, 'San Agustin'),
(504, 11, 'Aldiano Olaes'),
(505, 11, 'Barangay 1 Poblacion'),
(506, 11, 'Barangay 2 Poblacion'),
(507, 11, 'Barangay 3 Poblacion'),
(508, 11, 'Barangay 4 Poblacion'),
(509, 11, 'Barangay 5 Poblacion'),
(510, 11, 'Benjamin Tirona'),
(511, 11, 'Epifanio Malia'),
(512, 11, 'Fiorello Calimag'),
(513, 11, 'Francisco de Castro'),
(514, 11, 'Gavino Maderan'),
(515, 11, 'Gregoria de Jesus'),
(516, 11, 'Inocencio Salud'),
(517, 11, 'Jacinto Lumbreras'),
(518, 11, 'Kapitan Kua'),
(519, 11, 'Marcelino Memije'),
(520, 11, 'Nicolasa Virata'),
(521, 11, 'Pantaleon Granados'),
(522, 11, 'Ramon Cruz'),
(523, 11, 'San Gabriel'),
(524, 11, 'San Jose'),
(525, 11, 'Severino de Las Alas'),
(526, 11, 'Tiniente Tiago'),
(535, 12, 'A. Dalusag'),
(536, 12, 'Batas Dao'),
(537, 12, 'Cabuco'),
(538, 12, 'Castaños Cerca'),
(539, 12, 'Castaños Lejos'),
(540, 12, 'Kabulusan'),
(541, 12, 'Kaymisas'),
(542, 12, 'Lumipa'),
(543, 12, 'Narvaez'),
(544, 12, 'Poblacion I'),
(545, 12, 'Poblacion II'),
(546, 12, 'Poblacion III'),
(547, 12, 'Poblacion IV'),
(548, 12, 'Tabora'),
(550, 13, 'Agus-us'),
(551, 13, 'Alulod'),
(552, 13, 'Banaba Cerca'),
(553, 13, 'Banaba Lejos'),
(554, 13, 'Bancod'),
(555, 13, 'Barangay 1'),
(556, 13, 'Barangay 2'),
(557, 13, 'Barangay 3'),
(558, 13, 'Barangay 4'),
(559, 13, 'Buna Cerca'),
(560, 13, 'Buna Lejos I'),
(561, 13, 'Buna Lejos II'),
(562, 13, 'Calumpang Cerca'),
(563, 13, 'Calumpang Lejos I'),
(564, 13, 'Carasuchi'),
(565, 13, 'Daine I'),
(566, 13, 'Daine II'),
(567, 13, 'Guyam Malaki'),
(568, 13, 'Guyam Munti'),
(569, 13, 'Harasan'),
(570, 13, 'Kayquit I'),
(571, 13, 'Kayquit II'),
(572, 13, 'Kayquit III'),
(573, 13, 'Kaytambog'),
(574, 13, 'Kaytapos'),
(575, 13, 'Limbon'),
(576, 13, 'Lumampong Balagbag'),
(577, 13, 'Lumampong Halayhay'),
(578, 13, 'Mahabangkahoy Cerca'),
(579, 13, 'Mahabangkahoy Lejos'),
(580, 13, 'Mataas na Lupa'),
(581, 13, 'Pulo'),
(582, 13, 'Tambo Balagbag'),
(583, 13, 'Tambo Ilaya'),
(584, 13, 'Tambo Kulit'),
(585, 13, 'Tambo Malaki'),
(613, 14, 'Balsahan-Bisita'),
(614, 14, 'Batong Dalig'),
(615, 14, 'Binakayan-Aplaya'),
(616, 14, 'Binakayan-Kanluran'),
(617, 14, 'Congbalay-Legaspi'),
(618, 14, 'Gahak'),
(619, 14, 'Kaingen'),
(620, 14, 'Magdalo'),
(621, 14, 'Manggahan-Lawin'),
(622, 14, 'Panamitan'),
(623, 14, 'Pulvorista'),
(624, 14, 'Samala-Marquez'),
(625, 14, 'San Sebastian'),
(626, 14, 'Santa Isabel'),
(627, 14, 'Tabon I'),
(628, 14, 'Tabon II'),
(629, 14, 'Tabon III'),
(630, 14, 'Toclong'),
(631, 14, 'Tramo-Bantayan'),
(632, 14, 'Wakas I'),
(633, 14, 'Wakas II'),
(644, 15, 'Baliwag'),
(645, 15, 'Barangay 1'),
(646, 15, 'Barangay 2'),
(647, 15, 'Barangay 3'),
(648, 15, 'Barangay 4'),
(649, 15, 'Bendita I'),
(650, 15, 'Bendita II'),
(651, 15, 'Caluangan'),
(652, 15, 'Kabulusan'),
(653, 15, 'Medina'),
(654, 15, 'Pacheco'),
(655, 15, 'Ramirez'),
(656, 15, 'San Agustin'),
(657, 15, 'Tua'),
(658, 15, 'Urdaneta'),
(659, 16, 'Bucal I'),
(660, 16, 'Bucal II'),
(661, 16, 'Bucal IIIA'),
(662, 16, 'Bucal IIIB'),
(663, 16, 'Bucal IVA'),
(664, 16, 'Bucal IVB'),
(665, 16, 'Caingin Poblacion'),
(666, 16, 'Garita I A'),
(667, 16, 'Garita I B'),
(668, 16, 'Layong Mabilog'),
(669, 16, 'Pantihan I'),
(670, 16, 'Pantihan II'),
(671, 16, 'Pantihan III'),
(672, 16, 'Patungan'),
(673, 16, 'Pinagsanhan I A'),
(674, 16, 'Pinagsanhan I B'),
(675, 16, 'Poblacion I A'),
(676, 16, 'Poblacion I B'),
(677, 16, 'Poblacion II A'),
(678, 16, 'Poblacion II B'),
(679, 16, 'San Miguel I A'),
(680, 16, 'San Miguel I B'),
(681, 16, 'Tulay Kanluran'),
(682, 16, 'Tulay Silangan'),
(690, 17, 'Anuling Cerca I'),
(691, 17, 'Anuling Cerca II'),
(692, 17, 'Anuling Lejos I'),
(693, 17, 'Anuling Lejos II'),
(694, 17, 'Asis I'),
(695, 17, 'Asis II'),
(696, 17, 'Asis III'),
(697, 17, 'Banayad'),
(698, 17, 'Bukal'),
(699, 17, 'Galicia I'),
(700, 17, 'Galicia II'),
(701, 17, 'Miguel Mojica'),
(702, 17, 'Palocpoc I'),
(703, 17, 'Palocpoc II'),
(704, 17, 'Panungyan I'),
(705, 17, 'Panungyan II'),
(706, 17, 'Poblacion I'),
(707, 17, 'Poblacion II'),
(708, 17, 'Poblacion III'),
(709, 17, 'Poblacion IV'),
(710, 17, 'Poblacion V'),
(711, 17, 'Poblacion VI'),
(712, 17, 'Poblacion VII'),
(721, 18, 'Bagong Karsada'),
(722, 18, 'Balsahan'),
(723, 18, 'Bancaan'),
(724, 18, 'Bucana Malaki'),
(725, 18, 'Calubcob'),
(726, 18, 'Capt. C. Nazareno'),
(727, 18, 'Gomez-Zamora'),
(728, 18, 'Halang'),
(729, 18, 'Ibayo Estacion'),
(730, 18, 'Ibayo Silangan'),
(731, 18, 'Kanluran'),
(732, 18, 'Labac'),
(733, 18, 'Mabolo'),
(734, 18, 'Makina'),
(735, 18, 'Malainen Bago'),
(736, 18, 'Malainen Luma'),
(737, 18, 'Muzon'),
(738, 18, 'Palangue 1'),
(739, 18, 'Palangue 2&3'),
(740, 18, 'San Roque'),
(741, 18, 'Santulan'),
(742, 18, 'Sapa'),
(743, 18, 'Timalan Balsahan'),
(744, 18, 'Timalan Concepcion'),
(752, 19, 'Magdiwang'),
(753, 19, 'Poblacion'),
(754, 19, 'Salcedo I'),
(755, 19, 'Salcedo II'),
(756, 19, 'San Antonio I'),
(757, 19, 'San Antonio II'),
(758, 19, 'San Jose I'),
(759, 19, 'San Jose II'),
(760, 19, 'San Juan I'),
(761, 19, 'San Juan II'),
(762, 19, 'San Rafael I'),
(763, 19, 'San Rafael II'),
(764, 19, 'San Rafael III'),
(765, 19, 'San Rafael IV'),
(766, 19, 'Santa Rosa I'),
(767, 19, 'Santa Rosa II'),
(783, 20, 'Bagbag I'),
(784, 20, 'Bagbag II'),
(785, 20, 'Kanluran'),
(786, 20, 'Ligtong II'),
(787, 20, 'Ligtong III'),
(788, 20, 'Muzon I'),
(789, 20, 'Muzon II'),
(790, 20, 'Sapa I'),
(791, 20, 'Sapa II'),
(792, 20, 'Sapa III'),
(793, 20, 'Silangan I'),
(794, 20, 'Silangan II'),
(795, 20, 'Tejeros Convention'),
(796, 20, 'Wawa I'),
(797, 20, 'Wawa II'),
(798, 20, 'Wawa III'),
(814, 21, 'Acacia'),
(815, 21, 'Adlas'),
(816, 21, 'Anahaw I'),
(817, 21, 'Anahaw II'),
(818, 21, 'Balite I'),
(819, 21, 'Balite II'),
(820, 21, 'Balubad'),
(821, 21, 'Barangay I'),
(822, 21, 'Barangay II'),
(823, 21, 'Barangay III'),
(824, 21, 'Barangay IV'),
(825, 21, 'Batas'),
(826, 21, 'Biga I'),
(827, 21, 'Biga II'),
(828, 21, 'Biluso'),
(829, 21, 'Buho'),
(830, 21, 'Bulihan'),
(831, 21, 'Cabangaan'),
(832, 21, 'Hoyo'),
(833, 21, 'Iba'),
(834, 21, 'Ipil I'),
(835, 21, 'Ipil II'),
(836, 21, 'Kaong'),
(837, 21, 'Lalaan I'),
(838, 21, 'Lalaan II'),
(839, 21, 'Litlit'),
(840, 21, 'Lucsuhin'),
(841, 21, 'Maguyam'),
(842, 21, 'Malaking Tatyao'),
(843, 21, 'Mataas na Burol'),
(844, 21, 'Munting Ilog'),
(845, 21, 'Narra I'),
(846, 21, 'Narra II'),
(847, 21, 'Paligawan'),
(848, 21, 'Pooc I'),
(849, 21, 'Pooc II'),
(850, 21, 'Pulong Bunga'),
(851, 21, 'Pulong Saging'),
(852, 21, 'Puting Kahoy'),
(853, 21, 'San Miguel I'),
(854, 21, 'San Miguel II'),
(855, 21, 'San Vicente I'),
(856, 21, 'San Vicente II'),
(857, 21, 'Santol'),
(858, 21, 'Tartaria'),
(859, 21, 'Toledo'),
(860, 21, 'Tubuan I'),
(861, 21, 'Tubuan II'),
(862, 21, 'Tubuan III'),
(863, 21, 'Ulat'),
(864, 21, 'Yakal'),
(877, 22, 'Amaya I'),
(878, 22, 'Amaya II'),
(879, 22, 'Amaya III'),
(880, 22, 'Amaya IV'),
(881, 22, 'Amaya V'),
(882, 22, 'Amaya VI'),
(883, 22, 'Amaya VII'),
(884, 22, 'Bagtas'),
(885, 22, 'Barangay I'),
(886, 22, 'Barangay II'),
(887, 22, 'Barangay III'),
(888, 22, 'Biga'),
(889, 22, 'Bucal'),
(890, 22, 'Bunga'),
(891, 22, 'Calibuyo'),
(892, 22, 'Capipisa'),
(893, 22, 'Daang Amaya I'),
(894, 22, 'Daang Amaya II'),
(895, 22, 'Halayhay'),
(896, 22, 'Julugan I'),
(897, 22, 'Julugan II'),
(898, 22, 'Julugan III'),
(899, 22, 'Julugan IV'),
(900, 22, 'Julugan V'),
(901, 22, 'Julugan VI'),
(902, 22, 'Lambingan'),
(903, 22, 'Mulawin'),
(904, 22, 'Paradahan I'),
(905, 22, 'Paradahan II'),
(906, 22, 'Punta I'),
(907, 22, 'Punta II'),
(908, 22, 'Sahud Ulan'),
(909, 22, 'Sanja Mayor'),
(910, 22, 'Santol'),
(911, 22, 'Tanauan'),
(912, 22, 'Tres Cruses'),
(940, 23, 'Bucana'),
(941, 23, 'Poblacion I'),
(942, 23, 'Poblacion I A'),
(943, 23, 'Poblacion II'),
(944, 23, 'Poblacion III'),
(945, 23, 'San Jose'),
(946, 23, 'San Juan I'),
(947, 23, 'San Juan II'),
(948, 23, 'Sapang I'),
(949, 23, 'Sapang II');

-- --------------------------------------------------------

--
-- Table structure for table `cavite_cities`
--

CREATE TABLE `cavite_cities` (
  `id` int(11) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `postal_code` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cavite_cities`
--

INSERT INTO `cavite_cities` (`id`, `city_name`, `postal_code`) VALUES
(1, 'Alfonso', '4123'),
(2, 'Amadeo', '4119'),
(3, 'City Of Bacoor', '4102'),
(4, 'City Of Carmona', '4116'),
(5, 'City Of Cavite', '4100'),
(6, 'City Of Dasmariñas', '4114'),
(7, 'City Of General Trias', '4107'),
(8, 'City Of Imus', '4103'),
(9, 'City Of Tagaytay', '4120'),
(10, 'City of Trece Martires', '4109'),
(11, 'Gen. Mariano Alvarez', '4117'),
(12, 'General Emilio Aguinaldo', '4124'),
(13, 'Indang', '4122'),
(14, 'Kawit', '4104'),
(15, 'Magallanes', '4113'),
(16, 'Maragondon', '4112'),
(17, 'Mendez', '4121'),
(18, 'Naic', '4110'),
(19, 'Noveleta', '4105'),
(20, 'Rosario', '4106'),
(21, 'Silang', '4118'),
(22, 'Tanza', '4108'),
(23, 'Ternate', '4111');

-- --------------------------------------------------------

--
-- Table structure for table `counselor_meetings`
--

CREATE TABLE `counselor_meetings` (
  `id` int(11) NOT NULL,
  `referral_id` int(11) DEFAULT NULL,
  `incident_report_id` varchar(20) DEFAULT NULL,
  `meeting_date` datetime DEFAULT NULL,
  `venue` varchar(255) DEFAULT NULL,
  `persons_present` text DEFAULT NULL,
  `meeting_minutes` text DEFAULT NULL,
  `location` text DEFAULT NULL,
  `prepared_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `meeting_sequence` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `counselor_meetings`
--

INSERT INTO `counselor_meetings` (`id`, `referral_id`, `incident_report_id`, `meeting_date`, `venue`, `persons_present`, `meeting_minutes`, `location`, `prepared_by`, `created_at`, `meeting_sequence`) VALUES
(1, 20, NULL, '2024-12-12 08:00:00', 'Guidance Counseling Office', '', '', '', '', '2024-12-06 12:54:50', 1),
(2, NULL, 'CEIT-24-25-0004', '2024-12-19 14:30:00', 'Guidance Counseling Office', '', '', '', '', '2024-12-06 12:57:10', 1),
(3, NULL, 'CEIT-24-25-0001', '2024-12-12 11:30:00', 'Guidance Counseling Office', '', '', '', '', '2024-12-06 13:05:51', 1);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `department_id`, `name`) VALUES
(1, 1, 'BS Information Technology'),
(2, 1, 'BS Computer Science'),
(3, 5, 'BS Agricultural and Biosystems Engineering'),
(4, 2, 'BS Architecture'),
(5, 2, 'BS Civil Engineering'),
(6, 3, 'BS Computer Engineering'),
(7, 3, 'BS Electrical Engineering'),
(8, 3, 'BS Electronics Engineering'),
(9, 4, 'BS Industrial Engineering'),
(10, 4, 'BS Industrial Technology Major in Automotive Technology'),
(11, 4, 'BS Industrial Technology Major in Electrical Technology'),
(12, 4, 'BS Industrial Technology Major in Electronics Technology');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`) VALUES
(5, 'Department of Agriculture and Food Engineering (DAFE)'),
(2, 'Department of Civil Engineering (DCEA)'),
(3, 'Department of Computer, Electronics, and Electrical Engineering (DCEEE)'),
(4, 'Department of Industrial Engineering and Technology (DIET)'),
(1, 'Department of Information Technology (DIT)');

-- --------------------------------------------------------

--
-- Table structure for table `document_requests`
--

CREATE TABLE `document_requests` (
  `request_id` varchar(50) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `student_number` varchar(20) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `course` varchar(100) DEFAULT NULL,
  `document_request` varchar(100) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `id_presented` varchar(255) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `request_time` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `document_requests`
--

INSERT INTO `document_requests` (`request_id`, `student_id`, `first_name`, `last_name`, `student_number`, `gender`, `department`, `course`, `document_request`, `purpose`, `id_presented`, `contact_email`, `request_time`, `status`) VALUES
('REQ_66b0d1d716b7f2.52653877', 202105706, 'Miguel Juan', 'Escover', '202105706', NULL, 'Department of Information Technology (DIT)', 'Bachelor of Science in Information Technology', 'Good Moral', NULL, NULL, 'miguelescover.cvsu@gmail.com', '2024-08-05 15:21:27', 'Approved'),
('REQ_66bd85c0eb2632.06950112', 202105704, 'Marie', 'Gonzaga', '202105704', NULL, 'Department of Industrial Engineering and Technology (DIET)', 'BS Industrial Technology Major in Electrical Technology', 'Good Moral', NULL, NULL, 'main.mariedanice.tio@cvsu.edu.ph', '2024-08-15 06:36:16', 'Approved'),
('REQ_66c59d93c7f6f6.12101288', 202107556, 'Robin', 'Estrella', '202107556', NULL, 'Department of Information Technology (DIT)', 'Bachelor of Science in Information Technology', 'Marj', NULL, NULL, 'robin@cvsu.edu.ph', '2024-08-21 09:56:03', 'Approved'),
('REQ_66cdd640dc12a5.50562554', 202105708, 'Cyndell Dadula', ' Dadula', '202105708', NULL, 'Department of Agriculture and Food Engineering (DAFE)', 'BS Agricultural and Biosystems Engineering', 'Good Moral', NULL, NULL, 'cyndell.dadula@cvsu.edu.ph', '2024-08-27 15:36:00', 'Approved'),
('REQ_66d030eceb9819.92735781', 202105703, 'Kim', 'Gauel', '202105703', NULL, 'Department of Agriculture and Food Engineering (DAFE)', 'BS Agricultural and Biosystems Engineering', 'Good Moral', NULL, NULL, 'neiltristhan.mojica@cvsu.edu.ph', '2024-08-29 10:27:24', 'Approved'),
('REQ_66d039620e6940.68180990', 202105703, 'Kim', 'Gauel', '202105703', NULL, 'Department of Agriculture and Food Engineering (DAFE)', 'BS Agricultural and Biosystems Engineering', 'Pashnea', NULL, NULL, 'kim@cvsu.com', '2024-08-29 11:03:30', 'Pending'),
('REQ_66d03c31971550.90545054', 201987895, 'Won', 'Jang', '201987895', NULL, 'Department of Civil Engineering (DCEA)', 'BS Civil Engineering', 'Good Moral', NULL, NULL, 'won@cvsu.edu.ph', '2024-08-29 11:15:29', 'Pending'),
('REQ_66d7e958dd5c80.08942239', 202005700, 'Julia Carla', 'Abutin', '202005700', NULL, 'Department of Information Technology (DIT)', 'BS Information Technology', 'Good Moral', NULL, NULL, 'abutin@cvsu.edu.ph', '2024-09-04 07:00:08', 'Approved'),
('REQ_66dc0d0529e394.71489823', 202105700, 'Denzel Anthonny', 'Barbacena', '202105700', NULL, 'Department of Information Technology (DIT)', 'BS Information Technology', 'Good Moral', NULL, NULL, 'denxel@cvsu.edu.ph', '2024-09-07 10:21:25', 'Pending'),
('REQ_66dd3be48b2f87.01294258', 202105706, 'Miguel Juan', 'Escover', '202105706', NULL, 'Department of Information Technology (DIT)', 'BS Information Technology', 'Good Moral', NULL, NULL, 'miguel@cvsu.edu.ph', '2024-09-08 07:53:40', 'Rejected'),
('REQ_66dd4069f21ab9.64017570', 202105702, 'Cyndelll', 'Dadula', '202105702', NULL, 'Department of Information Technology (DIT)', 'BS Information Technology', 'Good Moral', NULL, NULL, 'cyn@cvsu.edu.ph', '2024-09-08 08:12:57', 'Rejected'),
('REQ_66e58f18490063.35759637', 111111111, 'Miguel Juan', 'Escover', '111111111', NULL, 'Department of Agriculture and Food Engineering (DAFE)', 'BS Agricultural and Biosystems Engineering', 'Good Moral', NULL, NULL, 'wibasis977@ofionk.com', '2024-09-14 15:26:48', 'Approved'),
('REQ_66ec3475c50f24.97325572', 111111111, 'Paul Carlo', 'Ronsairo', '111111111', NULL, 'Department of Agriculture and Food Engineering (DAFE)', 'BS Agricultural and Biosystems Engineering', 'crush ko &lt;3', NULL, NULL, 'wibasis977@ofionk.com', '2024-09-19 16:25:57', 'Approved'),
('REQ_66fe68829e0301.30176428', 202105294, 'CATHERINE L.', 'PANGANIBAN', '202105294', 'FEMALE', 'Department of Information Technology (DIT)', 'BS Information Technology', 'Good Moral', 'Board Examination', 'Others: passport', 'catherine.panganiban@cvsu.edu.ph', '2024-10-03 00:00:00', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `incident_reports`
--

CREATE TABLE `incident_reports` (
  `id` varchar(20) NOT NULL,
  `date_reported` datetime DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `reported_by` varchar(255) DEFAULT NULL,
  `reporters_id` int(11) DEFAULT NULL,
  `reported_by_type` varchar(50) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT 'pending',
  `approval_date` datetime DEFAULT NULL,
  `facilitator_id` int(11) DEFAULT NULL,
  `resolution_status` enum('Pending','In Progress','Resolved') DEFAULT 'Pending',
  `resolution_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `incident_reports`
--

INSERT INTO `incident_reports` (`id`, `date_reported`, `place`, `description`, `reported_by`, `reporters_id`, `reported_by_type`, `file_path`, `created_at`, `status`, `approval_date`, `facilitator_id`, `resolution_status`, `resolution_notes`) VALUES
('CEIT-24-25-0001', '2024-11-19 09:34:20', 'CSPEAR - November 19, 2024 at 4:33 PM', 'Vaping ang madamme', 'Guard One', 1, 'guard', NULL, '2024-11-19 08:35:02', 'Settled', '2024-12-09 14:19:02', 1, 'Resolved', 'sgdgsgsg'),
('CEIT-24-25-0002', '2024-11-19 09:33:44', 'Salusoy - November 19, 2024 at 4:33 PM', 'Unang report na ba \'to?', 'Guard One', 1, 'guard', NULL, '2024-11-19 08:35:52', 'Referred', '2024-12-06 21:37:42', 1, 'Pending', NULL),
('CEIT-24-25-0004', '2024-11-20 06:52:03', 'Salusoy - November 20, 2024 at 1:52 PM', 'Nagsuntukan, ayon sa mga bata, kaya pinasa sa counselor ahhahaha eme talaga kayo guyise kabwisitr', 'JUANA DELA CRUZ', 202002882, 'student', NULL, '2024-11-20 05:52:38', 'Rescheduled', '2024-12-05 13:09:46', 1, NULL, NULL),
('CEIT-24-25-0005', '2024-11-20 06:58:22', 'CEIT - November 20, 2024 at 1:58 PM', 'Cheating', 'Facilitator One - CEIT', 1, 'facilitator', NULL, '2024-11-20 05:58:42', 'Settled', '2024-12-06 11:30:13', 1, 'Resolved', 'Bwisit na bata pinalo sa pwet malu ahhaha'),
('CEIT-24-25-0006', '2024-11-20 07:23:31', 'CEIT - November 20, 2024 at 2:24 PM', 'hello world daw', 'Instructor Two', 2, 'instructor', NULL, '2024-11-20 06:24:23', 'Referred', '2024-12-03 21:13:44', 1, 'Pending', NULL),
('CEIT-24-25-0008', '2024-11-25 07:53:00', 'Gate 1 - November 25, 2024 at 2:51 PM', 'hello', 'Guard One', 1, 'guard', NULL, '2024-11-25 06:56:12', 'Referred', '2024-12-01 21:43:47', 1, 'Pending', NULL),
('CEIT-24-25-0009', '2024-12-09 07:09:04', 'Salusoy - December 9, 2024 at 2:09 PM', 'bully', 'Facilitator One - CEIT', 1, 'facilitator', NULL, '2024-12-09 06:10:12', 'Referred', '2024-12-09 14:10:29', 1, 'Pending', NULL),
('CEIT-24-25-0010', '2024-12-10 04:52:07', 'Gate 1 - December 10, 2024 at 11:52 AM', 'refer1', 'Ma\'am gladys', 1, 'facilitator', NULL, '2024-12-10 03:58:09', 'Referred', '2024-12-10 12:01:09', 1, 'Pending', NULL),
('CEIT-24-25-0011', '2024-12-10 04:52:07', 'Salusoy - December 10, 2024 at 11:58 AM', 'refer2', 'Ma\'am gladys', 1, 'facilitator', NULL, '2024-12-10 03:58:40', 'pending', NULL, NULL, 'Pending', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `incident_witnesses`
--

CREATE TABLE `incident_witnesses` (
  `id` int(11) NOT NULL,
  `incident_report_id` varchar(20) DEFAULT NULL,
  `witness_type` enum('student','staff') NOT NULL,
  `witness_id` varchar(20) DEFAULT NULL,
  `witness_name` varchar(255) DEFAULT NULL,
  `witness_student_name` varchar(100) DEFAULT NULL,
  `witness_course` varchar(100) DEFAULT NULL,
  `witness_year_level` varchar(20) DEFAULT NULL,
  `witness_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `incident_witnesses`
--

INSERT INTO `incident_witnesses` (`id`, `incident_report_id`, `witness_type`, `witness_id`, `witness_name`, `witness_student_name`, `witness_course`, `witness_year_level`, `witness_email`) VALUES
(172, 'CEIT-24-25-0001', 'student', NULL, 'Ikoy', 'Ikoy', NULL, NULL, NULL),
(173, 'CEIT-24-25-0002', 'student', NULL, 'Witbness', 'Witbness', NULL, NULL, NULL),
(175, 'CEIT-24-25-0004', 'student', '202005700', 'Julia Carla Abutin', 'Julia Carla Abutin', 'BS Information Technology', 'First Year', NULL),
(176, 'CEIT-24-25-0005', 'student', '202002884', 'JUANE DELA CRUZ', 'JUANE DELA CRUZ', 'BS Information Technology', 'First Year', NULL),
(177, 'CEIT-24-25-0006', 'student', '202005700', 'Julia Carla Abutin', 'Julia Carla Abutin', 'BS Information Technology', 'First Year', NULL),
(179, 'CEIT-24-25-0008', 'student', NULL, 'Cyndell', 'Cyndell', NULL, NULL, NULL),
(180, 'CEIT-24-25-0009', 'student', '202106473', 'MARIE DANICE G. TIO', 'MARIE DANICE G. TIO', 'BS Information Technology', 'Fourth Year', NULL),
(181, 'CEIT-24-25-0010', 'student', '202002883', 'JUANCHO DELA CRUZ', 'JUANCHO DELA CRUZ', 'BS Information Technology', 'Second Year', NULL),
(182, 'CEIT-24-25-0011', 'student', '202002883', 'JUANCHO DELA CRUZ', 'JUANCHO DELA CRUZ', 'BS Information Technology', 'Second Year', NULL);

--
-- Triggers `incident_witnesses`
--
DELIMITER $$
CREATE TRIGGER `before_witness_insert` BEFORE INSERT ON `incident_witnesses` FOR EACH ROW BEGIN
    DECLARE student_fullname VARCHAR(100);
    DECLARE student_course_name VARCHAR(100);
    DECLARE student_year VARCHAR(20);
    
    IF NEW.witness_type = 'student' AND NEW.witness_id IS NOT NULL THEN
        SELECT 
            CONCAT(ts.first_name, ' ', ts.last_name),
            c.name,
            s.year_level
        INTO 
            student_fullname,
            student_course_name,
            student_year
        FROM tbl_student ts
        LEFT JOIN sections s ON ts.section_id = s.id
        LEFT JOIN courses c ON s.course_id = c.id
        WHERE ts.student_id = NEW.witness_id;
        
        SET NEW.witness_student_name = student_fullname;
        SET NEW.witness_course = student_course_name;
        SET NEW.witness_year_level = student_year;
        SET NEW.witness_name = student_fullname;  -- Update the existing witness_name field too
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `meetings`
--

CREATE TABLE `meetings` (
  `id` int(11) NOT NULL,
  `incident_report_id` varchar(20) DEFAULT NULL,
  `meeting_date` datetime DEFAULT NULL,
  `venue` varchar(255) DEFAULT NULL,
  `persons_present` text DEFAULT NULL,
  `meeting_minutes` text DEFAULT NULL,
  `location` text DEFAULT NULL,
  `prepared_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `meeting_sequence` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `meetings`
--

INSERT INTO `meetings` (`id`, `incident_report_id`, `meeting_date`, `venue`, `persons_present`, `meeting_minutes`, `location`, `prepared_by`, `created_at`, `meeting_sequence`) VALUES
(1, 'CEIT-24-25-0005', '2024-12-09 13:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-06 03:27:03', 1),
(2, 'CEIT-24-25-0005', '2024-12-06 11:28:00', 'CEIT GUIDANCE OFFICE', '[\"Emme\",\"mary Joy\",\"Sir Simeon\"]', 'hatugo, ang bi=spsp0piqxw', NULL, 'Facilitator One - CEIT', '2024-12-06 03:28:33', 2),
(3, 'CEIT-24-25-0005', '2024-12-12 12:29:00', 'CEIT GUIDANCE OFFICE', '[\"Marie\",\"Sir Simeon\"]', 'Bwisit na bata pinalo sa pwet malu ahhaha', NULL, 'Facilitator One - CEIT', '2024-12-06 03:29:13', 3),
(4, 'CEIT-24-25-0001', '2024-12-09 08:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-06 03:47:28', 1),
(5, 'CEIT-24-25-0001', '2024-12-06 11:51:00', 'CEIT GUIDANCE OFFICE', '[\"Marie\",\"Sir Simeon\"]', 'hello, ano ba \'to?', NULL, 'Facilitator One - CEIT', '2024-12-06 03:52:08', 2),
(6, 'CEIT-24-25-0004', '2024-12-11 11:30:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-06 13:30:21', 1),
(7, 'CEIT-24-25-0002', '2024-12-09 11:30:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-06 13:37:52', 1),
(8, 'CEIT-24-25-0001', '2024-12-10 10:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 09:11:52', 1),
(9, 'CEIT-24-25-0004', '2024-12-09 15:30:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 09:12:36', 1),
(10, 'CEIT-24-25-0004', '2024-12-09 13:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 09:12:58', 1),
(11, 'CEIT-24-25-0002', '2024-12-17 14:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 09:13:35', 1),
(12, 'CEIT-24-25-0004', '2024-12-17 14:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 13:00:56', 1),
(13, 'CEIT-24-25-0004', '2024-12-17 15:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 13:01:09', 1),
(14, 'CEIT-24-25-0002', '2024-12-17 14:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 13:01:24', 1),
(15, 'CEIT-24-25-0002', '2024-12-09 09:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 13:20:30', 1),
(16, 'CEIT-24-25-0004', '2024-12-17 15:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 13:56:33', 1),
(17, 'CEIT-24-25-0002', '2024-12-17 14:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 13:56:42', 1),
(18, 'CEIT-24-25-0002', '2024-12-09 14:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 14:59:03', 1),
(19, 'CEIT-24-25-0002', '2024-12-09 14:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 14:59:12', 1),
(20, 'CEIT-24-25-0002', '2024-12-11 14:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 14:59:19', 1),
(21, 'CEIT-24-25-0002', '2024-12-18 14:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 14:59:26', 1),
(22, 'CEIT-24-25-0002', '2024-12-10 14:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-07 14:59:43', 1),
(23, 'CEIT-24-25-0009', '2024-12-10 09:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-09 06:10:51', 1),
(24, 'CEIT-24-25-0001', '2024-12-10 10:00:00', 'CEIT GUIDANCE Office', '', '', '', '', '2024-12-09 06:13:51', 1),
(25, 'CEIT-24-25-0009', '2024-12-10 14:16:00', 'CEIT GUIDANCE OFFICE', '[\"Marie\",\"Emme\"]', 'sdaffafsagf', NULL, 'Ma\'am gladys', '2024-12-09 06:17:15', 2),
(26, 'CEIT-24-25-0001', '2024-12-11 14:18:00', 'CEIT GUIDANCE OFFICE', '[\"sfsf\",\"sfsf\"]', 'sgdgsgsg', NULL, 'Ma\'am gladys', '2024-12-09 06:18:33', 3);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_type` enum('student','facilitator','adviser','counselor','dean','admin') NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_type`, `user_id`, `message`, `link`, `is_read`, `created_at`) VALUES
(3, 'student', '202105706', 'A meeting has been rescheduled for your incident report on December 3, 2024, 9:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0008', 0, '2024-12-02 11:20:52'),
(4, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0008', 0, '2024-12-02 11:20:52'),
(5, 'student', '202105706', 'A meeting has been rescheduled for your incident report on December 3, 2024, 9:51 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0008', 0, '2024-12-03 08:26:03'),
(6, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0008', 0, '2024-12-03 08:26:03'),
(7, 'counselor', '7', 'A new incident report has been referred to you.', 'view_referral_details.php?id=12', 0, '2024-12-03 12:55:20'),
(8, 'student', '202002882', 'Your incident report has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0006', 0, '2024-12-03 13:13:44'),
(9, 'adviser', '5', 'An incident report for your student has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0006', 0, '2024-12-03 13:13:44'),
(10, 'student', '202002882', 'Your incident report has been referred to the Guidance Counselor.', 'view_referral_details.php?id=16', 0, '2024-12-04 14:51:43'),
(11, 'adviser', '5', 'An incident report for your student has been referred to the Guidance Counselor.', 'view_referral_details.php?id=16', 0, '2024-12-04 14:51:43'),
(12, 'counselor', '7', 'A new incident report has been referred to you.', 'view_referral_details.php?id=16', 0, '2024-12-04 14:51:43'),
(13, 'student', '202105294', 'Your request for Good Moral has been Pending.', NULL, 0, '2024-12-04 15:03:47'),
(14, 'student', '202105294', 'Your request for Good Moral has been Approved.', NULL, 0, '2024-12-04 15:03:55'),
(15, 'student', '202002881', 'Your incident report has been marked as settled.', 'view_student_incident_reports.php?id=CEIT-24-25-0003', 0, '2024-12-04 15:32:22'),
(16, 'adviser', '5', 'An incident report for your student has been marked as settled.', 'view_student_incident_reports.php?id=CEIT-24-25-0003', 0, '2024-12-04 15:32:22'),
(17, 'student', '202002882', 'Your incident report has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:09:46'),
(18, 'student', '202002884', 'Your incident report has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:09:46'),
(19, 'adviser', '5', 'An incident report for your student has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:09:46'),
(20, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 9, 2024, 9:30 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:20:27'),
(21, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:20:27'),
(22, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 9, 2024, 3:00 PM', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:23:07'),
(23, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:23:07'),
(24, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 9, 2024, 3:00 PM', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:40:35'),
(25, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:40:35'),
(26, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 31, 2024, 11:30 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:41:24'),
(27, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:41:24'),
(28, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 10, 2024, 11:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:44:15'),
(29, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:44:15'),
(30, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 24, 2024, 12:00 PM', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:47:44'),
(31, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:47:44'),
(32, 'student', '202002882', 'Your incident report has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0005', 0, '2024-12-05 05:49:34'),
(33, 'adviser', '5', 'An incident report for your student has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0005', 0, '2024-12-05 05:49:34'),
(34, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 26, 2024, 11:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0005', 0, '2024-12-05 05:49:46'),
(35, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0005', 0, '2024-12-05 05:49:46'),
(36, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 9, 2024, 12:30 PM', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:58:34'),
(37, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-05 05:58:34'),
(38, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 17, 2024, 12:30 PM', 'View_student_incident_reports.php?id=CEIT-24-25-0005', 0, '2024-12-05 06:06:14'),
(39, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0005', 0, '2024-12-05 06:06:14'),
(40, 'student', '202002884', 'Your incident report has been referred to the Guidance Counselor.', 'view_referral_details.php?id=18', 0, '2024-12-05 06:08:18'),
(41, 'adviser', '5', 'An incident report for your student has been referred to the Guidance Counselor.', 'view_referral_details.php?id=18', 0, '2024-12-05 06:08:18'),
(42, 'counselor', '7', 'A new incident report has been referred to you.', 'view_referral_details.php?id=18', 0, '2024-12-05 06:08:18'),
(43, 'student', '202002882', 'Your incident report has been referred to the Guidance Counselor.', 'view_referral_details.php?id=19', 0, '2024-12-05 06:08:29'),
(44, 'adviser', '5', 'An incident report for your student has been referred to the Guidance Counselor.', 'view_referral_details.php?id=19', 0, '2024-12-05 06:08:29'),
(45, 'counselor', '7', 'A new incident report has been referred to you.', 'view_referral_details.php?id=19', 0, '2024-12-05 06:08:29'),
(46, 'student', '202105294', 'You have been referred to the Guidance Counselor.', 'view_referral_details.php?id=20', 0, '2024-12-05 13:04:48'),
(47, 'adviser', '5', 'Your student has been referred to the Guidance Counselor.', 'view_referral_details.php?id=20', 0, '2024-12-05 13:04:48'),
(48, 'counselor', '7', 'A new student referral has been submitted.', 'view_referral_details.php?id=20', 0, '2024-12-05 13:04:48'),
(49, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 9, 2024, 1:00 PM', 'View_student_incident_reports.php?id=CEIT-24-25-0005', 0, '2024-12-06 03:27:03'),
(50, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0005', 0, '2024-12-06 03:27:03'),
(51, 'student', '202002882', 'Your incident report has been marked as settled.', 'view_student_incident_reports.php?id=CEIT-24-25-0005', 0, '2024-12-06 03:30:13'),
(52, 'adviser', '5', 'An incident report for your student has been marked as settled.', 'view_student_incident_reports.php?id=CEIT-24-25-0005', 0, '2024-12-06 03:30:13'),
(53, 'student', '202002884', 'Your incident report has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 03:46:09'),
(54, 'adviser', '5', 'An incident report for your student has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 03:46:09'),
(55, 'student', '202002884', 'A meeting has been scheduled for your incident report on December 9, 2024, 8:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 03:47:28'),
(56, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 03:47:28'),
(57, 'student', '202002884', 'Your incident report has been referred to the Guidance Counselor.', 'view_referral_details.php?id=21', 0, '2024-12-06 03:52:28'),
(58, 'adviser', '5', 'An incident report for your student has been referred to the Guidance Counselor.', 'view_referral_details.php?id=21', 0, '2024-12-06 03:52:28'),
(59, 'counselor', '7', 'A new incident report has been referred to you.', 'view_referral_details.php?id=21', 0, '2024-12-06 03:52:28'),
(60, 'student', '202105294', 'A counseling meeting has been scheduled for your referral on December 12, 2024, 8:00 AM', 'view_counseling_schedule.php?id=20', 0, '2024-12-06 12:54:50'),
(61, 'adviser', '5', 'A counseling meeting has been scheduled for your student', 'view_counseling_schedule.php?id=20', 0, '2024-12-06 12:54:50'),
(62, 'student', '202105294', 'A counseling meeting has been rescheduled for your referral on December 12, 2024, 8:00 AM', 'view_counseling_schedule.php?id=20', 0, '2024-12-06 12:56:14'),
(63, 'adviser', '5', 'A counseling meeting has been rescheduled for your student', 'view_counseling_schedule.php?id=20', 0, '2024-12-06 12:56:14'),
(64, 'student', '202105294', 'A counseling meeting has been rescheduled for your referral on December 12, 2024, 8:00 AM', 'view_counseling_schedule.php?id=20', 0, '2024-12-06 12:56:54'),
(65, 'adviser', '5', 'A counseling meeting has been rescheduled for your student', 'view_counseling_schedule.php?id=20', 0, '2024-12-06 12:56:54'),
(66, 'student', '202002882', 'A counseling meeting has been scheduled for your incident report on December 19, 2024, 2:30 PM', 'view_counseling_schedule.php?id=CEIT-24-25-0004', 0, '2024-12-06 12:57:10'),
(67, 'adviser', '5', 'A counseling meeting has been scheduled for your student', 'view_counseling_schedule.php?id=CEIT-24-25-0004', 0, '2024-12-06 12:57:10'),
(68, 'student', '202002884', 'A counseling meeting has been scheduled for your incident report on December 12, 2024, 11:30 AM', 'view_counseling_schedule.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:05:52'),
(69, 'adviser', '5', 'A counseling meeting has been scheduled for your student', 'view_counseling_schedule.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:05:52'),
(70, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 9, 2024, 8:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:27:23'),
(71, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:27:23'),
(72, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 10, 2024, 10:30 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:27:34'),
(73, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:27:34'),
(74, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 12, 2024, 12:00 PM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:30:09'),
(75, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:30:09'),
(76, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 11, 2024, 11:30 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-06 13:30:21'),
(77, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-06 13:30:21'),
(78, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 9, 2024, 8:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:31:13'),
(79, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:31:13'),
(80, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 9, 2024, 8:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:32:54'),
(81, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:32:54'),
(82, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 9, 2024, 8:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:33:51'),
(83, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:33:51'),
(84, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 11, 2024, 11:30 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-06 13:37:30'),
(85, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-06 13:37:30'),
(86, 'student', '202002882', 'Your incident report has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:37:42'),
(87, 'student', '202002883', 'Your incident report has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:37:42'),
(88, 'adviser', '5', 'An incident report for your student has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:37:42'),
(89, 'student', '202002882', 'A meeting has been scheduled for your incident report on December 9, 2024, 11:30 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:37:52'),
(90, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:37:52'),
(91, 'adviser', '5', 'Meeting notification sent for student JUANA DELA CRUZ', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:46:21'),
(92, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:50:12'),
(93, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 10, 2024, 10:30 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:52:24'),
(94, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:52:24'),
(95, 'adviser', '5', 'Meeting notification sent for student JUANA DELA CRUZ', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:52:33'),
(96, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:52:42'),
(97, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 9, 2024, 10:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:53:40'),
(98, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 13:53:40'),
(99, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 9, 2024, 11:30 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:53:49'),
(100, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-06 13:53:49'),
(101, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 10, 2024, 12:30 PM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 14:20:58'),
(102, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-06 14:20:58'),
(103, 'adviser', '5', 'Meeting notification sent for student JUANE DELA CRUZ', 'view_meeting_details.php?id=CEIT-24-25-0001', 0, '2024-12-06 14:21:10'),
(104, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 10, 2024, 12:00 PM', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 07:39:30'),
(105, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 07:39:30'),
(106, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 07:43:06'),
(107, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 07:43:55'),
(108, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 9, 2024, 11:30 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 08:08:58'),
(109, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 08:08:58'),
(110, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 08:09:10'),
(111, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 08:28:52'),
(112, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 9, 2024, 8:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-07 09:00:10'),
(113, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-07 09:00:10'),
(114, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 9, 2024, 8:00 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-07 09:00:35'),
(115, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-07 09:00:35'),
(116, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 9, 2024, 11:30 AM', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 09:00:49'),
(117, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'View_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 09:00:49'),
(118, 'adviser', '5', 'Meeting notification sent for student JUANA DELA CRUZ', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 09:02:50'),
(119, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 10, 2024, 10:00 AM', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-07 09:11:52'),
(120, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-07 09:11:52'),
(121, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 9, 2024, 3:30 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-07 09:12:36'),
(122, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-07 09:12:36'),
(123, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 9, 2024, 1:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-07 09:12:58'),
(124, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-07 09:12:58'),
(125, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 17, 2024, 2:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 09:13:35'),
(126, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 09:13:35'),
(127, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 09:13:47'),
(128, 'student', '202002884', 'Your incident report has been marked as settled.', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-07 09:28:09'),
(129, 'adviser', '5', 'An incident report for your student has been marked as settled.', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-07 09:28:09'),
(130, 'student', '202002884', 'Your incident report has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-07 09:28:33'),
(131, 'adviser', '5', 'An incident report for your student has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-07 09:28:33'),
(132, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 17, 2024, 2:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-07 13:00:56'),
(133, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-07 13:00:56'),
(134, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 17, 2024, 3:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-07 13:01:09'),
(135, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-07 13:01:09'),
(136, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 17, 2024, 2:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:01:24'),
(137, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:01:24'),
(138, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:01:31'),
(139, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 9, 2024, 9:00 AM', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:20:30'),
(140, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:20:30'),
(141, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:20:47'),
(142, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:23:01'),
(143, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:27:16'),
(144, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 17, 2024, 3:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-07 13:56:34'),
(145, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0004', 0, '2024-12-07 13:56:34'),
(146, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 17, 2024, 2:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:56:42'),
(147, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:56:42'),
(148, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 13:56:47'),
(149, 'student', '202002882', 'You have a scheduled meeting on December 9, 2024 at 11:30 AM', 'view_meeting_details.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:47:22'),
(150, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 9, 2024, 2:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:59:03'),
(151, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:59:03'),
(152, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 9, 2024, 2:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:59:12'),
(153, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:59:12'),
(154, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 11, 2024, 2:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:59:19'),
(155, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:59:19'),
(156, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 18, 2024, 2:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:59:26'),
(157, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:59:26'),
(158, 'student', '202002882', 'A meeting has been rescheduled for your incident report on December 10, 2024, 2:00 PM', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:59:43'),
(159, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0002', 0, '2024-12-07 14:59:43'),
(160, 'student', '202105294', 'Your request for Good Moral has been Approved.', NULL, 0, '2024-12-08 09:40:10'),
(161, 'student', '202105706', 'Your request for Good Moral has been Rejected.', NULL, 0, '2024-12-08 09:40:49'),
(162, 'student', '202105294', 'Your request for Good Moral has been Approved.', NULL, 0, '2024-12-08 09:41:36'),
(163, 'student', '202105703', 'Your request for Good Moral has been Approved.', NULL, 0, '2024-12-08 09:49:35'),
(164, 'student', '202105706', 'Your request for Good Moral has been Rejected.', NULL, 0, '2024-12-08 09:54:42'),
(165, 'student', '202105706', 'Your request for Good Moral has been Rejected.', NULL, 0, '2024-12-08 09:59:34'),
(166, 'student', '111111111', 'Your request for Good Moral has been Approved.', NULL, 0, '2024-12-08 10:06:50'),
(167, 'student', '202105702', 'Your request for Good Moral has been Rejected.', NULL, 0, '2024-12-08 10:06:56'),
(168, 'student', '202005700', 'Your request for Good Moral has been Approved.', NULL, 0, '2024-12-08 10:07:53'),
(169, 'student', '202002882', 'Your incident report has been referred to the Guidance Counselor.', 'view_referral_details.php?id=22', 0, '2024-12-09 06:07:13'),
(170, 'adviser', '5', 'An incident report for your student has been referred to the Guidance Counselor.', 'view_referral_details.php?id=22', 0, '2024-12-09 06:07:13'),
(171, 'counselor', '7', 'A new incident report has been referred to you.', 'view_referral_details.php?id=22', 0, '2024-12-09 06:07:13'),
(172, 'counselor', '7', 'A new incident report has been referred to you.', 'view_referral_details.php?id=23', 0, '2024-12-09 06:07:24'),
(173, 'student', '202105706', 'Your incident report has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0009', 0, '2024-12-09 06:10:29'),
(174, 'adviser', '5', 'An incident report for your student has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0009', 0, '2024-12-09 06:10:29'),
(175, 'student', '202105706', 'A meeting has been scheduled for your incident report on December 10, 2024, 9:00 AM', 'view_student_incident_reports.php?id=CEIT-24-25-0009', 0, '2024-12-09 06:10:51'),
(176, 'adviser', '5', 'A meeting has been scheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0009', 0, '2024-12-09 06:10:51'),
(177, 'student', '202105706', 'You have a scheduled meeting on December 10, 2024 at 9:00 AM', 'view_meeting_details.php?id=CEIT-24-25-0009', 0, '2024-12-09 06:11:06'),
(178, 'adviser', '5', 'Meeting notification sent for student MIGUEL JUAN ESCOVER', 'view_meeting_details.php?id=CEIT-24-25-0009', 0, '2024-12-09 06:11:13'),
(179, 'student', '202105706', 'You have a scheduled meeting on December 10, 2024 at 9:00 AM', 'view_meeting_details.php?id=CEIT-24-25-0009', 0, '2024-12-09 06:12:51'),
(180, 'student', '202002884', 'A meeting has been rescheduled for your incident report on December 10, 2024, 10:00 AM', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-09 06:13:51'),
(181, 'adviser', '5', 'A meeting has been rescheduled for your student\'s incident report', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-09 06:13:51'),
(182, 'adviser', '5', 'Meeting notification sent for student JUANE DELA CRUZ', 'view_meeting_details.php?id=CEIT-24-25-0001', 0, '2024-12-09 06:14:14'),
(183, 'student', '202105706', 'Your request for Good Moral has been Rejected.', NULL, 0, '2024-12-09 06:15:09'),
(184, 'student', '202105294', 'Your request for Good Moral has been Approved.', NULL, 0, '2024-12-09 06:15:48'),
(185, 'student', '202002884', 'Your incident report has been marked as settled.', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-09 06:19:02'),
(186, 'adviser', '5', 'An incident report for your student has been marked as settled.', 'view_student_incident_reports.php?id=CEIT-24-25-0001', 0, '2024-12-09 06:19:02'),
(187, 'student', '202105706', 'Your incident report has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0010', 0, '2024-12-10 04:01:09'),
(188, 'adviser', '5', 'An incident report for your student has been updated to: For Meeting', 'view_student_incident_reports.php?id=CEIT-24-25-0010', 0, '2024-12-10 04:01:09'),
(189, 'student', '202105706', 'Your incident report has been referred to the Guidance Counselor.', 'view_referral_details.php?id=24', 0, '2024-12-10 04:01:30'),
(190, 'adviser', '5', 'An incident report for your student has been referred to the Guidance Counselor.', 'view_referral_details.php?id=24', 0, '2024-12-10 04:01:30'),
(191, 'counselor', '7', 'A new incident report has been referred to you.', 'view_referral_details.php?id=24', 0, '2024-12-10 04:01:30'),
(192, 'student', '202105706', 'Your incident report has been referred to the Guidance Counselor.', 'view_referral_details.php?id=25', 0, '2024-12-10 04:47:24'),
(193, 'adviser', '5', 'An incident report for your student has been referred to the Guidance Counselor.', 'view_referral_details.php?id=25', 0, '2024-12-10 04:47:24'),
(194, 'counselor', '7', 'A new incident report has been referred to you.', 'view_referral_details.php?id=25', 0, '2024-12-10 04:47:24'),
(195, 'student', '202105294', 'You have been referred to the Guidance Counselor.', 'view_referral_details.php?id=26', 0, '2024-12-10 15:13:54'),
(196, 'adviser', '5', 'Your student has been referred to the Guidance Counselor.', 'view_referral_details.php?id=26', 0, '2024-12-10 15:13:54'),
(197, 'counselor', '7', 'A new student referral has been submitted.', 'view_referral_details.php?id=26', 0, '2024-12-10 15:13:54');

-- --------------------------------------------------------

--
-- Table structure for table `pending_incident_reports`
--

CREATE TABLE `pending_incident_reports` (
  `id` int(11) NOT NULL,
  `guard_id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `date_reported` datetime NOT NULL,
  `place` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `reported_by` varchar(255) NOT NULL,
  `reported_by_type` varchar(50) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pending_incident_reports`
--

INSERT INTO `pending_incident_reports` (`id`, `guard_id`, `student_id`, `date_reported`, `place`, `description`, `reported_by`, `reported_by_type`, `file_path`, `status`, `created_at`) VALUES
(49, 2, '', '2024-11-18 11:06:35', 'CEIT - November 18, 2024 at 6:04 PM', 'try one', 'Guard two', 'guard', NULL, 'Escalated', '2024-11-18 10:06:35'),
(61, 1, '', '2024-11-19 09:33:44', 'Salusoy - November 19, 2024 at 4:33 PM', 'Unang report na ba \'to?', 'Guard One', 'guard', NULL, 'Escalated', '2024-11-19 08:33:44'),
(62, 1, '', '2024-11-19 09:34:20', 'CSPEAR - November 19, 2024 at 4:33 PM', 'Vaping ang madamme', 'Guard One', 'guard', NULL, 'Escalated', '2024-11-19 08:34:20'),
(63, 1, '', '2024-11-20 08:05:27', 'CEIT - November 20, 2024 at 3:05 PM', 'tyry yasfwghs', 'Guard One', 'guard', NULL, 'Escalated', '2024-11-20 07:05:27'),
(64, 1, '', '2024-11-25 07:53:00', 'Gate 1 - November 25, 2024 at 2:51 PM', 'hello', 'Guard One', 'guard', NULL, 'Escalated', '2024-11-25 06:53:00'),
(65, 1, '', '2024-11-25 14:40:24', 'Gate 1 - November 25, 2024 at 9:39 PM', 'It is hard to hold on and believe, cause what if it\'s not meant to be.', 'Guard One', 'guard', NULL, 'Pending', '2024-11-25 13:40:24');

-- --------------------------------------------------------

--
-- Table structure for table `pending_incident_witnesses`
--

CREATE TABLE `pending_incident_witnesses` (
  `id` int(11) NOT NULL,
  `pending_report_id` int(11) NOT NULL,
  `witness_type` enum('student','staff') NOT NULL,
  `witness_id` varchar(20) DEFAULT NULL,
  `witness_name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `witness_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pending_incident_witnesses`
--

INSERT INTO `pending_incident_witnesses` (`id`, `pending_report_id`, `witness_type`, `witness_id`, `witness_name`, `created_at`, `witness_email`) VALUES
(49, 49, 'student', '123456', 'wala ityo', '2024-11-18 10:06:35', NULL),
(61, 61, 'student', '125', 'Witbness', '2024-11-19 08:33:44', NULL),
(62, 62, 'student', '123', 'Ikoy', '2024-11-19 08:34:20', NULL),
(63, 63, 'student', '123456', 'wala ityo', '2024-11-20 07:05:27', NULL),
(64, 64, 'student', '', 'Cyndell', '2024-11-25 06:53:00', NULL),
(65, 65, 'student', '123', 'hello hi hehe', '2024-11-25 13:40:24', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pending_student_violations`
--

CREATE TABLE `pending_student_violations` (
  `id` int(11) NOT NULL,
  `pending_report_id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pending_student_violations`
--

INSERT INTO `pending_student_violations` (`id`, `pending_report_id`, `student_id`, `student_name`, `created_at`) VALUES
(59, 49, '123', 'bata 1', '2024-11-18 10:06:35'),
(60, 49, '202002882', 'ewan', '2024-11-18 10:06:35'),
(79, 61, '202002882', 'elise', '2024-11-19 08:33:44'),
(80, 61, '123', 'Giro daw', '2024-11-19 08:33:44'),
(81, 62, '202002884', 'Sino ba ito?', '2024-11-19 08:34:20'),
(82, 63, '123', 'bata 1', '2024-11-20 07:05:27'),
(83, 63, '202002883', 'neil', '2024-11-20 07:05:27'),
(84, 64, '123', 'secret', '2024-11-25 06:53:00'),
(85, 64, '202105706', 'Miggy cute', '2024-11-25 06:53:00'),
(86, 65, '202002882', 'dream', '2024-11-25 13:40:24'),
(87, 65, '202002885', 'hard to hold on', '2024-11-25 13:40:24');

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

CREATE TABLE `referrals` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `course_year` varchar(100) NOT NULL,
  `reason_for_referral` varchar(255) NOT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `violation_details` text DEFAULT NULL,
  `other_concerns` text DEFAULT NULL,
  `faculty_name` varchar(100) NOT NULL,
  `acknowledged_by` varchar(100) NOT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `incident_report_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `referrals`
--

INSERT INTO `referrals` (`id`, `date`, `first_name`, `middle_name`, `last_name`, `course_year`, `reason_for_referral`, `status`, `violation_details`, `other_concerns`, `faculty_name`, `acknowledged_by`, `student_id`, `incident_report_id`) VALUES
(9, '2024-11-03', 'Kim', 'Mojica', 'Gauel', 'BS Agricultural and Biosystems Engineering - First Year', 'Behavior maladjustment', 'Done', '', '', 'Facilitator One - CEIT', 'Guidance Counselor', NULL, NULL),
(10, '2024-11-22', 'MIGUEL JUAN', 'CASAMBROS', 'ESCOVER', 'BS Information Technology - Fourth Year', 'Other concern', 'For Meeting', '', 'High Level of Stress', 'Facilitator One - CEIT', 'Guidance Counselor', NULL, NULL),
(11, '2024-12-03', 'MIGUEL JUAN', 'CASAMBROS', 'ESCOVER', 'BS Information Technology - Fourth Year', 'Behavior maladjustment', 'For Meeting', '', '', 'Facilitator One - CEIT', 'Guidance Counselor', '202105706', 'CEIT-24-25-0008'),
(12, '2024-12-03', 'secret', '', '', ' - ', 'Behavior maladjustment', 'For Meeting', '', '', 'Facilitator One - CEIT', 'Guidance Counselor', NULL, 'CEIT-24-25-0008'),
(14, '2024-12-03', 'JUANA', 'B', 'DELA CRUZ', 'Second Year BS Information Technology - 1', 'Violation to school rules', 'For Meeting', 'not wearing uniform', '', 'Facilitator One - CEIT', 'Counselor One', '202002882', NULL),
(15, '2024-12-03', 'JUANA', 'B', 'DELA CRUZ', 'Second Year BS Information Technology - 1', 'Other concern', 'Pending', '', 'ano ba dapat?', 'Facilitator One - CEIT', 'Counselor One', '202002882', NULL),
(16, '2024-12-04', 'JUANA', 'B', 'DELA CRUZ', 'BS Information Technology - Second Year', 'Academic concern', 'For Meeting', '', '', 'Facilitator One - CEIT', 'Guidance Counselor', '202002882', 'CEIT-24-25-0006'),
(17, '2024-12-04', 'Simeon', 'Gonzaga', 'Daez', 'Fourth Year BS Information Technology - 1', 'Other concern', 'Pending', '', 'trying langsss haha', 'Facilitator One - CEIT', 'Guidance Counselor', NULL, NULL),
(18, '2024-12-05', 'JUANE', 'D', 'DELA CRUZ', 'BS Information Technology - Second Year', 'Violation to school rules: Hello', 'For Meeting', '', '', 'Facilitator One - CEIT', 'Guidance Counselor', '202002884', 'CEIT-24-25-0004'),
(19, '2024-12-05', 'JUANA', 'B', 'DELA CRUZ', 'BS Information Technology - Second Year', 'Behavior maladjustment', 'Pending', '', '', 'Facilitator One - CEIT', 'Guidance Counselor', '202002882', 'CEIT-24-25-0004'),
(20, '2024-12-05', 'CATHERINE', 'L.', 'PANGANIBAN', 'BS Information Technology', 'Other concern', 'For Meeting', '', 'High Stress Level', 'Facilitator One - CEIT', 'Guidance Counselor', '202105294', NULL),
(21, '2024-12-06', 'JUANE', 'D', 'DELA CRUZ', 'BS Information Technology - Second Year', 'Behavior maladjustment', 'For Meeting', '', '', 'Facilitator One - CEIT', 'Guidance Counselor', '202002884', 'CEIT-24-25-0001'),
(22, '2024-12-09', 'JUANA', 'B', 'DELA CRUZ', 'BS Information Technology - Second Year', 'Behavior maladjustment', 'Pending', '', '', 'Facilitator One - CEIT', 'Guidance Counselor', '202002882', 'CEIT-24-25-0002'),
(23, '2024-12-09', 'Giro daw', '', '', ' - ', 'Behavior maladjustment', 'For Meeting', '', '', 'Facilitator One - CEIT', 'Guidance Counselor', NULL, 'CEIT-24-25-0002'),
(24, '2024-12-10', 'MIGUEL JUAN', 'CASAMBROS', 'ESCOVER', 'BS Information Technology - Fourth Year', 'Academic concern', 'Pending', '', '', 'Ma\'am gladys', 'Guidance Counselor', '202105706', 'CEIT-24-25-0010'),
(25, '2024-12-10', 'MIGUEL JUAN', 'CASAMBROS', 'ESCOVER', 'BS Information Technology - Fourth Year', 'Other concern', 'Done', '', 'refer 2', 'Ma\'am gladys', 'Guidance Counselor', '202105706', 'CEIT-24-25-0009'),
(26, '2024-12-10', 'CATHERINE', 'L.', 'PANGANIBAN', 'BS Information Technology', 'Other concern', 'Done', '', 'Mental Health Concern', 'Ma\'am gladys', 'Guidance Counselor', '202105294', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `course_id` int(11) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `year_level` varchar(20) NOT NULL,
  `section_no` varchar(20) NOT NULL,
  `academic_year` varchar(15) NOT NULL,
  `adviser_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `department_id`, `department_name`, `course_id`, `course_name`, `year_level`, `section_no`, `academic_year`, `adviser_id`, `created_at`) VALUES
(1, 1, 'Department of Information Technology (DIT)', 1, 'BS Information Technology', 'Third Year', '1', '2024 to 2025', 1, '2024-08-29 07:45:35'),
(4, 5, 'Department of Agriculture and Food Engineering (DAFE)', 3, 'BS Agricultural and Biosystems Engineering', 'First Year', '1', '2024 to 2025', 2, '2024-08-29 08:15:17'),
(5, 2, 'Department of Civil Engineering (DCEA)', 5, 'BS Civil Engineering', 'Fourth Year', '1', '2024 to 2025', 2, '2024-08-29 08:15:24'),
(11, 1, 'Department of Information Technology (DIT)', 1, 'BS Information Technology', 'First Year', '2', '2024 to 2025', 1, '2024-08-31 15:16:11'),
(2411907, 1, 'Department of Information Technology (DIT)', 1, 'BS Information Technology', 'Second Year', '1', '2024 to 2025', 5, '2024-11-18 06:44:39'),
(2425375, 3, 'Department of Computer, Electronics, and Electrical Engineering (DCEEE)', 7, 'BS Electrical Engineering', 'First Year', '1', '2024 to 2025', 5, '2024-11-20 10:16:09'),
(2428698, 1, 'Department of Information Technology (DIT)', 1, 'BS Information Technology', 'Fourth Year', '1', '2024 to 2025', 5, '2024-10-03 08:04:17');

--
-- Triggers `sections`
--
DELIMITER $$
CREATE TRIGGER `before_insert_section` BEFORE INSERT ON `sections` FOR EACH ROW BEGIN
    DECLARE dept_name VARCHAR(100);
    DECLARE crs_name VARCHAR(100);
    
    SELECT name INTO dept_name FROM departments WHERE id = NEW.department_id;
    SELECT name INTO crs_name FROM courses WHERE id = NEW.course_id;
    
    SET NEW.department_name = dept_name;
    SET NEW.course_name = crs_name;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_update_section` BEFORE UPDATE ON `sections` FOR EACH ROW BEGIN
    DECLARE dept_name VARCHAR(100);
    DECLARE crs_name VARCHAR(100);
    
    IF NEW.department_id != OLD.department_id THEN
        SELECT name INTO dept_name FROM departments WHERE id = NEW.department_id;
        SET NEW.department_name = dept_name;
    END IF;
    
    IF NEW.course_id != OLD.course_id THEN
        SELECT name INTO crs_name FROM courses WHERE id = NEW.course_id;
        SET NEW.course_name = crs_name;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `student_profiles`
--

CREATE TABLE `student_profiles` (
  `profile_id` varchar(20) NOT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `permanent_address` text DEFAULT NULL,
  `current_address` text DEFAULT NULL,
  `province` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `barangay` varchar(100) NOT NULL,
  `zipcode` int(5) NOT NULL,
  `houseno_street` int(10) NOT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `birthplace` varchar(100) DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `spouse_name` varchar(100) DEFAULT NULL,
  `spouse_occupation` varchar(100) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civil_status` varchar(20) DEFAULT NULL,
  `year_level` varchar(20) DEFAULT NULL,
  `semester_first_enrolled` varchar(50) DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `father_contact` varchar(20) DEFAULT NULL,
  `father_occupation` varchar(100) DEFAULT NULL,
  `mother_name` text DEFAULT NULL,
  `mother_contact` varchar(20) DEFAULT NULL,
  `mother_occupation` varchar(100) DEFAULT NULL,
  `guardian_name` varchar(100) DEFAULT NULL,
  `guardian_relationship` varchar(50) DEFAULT NULL,
  `guardian_contact` varchar(20) DEFAULT NULL,
  `guardian_occupation` varchar(100) DEFAULT NULL,
  `siblings` int(11) DEFAULT NULL,
  `birth_order` varchar(100) DEFAULT NULL,
  `family_income` varchar(100) DEFAULT NULL,
  `elementary` text DEFAULT NULL,
  `secondary` varchar(100) DEFAULT NULL,
  `transferees` varchar(100) DEFAULT NULL,
  `course_factors` text DEFAULT NULL,
  `career_concerns` text DEFAULT NULL,
  `medications` text DEFAULT NULL,
  `medical_conditions` text DEFAULT NULL,
  `suicide_attempt` varchar(3) DEFAULT NULL,
  `suicide_reason` text DEFAULT NULL,
  `problems` text DEFAULT NULL,
  `family_problems` text NOT NULL,
  `fitness_activity` varchar(100) DEFAULT NULL,
  `fitness_frequency` varchar(20) DEFAULT NULL,
  `stress_level` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `signature_path` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_profiles`
--

INSERT INTO `student_profiles` (`profile_id`, `student_id`, `course_id`, `last_name`, `first_name`, `middle_name`, `permanent_address`, `current_address`, `province`, `city`, `barangay`, `zipcode`, `houseno_street`, `contact_number`, `email`, `gender`, `birthdate`, `birthplace`, `nationality`, `religion`, `spouse_name`, `spouse_occupation`, `age`, `civil_status`, `year_level`, `semester_first_enrolled`, `father_name`, `father_contact`, `father_occupation`, `mother_name`, `mother_contact`, `mother_occupation`, `guardian_name`, `guardian_relationship`, `guardian_contact`, `guardian_occupation`, `siblings`, `birth_order`, `family_income`, `elementary`, `secondary`, `transferees`, `course_factors`, `career_concerns`, `medications`, `medical_conditions`, `suicide_attempt`, `suicide_reason`, `problems`, `family_problems`, `fitness_activity`, `fitness_frequency`, `stress_level`, `created_at`, `signature_path`) VALUES
('Stu_pro_000000007', '202105703', 3, 'Gauel', 'Kim', 'Mojica', 'Kaytapos, Indang, Cavite, 4123, Philippines', 'Kaytapos, Indang, Cavite, 4123, Philippines', 'Cavite', 'Indang', '', 0, 0, '09123658974', 'kim@cvsu.com', 'Female', '1999-06-15', NULL, NULL, NULL, NULL, NULL, 25, 'Single', 'First Year', 'First Semester, 2024-2025', 'N/A', NULL, NULL, 'Mudra Bells', NULL, NULL, NULL, NULL, NULL, NULL, 0, 'Only Child', 'below 10,000', 'BLDA, Indang, 2014', 'OCT, Tagaytay, 2019', '', 'Pursuit of Knowledge, Moral Fulfilment, Peer Influence, Other: I am super Cute', 'I dont know and I am not sure what to do after graduation', 'NO MEDICATIONS', 'NO CONDITIONS', 'no', '', 'Alcohol/Substance Abuse, Eating Disorder', '', 'NO FITNESS', '', 'High', '2024-08-29 08:37:15', '/capstone1/student/uploads/student_signatures/signature_66d03335dc333.png'),
('Stu_pro_000000008', '201987895', 5, 'Jang', 'Won', 'Young', 'Hello, Rosario, Cavite, 4123, Philippines', 'Hello, Rosario, Cavite, 4123, Philippines', 'Cavite', 'Rosario', '', 0, 0, '09788885545', 'won@cvsu.edu.ph', 'Female', '2004-02-10', NULL, NULL, NULL, NULL, NULL, 20, 'Engaged', 'Third Year', 'First Semester, 2024-2025', 'N/A', NULL, NULL, 'Mudra Bells', NULL, NULL, NULL, NULL, NULL, NULL, 4, 'Second', 'above 50,000', 'BLDA, Indang, 2014', 'OCT, Tagaytay, 2019', '', 'Parents Decision/Choice; Status Recognition; Independence', 'I know what I want, but someone else thinks I should do something else; I don\'t know and I am not sure what to do after graduation', 'NO MEDICATIONS', 'NO MEDICAL CONDITIONS', 'no', '', 'NO PROBLEMS', '', NULL, NULL, 'low', '2024-08-29 09:14:21', '/capstone1/student/uploads/student_signatures/signature_66d03beb0d8db.png'),
('Stu_pro_000000010', '202105700', 1, 'Barbacena', 'Denzel Anthonny', 'Bacolod', 'San Juan, City Of Dasmariñas, Cavite, 4123, Philippines', 'San Juan, City Of Dasmariñas, Cavite, 4123, Philippines', 'Cavite', 'City Of Dasmariñas', '', 0, 0, '09123456789', 'denxel@cvsu.edu.ph', 'Male', '2002-02-22', NULL, NULL, NULL, NULL, NULL, 22, 'Domestic Partnership', 'Fifth Year', 'First Semester, 2024-2025', 'N/A', NULL, NULL, 'N/A', NULL, NULL, NULL, NULL, NULL, NULL, 0, 'Only Child', '11,000 - 20,000', 'DSAM, DASMA, 2014', 'NOTRE, TRECE, 2020', '', 'Financial Security after graduation, Childhood Dream, Leisure/Enjoyment', 'I think I am not capable of anything, Others: Too Cute', 'NO MEDICATIONS', 'Hypertension, Diabetes', 'yes', 'hello', 'NO PROBLEMS', '', 'Inuman', 'Everyday', 'High', '2024-08-30 11:04:04', '/capstone1/student/uploads/student_signatures/signature_66d1a71e841c5.png'),
('Stu_pro_000000017', '202005700', 1, 'Abutin', 'Julia Carla', 'Gonzaga', 'Javalera, City Of Cavite, Cavite, 4123, Philippines', 'Javalera, City Of Cavite, Cavite, 4123, Philippines', 'Cavite', 'City Of Cavite', '', 0, 0, '09557484658', 'julia@cvsu.edu.ph', 'Female', '2024-10-31', 'Manila', 'Filipino', 'Evangelical', 'Jungkook', 'Entertainer', 0, 'Married', 'First Year', 'Second Semester, 2022-2023', 'N/A', 'N/A', 'N/A', 'Mudra Bells', '09123658974', 'itchibells', 'Haruto', 'Boyfriend', '09557484658', 'Artist', 1, 'Eldest', '11,000 – 20,000', 'OCT, Indang, 2011', 'OCT, Tagaytay, 2019', ', , ', 'Financial Security after graduation; Challenge/Adventure; Moral Fulfilment', 'I need more information about my personal traits, interests, skills, and values; I have difficulty making a career decision/goal-setting; My parents have different goals for me', 'NO MEDICATIONS', 'NO MEDICAL CONDITIONS', 'no', '', 'NO PROBLEMS', '', 'NO FITNESS', NULL, 'high', '2024-10-31 12:22:23', '/capstone1/student/uploads/student_signatures/signature_672376e169522.png'),
('Stu_pro_000000021', '202102690', 1, 'MOJICA', 'NEIL TRISTHAN', 'NOVICIO', '213, Javalera, City Of Tagaytay, 4123 Cavite, Philippines', '213, Javalera, City Of Tagaytay, 4123 Cavite, Philippines', 'Cavite', 'City Of Tagaytay', '', 0, 0, '09107978629', 'neiltristhan.mojica@cvsu.edu.ph', 'MALE', '1996-06-04', 'Manila', 'American', 'Iglesia ni Cristo', 'Jungkook', 'Entertainer', 28, 'Married', 'Second Year', 'First Semester, 2021-2022', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'Haruto', 'Boyfriend', '09557484658', 'Artist', 2, 'Eldest', '11,000 – 20,000', 'BLDASS; Indang, cavite; 2011', 'OCT; Tagaytay, Manila; 2019', 'ANHS; Alfonso, Cavite; Vet', 'Parents Decision/Choice; Pursuit of Knowledge; Peer Influence; Other: I am super Cute', 'I need more information about certain course/s and occupation/s: Vulcanizing; I have many goals that conflict with each other', 'NO MEDICATIONS', 'Asthma, Hypertension, Diabetes, Insomnia, Vertigo', 'no', '', 'NO PROBLEMS', 'Depression; Aggression; Others: bullyinmg is wusghdsxuiwed', 'talon sa building', 'Everyday', 'high', '2024-11-17 11:23:54', '/capstone1/student/uploads/student_signatures/signature_6739d2bc66356.png'),
('Stu_pro_000000022', '202105706', 1, 'ESCOVER', 'MIGUEL JUAN', 'CASAMBROS', '214, Marahan 2, Alfonso, Cavite, 4123, Philippines', '214, Marahan 2, Alfonso, Cavite, 4123, Philippines', 'Cavite', 'Alfonso', 'Marahan 2', 4123, 214, '09911186546', 'migueljuan.escover@cvsu.edu.ph', 'Male', '2003-04-04', 'Manila', 'American', 'Judaism', NULL, NULL, 21, 'Widowed', 'Second Year', 'First Semester, 2024-2025', 'N/A', 'N/A', 'N/A', 'MudraBells', '09107978629', 'itchibells', 'Yoshinori', 'Boyfriend', '09123658974', 'Artist', 2, 'Youngest', '11,000 – 20,000', 'BLDA; Indang, Cavite; 2011', 'OCTTT;Tagaytay,Mars;2014', '', 'Financial Security after graduation; Childhood Dream; Leisure/Enjoyment; Status Recognition; Other: I am super Cute', 'I need more information about certain course/s and occupation/s: moves like jogger; I have difficulty making a career decision/goal-setting; Others: You light up me inside, whenever you are around', 'NO MEDICATIONS', 'NO MEDICAL CONDITIONS', 'no', '', 'NO PROBLEMS', 'Alcohol/Substance Abuse; Others: baby, I was born this way.', 'Inuman', '2-3 Month', 'high', '2024-11-18 05:09:33', '/capstone1/student/uploads/student_signatures/signature_673acc8fd91dd.png'),
('Stu_pro_000000023', '202002882', 1, 'DELA CRUZ', 'JUANA', 'B', '2222, Barangay 3, Alfonso, Cavite, 4123, Philippines', '2222, Barangay 3, Alfonso, Cavite, 4123, Philippines', 'Cavite', 'Alfonso', 'Barangay 3', 4123, 2222, '09911186546', 'juana.recto@cvsu.edu.ph', 'FEMALE', '2024-10-31', 'Manila', 'Filipino', 'Hinduism', NULL, NULL, 0, 'Single', 'Fourth Year', 'Second Semester, 2019-2020', 'Pudamstra', '09318762469', 'Nyogginng', 'Mudamstra', '09107978629', 'itchibells', 'Haruto', 'Boyfriend', '09788885545', 'Artist', 3, 'Eldest', '21,000 – 30,000', 'BLDA; Marahan, cavite; 2011', 'OCTTT; Tagaytay; 2019', '', 'Opportunity to help others/society; Location of School; Pursuit of Knowledge; Other; Other: suoeor shy wait', 'I need more information about certain course/s and occupation/s: iPad; I have difficulty making a career decision/goal-setting; Others: juntesa', 'NO MEDICATIONS', 'NO MEDICAL CONDITIONS', 'no', '', 'NO PROBLEMS', 'NO PROBLEMS', 'zumbaaaa', 'Everyday', 'low', '2024-11-22 14:43:23', '/capstone1/student/uploads/student_signatures/signature_67409901d630d.png'),
('Stu_pro_000000024', '202105294', 1, 'PANGANIBAN', 'CATHERINE L.', '', '214, Buck Estate, Alfonso, Cavite, 4123, Philippines', '214, Buck Estate, Alfonso, Cavite, 4123, Philippines', 'Cavite', 'Alfonso', 'Buck Estate', 4123, 214, '09788885545', 'catherine.panganiban@cvsu.edu.ph', 'FEMALE', '2024-12-06', 'Manila', 'Filipino', 'Aglipayan', 'Jungkook', 'Entertainer', 0, 'Married', 'Fifth Year', 'Second Semester, 2018-2019', 'N/A', 'N/A', 'N/A', 'Mudra Bells', '09060631106', 'itchibells', 'Haruto', 'Boyfriend', '09123658974', 'Artist', 0, 'Only Child', 'below-10,000', 'BLDA; Indang, hello; 2006', 'OCT; Tagaytay, Cavite; 2018', '', 'Financial Security after graduation; Challenge/Adventure; Other; Other: ayos ,ka ah', 'I need more information about certain course/s and occupation/s: vulcanizing; I think I am not capable of anything; I know what I want, but someone else thinks I should do something else', 'NO MEDICATIONS', 'NO MEDICAL CONDITIONS', 'yes', 'maris racal', 'Alcohol/Substance Abuse; Eating Disorder; Depression; Aggression; Others: nagwawala sa banyo', 'Depression', 'Inuman', 'Everyday', 'high', '2024-12-06 07:46:22', '/capstone1/student/uploads/student_signatures/signature_6752ac9f237d9.png');

-- --------------------------------------------------------

--
-- Table structure for table `student_violations`
--

CREATE TABLE `student_violations` (
  `id` int(11) NOT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `incident_report_id` varchar(20) NOT NULL,
  `violation_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `student_name` varchar(100) NOT NULL,
  `student_course` varchar(100) DEFAULT NULL,
  `student_year_level` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_violations`
--

INSERT INTO `student_violations` (`id`, `student_id`, `incident_report_id`, `violation_date`, `status`, `student_name`, `student_course`, `student_year_level`) VALUES
(253, '202002884', 'CEIT-24-25-0001', '2024-11-19 09:34:20', 'Settled', 'JUANE DELA CRUZ', 'BS Information Technology', 'First Year'),
(254, '202002882', 'CEIT-24-25-0002', '2024-11-19 09:33:44', 'For Meeting', 'JUANA DELA CRUZ', 'BS Information Technology', 'First Year'),
(255, NULL, 'CEIT-24-25-0002', '2024-11-19 09:33:44', 'For Meeting', 'Giro daw', NULL, NULL),
(258, '202002882', 'CEIT-24-25-0004', '2024-11-20 06:52:03', 'For Meeting', 'JUANA DELA CRUZ', 'BS Information Technology', 'First Year'),
(259, '202002884', 'CEIT-24-25-0004', '2024-11-20 06:52:03', 'For Meeting', 'JUANE DELA CRUZ', 'BS Information Technology', 'First Year'),
(260, '202002882', 'CEIT-24-25-0005', '2024-11-20 06:58:22', 'Settled', 'JUANA DELA CRUZ', 'BS Information Technology', 'First Year'),
(261, '202002882', 'CEIT-24-25-0006', '2024-11-20 07:23:31', 'For Meeting', 'JUANA DELA CRUZ', 'BS Information Technology', 'First Year'),
(264, NULL, 'CEIT-24-25-0008', '2024-11-25 07:53:00', 'For Meeting', 'secret', NULL, NULL),
(265, '202105706', 'CEIT-24-25-0008', '2024-11-25 07:53:00', 'For Meeting', 'MIGUEL JUAN ESCOVER', 'BS Information Technology', 'Fourth Year'),
(266, '202105706', 'CEIT-24-25-0009', '2024-12-09 07:09:04', 'For Meeting', 'MIGUEL JUAN ESCOVER', 'BS Information Technology', 'Fourth Year'),
(267, '202105706', 'CEIT-24-25-0010', '2024-12-10 04:52:07', 'For Meeting', 'MIGUEL JUAN ESCOVER', 'BS Information Technology', 'Fourth Year'),
(268, '202105706', 'CEIT-24-25-0011', '2024-12-10 04:52:07', 'pending', 'MIGUEL JUAN ESCOVER', 'BS Information Technology', 'Fourth Year');

--
-- Triggers `student_violations`
--
DELIMITER $$
CREATE TRIGGER `before_student_violation_insert` BEFORE INSERT ON `student_violations` FOR EACH ROW BEGIN
            DECLARE student_fullname VARCHAR(100);
            DECLARE student_course_name VARCHAR(100);
            DECLARE student_year VARCHAR(20);
            
            IF NEW.student_id IS NOT NULL THEN
                SELECT 
                    CONCAT(ts.first_name, ' ', ts.last_name),
                    c.name,
                    s.year_level
                INTO 
                    student_fullname,
                    student_course_name,
                    student_year
                FROM tbl_student ts
                LEFT JOIN sections s ON ts.section_id = s.id
                LEFT JOIN courses c ON s.course_id = c.id
                WHERE ts.student_id = NEW.student_id;
                
                SET NEW.student_name = student_fullname;
                SET NEW.student_course = student_course_name;
                SET NEW.student_year_level = student_year;
            END IF;
        END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`, `email`, `name`, `profile_picture`, `created_at`, `updated_at`, `reset_token`, `reset_token_expires`) VALUES
(4, 'CEIT_admin', '$2y$10$jeF/0EyhPXw8imTDzOpK0eyAVnCBZFjbQqYCDWQIwT5WBkw7kmaim', 'ceitguidanceoffice@gmail.com', 'CEIT ADMIN', 'admin_profiles/66dfe5c827e3a.jpg', '2024-09-09 21:37:48', '2024-09-10 15:52:13', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_adviser`
--

CREATE TABLE `tbl_adviser` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_adviser`
--

INSERT INTO `tbl_adviser` (`id`, `username`, `password`, `email`, `name`, `profile_picture`, `created_at`, `updated_at`, `reset_token`, `reset_token_expires`) VALUES
(1, 'adviser1', '$2y$10$gy8cMdVedMAzsPcXB3TcMOCldNUqCFC62xp.X0Ag7aZhxEIyxnJUS', 'adviser1@cvsu.edu.ph', 'Adviser One', 'adviser_profiles/66a9a6f6a1524.jpg', '2024-07-19 18:01:28', '2024-09-12 18:34:17', NULL, NULL),
(2, 'adviser2', '$2y$10$Iown7rmnbTsja5eNsjnNo.1tjtKG38ymg4ktPTTUYqrchzYLszphu', 'adviser2@cvsu.edu.ph', 'Adviser Two', 'adviser_profiles/66b1dbea19489.png', '2024-07-19 18:01:28', '2024-09-09 22:47:37', NULL, NULL),
(5, 'Simeon2024', '$2y$10$BqtAbxe2juRWPtv8G8bs0u/WL4C1gl1Nr.NfSlCThuWWDh6ZlFigW', 'miguelescover.cvsu@gmail.com', 'Simeon Daez', NULL, '2024-10-01 14:16:25', '2024-11-22 23:12:09', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_adviser_tables`
--

CREATE TABLE `tbl_adviser_tables` (
  `table_id` int(11) NOT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_counselor`
--

CREATE TABLE `tbl_counselor` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_counselor`
--

INSERT INTO `tbl_counselor` (`id`, `username`, `password`, `email`, `name`, `profile_picture`, `created_at`, `updated_at`, `reset_token`, `reset_token_expires`) VALUES
(7, 'counselor1', '$2y$10$I2UdQpfoRogIlFoK.4iRy.ahtfgaGmfdnojkf6q0lLcEuChVTEyRG', 'counselor@gmail.com', 'Angelyn Benedictura', NULL, '2024-09-09 13:45:07', '2024-12-04 06:11:26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dean`
--

CREATE TABLE `tbl_dean` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_dean`
--

INSERT INTO `tbl_dean` (`id`, `username`, `password`, `email`, `name`, `profile_picture`, `created_at`, `updated_at`, `reset_token`, `reset_token_expires`) VALUES
(1, 'dean1', '$2y$10$wjtiVPvV3v6YyEDnXYvmKeNBdTNkEyqaOYJAjrp/kuKA3jVZVEVWK', 'dean1@cvsu.edu.ph', 'CEIT Dean One', 'path/to/profile1.jpg', '2024-07-21 10:40:40', '2024-09-10 06:51:55', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_facilitator`
--

CREATE TABLE `tbl_facilitator` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_facilitator`
--

INSERT INTO `tbl_facilitator` (`id`, `username`, `password`, `email`, `name`, `profile_picture`, `created_at`, `updated_at`, `reset_token`, `reset_token_expires`) VALUES
(1, 'facilitator1', '$2y$10$oVguZM/a1yi.sgJAhIkGfeb2VXQCDZzp8RTs8lY3TXzQqLV4DcZym', 'facilitator1@cvsu.edu.ph', 'Ma\'am gladys', 'path/to/profile1.jpg', '2024-07-21 10:40:55', '2024-12-09 06:16:10', NULL, NULL),
(2, 'facilitator2', '$2y$10$iQIhHusJnQdCcObv.Tb0gOGbuBz6VYUIhgFK5kLgGYMAMqLsaXO9e', 'ceitguidanceoffice@gmail.com', 'Facilitator Two', NULL, '2024-09-09 15:07:12', '2024-09-09 15:07:12', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guard`
--

CREATE TABLE `tbl_guard` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_guard`
--

INSERT INTO `tbl_guard` (`id`, `username`, `password`, `email`, `name`, `profile_picture`, `created_at`, `updated_at`, `reset_token`, `reset_token_expires`) VALUES
(1, 'guard1', '$2y$10$Snjkf3JpaooLNQdndXijy.RUN5TkWxQSxulc.plQLRWcaVM0dZxPa', 'nehepi2158@cpaurl.com', 'Guard One', 'path/to/profile1.jpg', '2024-07-21 10:41:17', '2024-11-19 08:35:40', NULL, NULL),
(2, 'guard2', '$2y$10$7Awt9/OOL48GlbMyCE0lQul44Y614FEmH9H5bmHnqicE/k4fyWWMe', 'guard@cvsu.edu.ph', 'Guard two', '', '2024-07-30 13:31:23', '2024-10-18 07:36:55', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_instructor`
--

CREATE TABLE `tbl_instructor` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_instructor`
--

INSERT INTO `tbl_instructor` (`id`, `username`, `password`, `email`, `name`, `profile_picture`, `created_at`, `updated_at`, `reset_token`, `reset_token_expires`) VALUES
(1, 'instructor1', '$2y$10$j/9KuTHH.B0vxYFnIjhuVOS6rmJyJNm5VG7IzIh1RhkowBY6f4lT.', 'instructor1@cvsu.edu.ph', 'Instructor One', 'path/to/profile1.jpg', '2024-07-21 18:41:31', '2024-09-10 15:04:08', NULL, NULL),
(2, 'instructor2', '$2y$10$2E1m/kMUANqAQsV2TalycuKdR2LBrrCzJoFEdHUrKh3QayT16AJNC', 'instructor2@cvsu.com', 'Instructor Two', NULL, '2024-08-29 15:02:18', '2024-09-16 18:29:18', NULL, NULL),
(3, 'instructor3', '$2y$10$9IEQUVi8zbs83zkURRgN5.O69w1vaGMyeBix883BN/xSqxtqM3R2G', 'instructor3@gmail.com', 'Instructor Three', NULL, '2024-09-09 23:12:11', '2024-10-08 12:38:33', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `student_id` varchar(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `section_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`student_id`, `password`, `email`, `profile_picture`, `created_at`, `updated_at`, `section_id`, `first_name`, `middle_name`, `last_name`, `gender`, `reset_token`, `reset_token_expires`) VALUES
('201312664', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JANINE ANNE B.', NULL, 'MENDOZA', 'FEMALE', NULL, NULL),
('201987895', 'user1', 'won@cvsu.edu.ph', NULL, '2024-08-29 16:17:10', '2024-08-29 16:17:10', 5, 'Won', 'Young', 'Jang', 'Female', NULL, NULL),
('202002881', NULL, NULL, NULL, '2024-11-18 14:44:51', '2024-11-18 14:44:51', 2411907, 'JUAN', 'A', 'DELA CRUZ', 'FEMALE', NULL, NULL),
('202002882', '$2y$10$OAM1OVpnDUiKhwQdndnZYO.0t3EXkNCdkVydAqKIPN.Q78C1W0F3W', 'juana.recto@cvsu.edu.ph', NULL, '2024-11-18 14:44:51', '2024-11-20 13:45:53', 2411907, 'JUANA', 'B', 'DELA CRUZ', 'FEMALE', NULL, NULL),
('202002883', NULL, NULL, NULL, '2024-11-18 14:44:51', '2024-11-18 14:44:51', 2411907, 'JUANCHO', 'C', 'DELA CRUZ', 'MALE', NULL, NULL),
('202002884', NULL, NULL, NULL, '2024-11-18 14:44:51', '2024-11-18 14:44:51', 2411907, 'JUANE', 'D', 'DELA CRUZ', 'FEMALE', NULL, NULL),
('202002885', NULL, NULL, NULL, '2024-11-18 14:44:51', '2024-11-18 14:44:51', 2411907, 'JUNE', 'E', 'DELA CRUZ', 'MALE', NULL, NULL),
('202005700', '$2y$10$no7znbU3V6cxudK3SpK79uHMw13GuE4YR.n61NCjH0i6122vRrR0y', 'julia@cvsu.edu.ph', NULL, '2024-08-31 23:25:10', '2024-09-14 22:32:40', 11, 'Julia Carla', 'Gonzaga', 'Abutin', 'Female', NULL, NULL),
('202005706', '$2y$10$lJ/xylFshJOZm9NXebSt3eW4Tq8PD9j2WO7YTO5Nwi4QlvRelfrz.', 'john@cvsu.edu.ph', NULL, '2024-08-31 23:18:21', '2024-09-14 22:32:48', 11, 'John Robin', 'Abanilla', 'Estrella', 'Male', NULL, NULL),
('202011099', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'ANGELO P.', NULL, 'LAGMAY', 'MALE', NULL, NULL),
('202011307', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'BAMBY', 'B', 'REQUILLO', 'FEMALE', NULL, NULL),
('202011451', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'KAYRON MARK', 'J', 'BURZON', 'MALE', NULL, NULL),
('202011511', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'CARIAH KIRSTINE', 'B', 'CATANGUI', 'FEMALE', NULL, NULL),
('202011697', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'CHRISTIAN JOHN R.', NULL, 'ESGUERRA', 'MALE', NULL, NULL),
('202011997', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'KRISTIAN CALEB', 'A', 'MAGULING', 'MALE', NULL, NULL),
('202013012', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JOLLO', 'R', 'PANALIGAN', 'MALE', NULL, NULL),
('202013770', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'MARISSA', 'S', 'MANUBAY', 'FEMALE', NULL, NULL),
('202014202', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'ANGEL', 'M', 'OCMEN', 'FEMALE', NULL, NULL),
('202014937', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'MARK CHRISTIAN', 'D', 'TABUZO', 'MALE', NULL, NULL),
('202015172', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'XANDER LEE', 'A', 'SARITA', 'MALE', NULL, NULL),
('202015383', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'MARCHEN D.', NULL, 'OBEDIENTE', 'FEMALE', NULL, NULL),
('202015572', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JASPER ANDREI P.', NULL, 'PIELAGO', 'MALE', NULL, NULL),
('202015825', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JARED CHRYSTIANE C.', NULL, 'NUESTRO', 'MALE', NULL, NULL),
('202102253', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JENSON YEHD G.', NULL, 'BUENAVENTURA', 'MALE', NULL, NULL),
('202102317', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'CLARK ANGELO P.', NULL, 'MENDOZA', 'MALE', NULL, NULL),
('202102690', '$2y$10$.mMCBhwG0qG8/RawAzg1O.VsDPJ6lsceSYjUQMvM0KUqwagRJpICm', 'neiltristhan.mojica@cvsu.edu.ph', NULL, '2024-10-03 16:04:37', '2024-12-06 11:50:55', 2428698, 'NEIL TRISTHAN', 'N.', 'MOJICA', 'MALE', '36d51f658cdba80580dada37c21db031b893322dc563eada05732a0022e4de50ecd78b2aee95ff1f2997e0b3c9155c870128', '2024-12-06 12:50:55'),
('202102768', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JOHN PATRICK', 'B', 'LUCAÃAS', 'MALE', NULL, NULL),
('202102881', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'MARK KEN FELIX', 'P', 'MADRID', 'MALE', NULL, NULL),
('202102882', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JOHNDELL S.', NULL, 'GENER', 'MALE', NULL, NULL),
('202102884', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JOHN JAYSON', 'T', 'MAGBOO', 'MALE', NULL, NULL),
('202102887', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JULIANNE CARLA C.', NULL, 'ABUTIN', 'FEMALE', NULL, NULL),
('202102908', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'AIRA LIZETTE', 'B', 'CABRAL', 'FEMALE', NULL, NULL),
('202102945', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'HANZEL L.', NULL, 'RAMIREZ', 'MALE', NULL, NULL),
('202102956', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JOHN LESTER B.', NULL, 'ARANETA', 'MALE', NULL, NULL),
('202103574', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'SHINBY M.', NULL, 'YAO', 'FEMALE', NULL, NULL),
('202103601', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'CHERRIE MAE A.', NULL, 'PEÃALOSA', 'FEMALE', NULL, NULL),
('202103642', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'EMILYN', 'C', 'MOJICA', 'FEMALE', NULL, NULL),
('202104060', '$2y$10$pV1xfgbOXsAazI4i6FyjceSudXvPTW46yiGhlVIP25yWhPOpSGLzS', 'ramuelbryant.cruzada@cvsu.edu.ph', NULL, '2024-10-03 16:04:37', '2024-10-03 16:07:31', 2428698, 'RAMUEL BRYANT R.', NULL, 'CRUZADA', 'MALE', NULL, NULL),
('202104088', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'ALEXANDER V.', NULL, 'LLANO', 'MALE', NULL, NULL),
('202104158', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'MICHAEL', 'E', 'LAGATIC', 'MALE', NULL, NULL),
('202104176', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'CYNDELL A.', NULL, 'DADULA', 'FEMALE', NULL, NULL),
('202104261', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'ALESSANDRA G.', NULL, 'CASTILLAS', 'FEMALE', NULL, NULL),
('202104361', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'DOMING H.', NULL, 'RICALDE', 'MALE', NULL, NULL),
('202104364', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'PRINCESS NICOLE', 'A', 'PADILLA', 'FEMALE', NULL, NULL),
('202105204', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'KARL CHESTER', 'C', 'LODANA', 'MALE', NULL, NULL),
('202105206', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JOHNBERT CHRISTIENE', 'D', 'TAGLE', 'MALE', NULL, NULL),
('202105212', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JHANNAH BERNADETTE', 'Q', 'ALBINO', 'FEMALE', NULL, NULL),
('202105294', '$2y$10$YU3PUZTFrvaA/uadZ8lByuQplqPSPvlCOwEUKsm3YQnZDVf9sco2.', 'catherine.panganiban@cvsu.edu.ph', NULL, '2024-10-03 16:04:37', '2024-10-03 16:09:19', 2428698, 'CATHERINE L.', NULL, 'PANGANIBAN', 'FEMALE', NULL, NULL),
('202105320', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'MARY JOY T.', NULL, 'VECINO', 'FEMALE', NULL, NULL),
('202105470', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JAMES EZEKIEL', 'L', 'DAQUIS', 'MALE', NULL, NULL),
('202105558', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'HERSHEYLINE NHADYN B.', NULL, 'DUDAS', 'FEMALE', NULL, NULL),
('202105559', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'LOUIELA MAE G.', NULL, 'APOLONA', 'FEMALE', NULL, NULL),
('202105560', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'CHYNNA LARIZE S.', NULL, 'LAYOS', 'FEMALE', NULL, NULL),
('202105592', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JAISSEN YVES', 'S', 'NAZARENO', 'MALE', NULL, NULL),
('202105700', '$2y$10$.GwE9VstYR.V8VLn6FRdX.6irHu/9A/IF5yHu1pcp9yV.yJISUS82', 'denxel@cvsu.edu.ph', NULL, '2024-08-29 16:12:16', '2024-10-02 18:42:56', NULL, 'IAN GABRIELLE B.', 'Bacolod', 'TEODORO', 'MALE', NULL, NULL),
('202105701', '$2y$10$LjoF5.lcbSDHxk4Jn3C6UuJIdrp//LTSYrwEFccDCNKl9ocJicdB2', 'marie1@cvsu.edu.ph', NULL, '2024-08-29 16:11:46', '2024-09-12 18:53:05', 1, 'Marie', 'Gonzaga', 'Tio', 'Female', NULL, NULL),
('202105702', '$2y$10$ctkNZvOcwrBy8yvC.NviPOkAkmdOcKAl4xZn9DCTwy/W1CSrljmwi', 'cyn@cvsu.edu.ph', NULL, '2024-08-29 16:13:06', '2024-09-12 18:52:36', 1, 'Cyndelll', 'Villa-or', 'Dadula', 'Female', NULL, NULL),
('202105703', 'password1', 'kim@cvsu.com', NULL, '2024-08-29 16:16:10', '2024-08-29 16:16:10', 4, 'Kim', 'Mojica', 'Gauel', 'Female', NULL, NULL),
('202105706', '$2y$10$YY9He3QHShLtrtlX1lCSjOZpLtO13cgFhdK37TtwarKOZv/oHTbKu', 'migueljuan.escover@cvsu.edu.ph', NULL, '2024-11-09 13:24:14', '2024-11-09 13:26:04', 2428698, 'MIGUEL JUAN', 'CASAMBROS', 'ESCOVER', 'Male', NULL, NULL),
('202105723', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'SHAWN RAVEN', 'L', 'FERRER', 'MALE', NULL, NULL),
('202105791', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JUDE', 'F', 'BAUTISTA', 'MALE', NULL, NULL),
('202106047', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JULIUS RUIZ', 'M', 'DILLERA', 'MALE', NULL, NULL),
('202106063', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'EMME R.', NULL, 'MEJICA', 'FEMALE', NULL, NULL),
('202106067', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'AAROL JAELO M.', NULL, 'HINTAY', 'MALE', NULL, NULL),
('202106072', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'RICA MAE A.', NULL, 'DUMAGAT', 'FEMALE', NULL, NULL),
('202106075', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'PRINCESS MAE J.', NULL, 'TAN', 'FEMALE', NULL, NULL),
('202106101', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'GWYNETH KYLA', 'C', 'CIRIACO', 'FEMALE', NULL, NULL),
('202106114', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'ANGEL MARIE', 'N', 'DEDASE', 'FEMALE', NULL, NULL),
('202106149', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JHON VHIC', 'C', 'BALLERA', 'MALE', NULL, NULL),
('202106160', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JESUS T.', NULL, 'CONSTANTE', 'MALE', NULL, NULL),
('202106196', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JOSHUA F.', NULL, 'PENUELA', 'MALE', NULL, NULL),
('202106240', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'ARRIANE FAITH', 'A', 'HEMBRADOR', 'FEMALE', NULL, NULL),
('202106258', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'CRISTINE MAY', 'C', 'MONCHEZ', 'FEMALE', NULL, NULL),
('202106259', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'LORENZO DANIEL', 'A', 'JARATA', 'MALE', NULL, NULL),
('202106271', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'MILLARD JOHN', 'C', 'ORTILLANO', 'MALE', NULL, NULL),
('202106281', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'JOHN DAVE', 'C', 'SUYAT', 'MALE', NULL, NULL),
('202106434', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'MARY KATHLEEN E.', NULL, 'MANALO', 'FEMALE', NULL, NULL),
('202106470', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'CLARK FERNANDO POE', 'G', 'MIRA', 'MALE', NULL, NULL),
('202106473', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'MARIE DANICE G.', NULL, 'TIO', 'FEMALE', NULL, NULL),
('202106707', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'DARLENE', 'R', 'SOLTES', 'FEMALE', NULL, NULL),
('202106720', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'ABEGAIL L.', NULL, 'BARREDO', 'FEMALE', NULL, NULL),
('202106746', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'EURICA MAE', 'D', 'BORCE', 'FEMALE', NULL, NULL),
('202107410', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'BYRON', 'Q', 'PALOMERAS', 'MALE', NULL, NULL),
('202107461', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JOVENRY LLOYD L.', NULL, 'VILLA-OR', 'MALE', NULL, NULL),
('202107555', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'FERDYLORN R.', NULL, 'UDANI', 'MALE', NULL, NULL),
('202107556', NULL, NULL, NULL, '2024-10-03 16:04:37', '2024-10-03 16:04:37', 2428698, 'JOHN ROBIN A.', NULL, 'ESTRELLA', 'MALE', NULL, NULL),
('202108636', NULL, NULL, NULL, '2024-11-25 15:41:05', '2024-11-25 15:41:05', 2425375, 'GENE ROBERT', 'D', 'MANGUERA', 'MALE', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cavite_barangays`
--
ALTER TABLE `cavite_barangays`
  ADD PRIMARY KEY (`id`),
  ADD KEY `city_id` (`city_id`);

--
-- Indexes for table `cavite_cities`
--
ALTER TABLE `cavite_cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `counselor_meetings`
--
ALTER TABLE `counselor_meetings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `referral_id` (`referral_id`),
  ADD KEY `incident_report_id` (`incident_report_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `document_requests`
--
ALTER TABLE `document_requests`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `incident_reports`
--
ALTER TABLE `incident_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `incident_witnesses`
--
ALTER TABLE `incident_witnesses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `incident_witnesses_ibfk_1` (`incident_report_id`),
  ADD KEY `incident_witnesses_ibfk_2` (`witness_id`);

--
-- Indexes for table `meetings`
--
ALTER TABLE `meetings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `incident_report_id` (`incident_report_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_type_user_id_index` (`user_type`,`user_id`);

--
-- Indexes for table `pending_incident_reports`
--
ALTER TABLE `pending_incident_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `guard_id` (`guard_id`);

--
-- Indexes for table `pending_incident_witnesses`
--
ALTER TABLE `pending_incident_witnesses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pending_report_id` (`pending_report_id`);

--
-- Indexes for table `pending_student_violations`
--
ALTER TABLE `pending_student_violations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pending_report_id` (`pending_report_id`);

--
-- Indexes for table `referrals`
--
ALTER TABLE `referrals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_referral_status` (`status`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `idx_incident_student` (`incident_report_id`,`student_id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_section` (`department_id`,`course_id`,`year_level`,`section_no`,`academic_year`),
  ADD KEY `fk_sections_course` (`course_id`),
  ADD KEY `fk_sections_adviser` (`adviser_id`);

--
-- Indexes for table `student_profiles`
--
ALTER TABLE `student_profiles`
  ADD PRIMARY KEY (`profile_id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `student_violations`
--
ALTER TABLE `student_violations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_violations_ibfk_2` (`incident_report_id`),
  ADD KEY `student_violations_ibfk_1` (`student_id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_adviser`
--
ALTER TABLE `tbl_adviser`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_adviser_tables`
--
ALTER TABLE `tbl_adviser_tables`
  ADD PRIMARY KEY (`table_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `tbl_counselor`
--
ALTER TABLE `tbl_counselor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_dean`
--
ALTER TABLE `tbl_dean`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_facilitator`
--
ALTER TABLE `tbl_facilitator`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_guard`
--
ALTER TABLE `tbl_guard`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_instructor`
--
ALTER TABLE `tbl_instructor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_section` (`section_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cavite_barangays`
--
ALTER TABLE `cavite_barangays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=955;

--
-- AUTO_INCREMENT for table `cavite_cities`
--
ALTER TABLE `cavite_cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `counselor_meetings`
--
ALTER TABLE `counselor_meetings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `incident_witnesses`
--
ALTER TABLE `incident_witnesses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=183;

--
-- AUTO_INCREMENT for table `meetings`
--
ALTER TABLE `meetings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=198;

--
-- AUTO_INCREMENT for table `pending_incident_reports`
--
ALTER TABLE `pending_incident_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `pending_incident_witnesses`
--
ALTER TABLE `pending_incident_witnesses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `pending_student_violations`
--
ALTER TABLE `pending_student_violations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `referrals`
--
ALTER TABLE `referrals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2497840;

--
-- AUTO_INCREMENT for table `student_violations`
--
ALTER TABLE `student_violations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=269;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_adviser`
--
ALTER TABLE `tbl_adviser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_adviser_tables`
--
ALTER TABLE `tbl_adviser_tables`
  MODIFY `table_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_counselor`
--
ALTER TABLE `tbl_counselor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_dean`
--
ALTER TABLE `tbl_dean`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_facilitator`
--
ALTER TABLE `tbl_facilitator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_guard`
--
ALTER TABLE `tbl_guard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_instructor`
--
ALTER TABLE `tbl_instructor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cavite_barangays`
--
ALTER TABLE `cavite_barangays`
  ADD CONSTRAINT `cavite_barangays_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `cavite_cities` (`id`);

--
-- Constraints for table `counselor_meetings`
--
ALTER TABLE `counselor_meetings`
  ADD CONSTRAINT `counselor_meetings_ibfk_1` FOREIGN KEY (`referral_id`) REFERENCES `referrals` (`id`),
  ADD CONSTRAINT `counselor_meetings_ibfk_2` FOREIGN KEY (`incident_report_id`) REFERENCES `incident_reports` (`id`);

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `incident_witnesses`
--
ALTER TABLE `incident_witnesses`
  ADD CONSTRAINT `incident_witnesses_ibfk_1` FOREIGN KEY (`incident_report_id`) REFERENCES `incident_reports` (`id`),
  ADD CONSTRAINT `incident_witnesses_ibfk_2` FOREIGN KEY (`witness_id`) REFERENCES `tbl_student` (`student_id`) ON DELETE SET NULL;

--
-- Constraints for table `pending_incident_reports`
--
ALTER TABLE `pending_incident_reports`
  ADD CONSTRAINT `pending_incident_reports_ibfk_1` FOREIGN KEY (`guard_id`) REFERENCES `tbl_guard` (`id`);

--
-- Constraints for table `pending_incident_witnesses`
--
ALTER TABLE `pending_incident_witnesses`
  ADD CONSTRAINT `pending_incident_witnesses_ibfk_1` FOREIGN KEY (`pending_report_id`) REFERENCES `pending_incident_reports` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pending_student_violations`
--
ALTER TABLE `pending_student_violations`
  ADD CONSTRAINT `pending_student_violations_ibfk_1` FOREIGN KEY (`pending_report_id`) REFERENCES `pending_incident_reports` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `referrals`
--
ALTER TABLE `referrals`
  ADD CONSTRAINT `referrals_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `tbl_student` (`student_id`),
  ADD CONSTRAINT `referrals_ibfk_2` FOREIGN KEY (`incident_report_id`) REFERENCES `incident_reports` (`id`);

--
-- Constraints for table `sections`
--
ALTER TABLE `sections`
  ADD CONSTRAINT `fk_sections_adviser` FOREIGN KEY (`adviser_id`) REFERENCES `tbl_adviser` (`id`),
  ADD CONSTRAINT `fk_sections_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  ADD CONSTRAINT `fk_sections_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `student_profiles`
--
ALTER TABLE `student_profiles`
  ADD CONSTRAINT `student_profiles_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `student_violations`
--
ALTER TABLE `student_violations`
  ADD CONSTRAINT `student_violations_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `tbl_student` (`student_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `student_violations_ibfk_2` FOREIGN KEY (`incident_report_id`) REFERENCES `incident_reports` (`id`);

--
-- Constraints for table `tbl_adviser_tables`
--
ALTER TABLE `tbl_adviser_tables`
  ADD CONSTRAINT `tbl_adviser_tables_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `tbl_adviser` (`id`);

--
-- Constraints for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD CONSTRAINT `fk_section` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
