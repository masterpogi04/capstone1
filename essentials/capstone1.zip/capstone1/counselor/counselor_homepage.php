<?php
session_start();
include '../db.php';

// Ensure the user is logged in and is a counselor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'counselor') {
    header("Location: ../login.php");
    exit();
}

// Function to fetch notifications
function fetchNotifications($connection, $counselor_id) {
    $query = "SELECT * FROM notifications 
              WHERE user_type = 'counselor' 
              AND user_id = ? 
              AND is_read = 0 
              ORDER BY created_at DESC 
              LIMIT 5";
    $stmt = $connection->prepare($query);
    $stmt->bind_param("i", $counselor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

$counselor_id = $_SESSION['user_id'];

// Fetch the counselor's details from the database
$stmt = $connection->prepare("SELECT name, profile_picture FROM tbl_counselor WHERE id = ?");
if ($stmt === false) {
    die("Prepare failed: " . $connection->error);
}
$stmt->bind_param("i", $counselor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $counselor = $result->fetch_assoc();
    $name = $counselor['name'];
    $profile_picture = $counselor['profile_picture'];
} else {
    die("Counselor not found.");
}

// Fetch notifications
$notifications = fetchNotifications($connection, $counselor_id);

// Handle notification deletion
if (isset($_POST['delete_notification'])) {
    $notification_id = $_POST['notification_id'];
    $delete_query = "DELETE FROM notifications WHERE id = ? AND user_id = ?";
    $delete_stmt = $connection->prepare($delete_query);
    $delete_stmt->bind_param("ii", $notification_id, $counselor_id);
    $delete_stmt->execute();
    exit();
}
mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CEIT - Guidance Office</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        body {
            background-color: #FAF3E0;
            font-family: Arial;
        }
        .sidebar {
            height: 100vh;
            background-color: #1A6E47;
            color: white;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            display: block;
            padding: 10px 15px;
            text-decoration: none;
        }
        .sidebar a:hover, .sidebar a.active {
            background-color: #F2A54B;
        }
        .header {
            background-color: #F4A261;
            padding: 10px;
            color: black;
            font-family: Arial;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .main-content {
            padding: 0;
            position: relative;
            min-height: 100vh;
        }  
        .welcome-text {
            position: relative;
            background-image: url('cvsu1.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 50px;
            text-align: left;
            margin-bottom: 20px;
        }
        .welcome-text::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 128, 0, 0.7);
            z-index: 0;
        }
        .welcome-text h2, .welcome-text h3 {
            position: relative;
            z-index: 1;
        }
        .h2 {
            font-family: serif;
            font-size: 60px;
            font-weight: 700;
        }
        h3 {
            font-family: serif;
            font-size: 40px;
        }
        .manage-buttons {
            display: flex;
            justify-content: center;
            padding: 20px;
        }
        .manage-buttons a {
            margin: 0 10px;
        }
        .manage-buttons button {
            background-color: #0f6a1a;
            color: white;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s, transform 0.3s;
        }
        .manage-buttons button:hover {
            background-color: #218838;
            transform: translateY(-3px);
        }
        .footer {
            background-color: #F4A261;
            padding: 10px;
            color: black;
            text-align: center;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
        .profile-section {
            display: flex;
            align-items: center;
            flex-direction: column;
            padding: 15px;
        }
        .profile-section img {
            margin-top: 20px;
            width: 100px;
            height: 100px;
            border: 2px solid white;
            border-radius: 50%;
        }
        .profile-section p {
            margin-top: 10px;
            font-weight: bold;
        }
        .notification-icon {
            font-size: 24px;
            color: #FFFFFF;
            cursor: pointer;
            transition: color 0.3s;
        }
        .notification-icon:hover {
            color: #F2A54B;
        }
        .notification-panel {
            position: fixed;
            top: 60px;
            right: 20px;
            width: 300px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 10px;
            max-height: 400px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }
        .notification-item {
            padding: 10px;
            border-bottom: 1px solid #dee2e6;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .delete-notification {
            background: none;
            border: none;
            color: #dc3545;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 sidebar">
                <div class="profile-section text-center">
                    <img src="<?php echo htmlspecialchars($profile_picture); ?>" class="rounded-circle" alt="Profile Picture">
                    <p><?php echo htmlspecialchars($name); ?></p>
                </div>
                <a href="counselor_homepage.php">Home</a>
                <a href="counselor_myprofile.php">My Profile</a>
                <a href="help_support_counselor.php">Help & Support</a>
                <a class="nav-link" href="../login.php" onclick="return confirm('Are you sure you want to log out?')">Log Out</a>
            </nav>
            <main class="col-md-10 main-content">
                <div class="header">
                    <h1>CEIT - GUIDANCE OFFICE</h1>
                    <i class="fas fa-bell notification-icon" onclick="toggleNotifications()"></i>
                </div>
                <div class="welcome-text">
                    <h2 class='h2'>WELCOME, <?php echo htmlspecialchars($name); ?>!!</h2>
                </div>
                <div class="manage-buttons">
                        <a href="view_referrals_page.php"><button>View Referrals</button></a>                   
                        <a href="view_referrals_done.php"><button>View Done Referrals</button></a>
                </div>
                <div class="footer">
                   <p>&copy; 2024 All Rights Reserved</p> 
                </div>
            </main>
        </div>
    </div>

    <div class="notification-panel" id="notificationPanel">
        <h5>Notifications</h5>
        <?php if (empty($notifications)): ?>
            <p>No new notifications</p>
        <?php else: ?>
            <?php foreach ($notifications as $notif): ?>
                <div class="notification-item" id="notification-<?php echo $notif['id']; ?>">
                    <a href="<?php echo htmlspecialchars($notif['link']); ?>"><?php echo htmlspecialchars($notif['message']); ?></a>
                    <small><?php echo htmlspecialchars($notif['created_at']); ?></small>
                    <button class="delete-notification" onclick="deleteNotification(<?php echo $notif['id']; ?>)">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script>
    function toggleNotifications() {
        var panel = document.getElementById('notificationPanel');
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }

    function deleteNotification(notificationId) {
        if (confirm('Are you sure you want to delete this notification?')) {
            $.ajax({
                url: 'delete_notification.php',
                type: 'POST',
                data: {
                    notification_id: notificationId
                },
                success: function(response) {
                    $('#notification-' + notificationId).remove();
                    if ($('.notification-item').length === 0) {
                        $('#notificationPanel').html('<h5>Notifications</h5><p>No new notifications</p>');
                    }
                },
                error: function() {
                    alert('Error deleting notification. Please try again.');
                }
            });
        }
    }

    // Close notifications when clicking outside
    window.onclick = function(event) {
        if (!event.target.matches('.notification-icon') && !event.target.closest('.notification-panel')) {
            var panel = document.getElementById('notificationPanel');
            if (panel.style.display === 'block') {
                panel.style.display = 'none';
            }
        }
    }
    </script>
</body>
</html>