<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 10;
$offset = ($page - 1) * $records_per_page;

// Get filter parameters
$involvement_filter = isset($_GET['involvement']) ? $_GET['involvement'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$sort_order = isset($_GET['sort']) ? $_GET['sort'] : 'DESC';

// Build WHERE clause for both queries
$where_clause = "WHERE (sv.student_id IS NOT NULL OR iw.witness_id IS NOT NULL)";
if ($involvement_filter) {
    if ($involvement_filter === 'Involved') {
        $where_clause .= " AND sv.student_id IS NOT NULL";
    } elseif ($involvement_filter === 'Witness') {
        $where_clause .= " AND iw.witness_id IS NOT NULL";
    }
}
if ($status_filter) {
    $where_clause .= " AND ir.status = ?";
}

// Count query
$count_query = "
    SELECT COUNT(DISTINCT ir.id) as total_records 
    FROM incident_reports ir
    LEFT JOIN student_violations sv ON ir.id = sv.incident_report_id AND sv.student_id = ?
    LEFT JOIN incident_witnesses iw ON ir.id = iw.incident_report_id AND iw.witness_id = ?
    $where_clause
";

$count_stmt = $connection->prepare($count_query);
if ($count_stmt === false) {
    die("Prepare failed: " . $connection->error);
}

if ($status_filter) {
    $count_stmt->bind_param("sss", $student_id, $student_id, $status_filter);
} else {
    $count_stmt->bind_param("ss", $student_id, $student_id);
}

$count_stmt->execute();
$count_result = $count_stmt->get_result();
$row = $count_result->fetch_assoc();
$total_records = $row['total_records'];
$total_pages = ceil($total_records / $records_per_page);

// Main query
$query = "
    SELECT DISTINCT ir.*, 
           CASE 
               WHEN sv.student_id IS NOT NULL THEN 'Involved'
               WHEN iw.witness_id IS NOT NULL THEN 'Witness'
           END as involvement_type
    FROM incident_reports ir
    LEFT JOIN student_violations sv ON ir.id = sv.incident_report_id AND sv.student_id = ?
    LEFT JOIN incident_witnesses iw ON ir.id = iw.incident_report_id AND iw.witness_id = ?
    $where_clause
    ORDER BY ir.date_reported " . ($sort_order === 'ASC' ? 'ASC' : 'DESC') . "
    LIMIT ? OFFSET ?
";

$stmt = $connection->prepare($query);
if ($stmt === false) {
    die("Prepare failed: " . $connection->error);
}

if ($status_filter) {
    $stmt->bind_param("sssii", $student_id, $student_id, $status_filter, $records_per_page, $offset);
} else {
    $stmt->bind_param("ssii", $student_id, $student_id, $records_per_page, $offset);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Incident Reports</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <style>
        body {
            background: linear-gradient(135deg, #0d693e, #004d4d);
            min-height: 100vh;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            margin: 0;
            color: #333;
        }
        .container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            margin-top: 50px;
            margin-bottom: 50px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #0d693e;
            border-bottom: 2px solid #0d693e;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        dt {
            font-weight: bold;
            color: #0d693e;
        }
        dd {
            margin-bottom: 15px;
        }
        .btn-primary {
            background-color: #0d693e;
            border-color: #0d693e;
        }
        .btn-primary:hover {
            background-color: #094e2e;
            border-color: #094e2e;
        }
        .btn-secondary {
            background-color: #F4A261;
            border-color: #F4A261;
            color: #fff;
            padding: 10px 20px;
        }
        .btn-secondary:hover {
            background-color: #E76F51;
            border-color: #E76F51;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <a href="student_homepage.php" class="btn btn-secondary mb-4">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        <h2>My Incident Reports</h2>

        <!-- Filter Form -->
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-3">
                    <select name="involvement" class="form-control">
                        <option value="">All Involvements</option>
                        <option value="Involved" <?php echo $involvement_filter === 'Involved' ? 'selected' : ''; ?>>Involved</option>
                        <option value="Witness" <?php echo $involvement_filter === 'Witness' ? 'selected' : ''; ?>>Witness</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-control">
                        <option value="">All Statuses</option>
                        <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="for meeting" <?php echo $status_filter === 'for meeting' ? 'selected' : ''; ?>>For Meeting</option>
                        <option value="settled" <?php echo $status_filter === 'settled' ? 'selected' : ''; ?>>Settled</option>
                        <option value="for meeting-counselor" <?php echo $status_filter === 'for meeting-counselor' ? 'selected' : ''; ?>>For Meeting-Counselor</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="sort" class="form-control">
                        <option value="DESC" <?php echo $sort_order === 'DESC' ? 'selected' : ''; ?>>Newest First</option>
                        <option value="ASC" <?php echo $sort_order === 'ASC' ? 'selected' : ''; ?>>Oldest First</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary">Apply Filters</button>
                </div>
            </div>
        </form>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Date Reported</th>
                    <th>Incident Date/Time</th>
                    <th>Description</th>
                    <th>My Involvement</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows == 0): ?>
                <tr>
                    <td colspan="6" class="text-center">
                        <div class="alert alert-info" role="alert">
                            No incident reports found.
                        </div>
                    </td>
                </tr>
                <?php else: ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['date_reported']); ?></td>
                        <td><?php echo htmlspecialchars($row['place']); ?></td>
                        <td><?php echo htmlspecialchars(substr($row['description'], 0, 50)) . '...'; ?></td>
                        <td><?php echo htmlspecialchars($row['involvement_type']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                        <td>
                            <a href="view_student_incident_details.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">View Details</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=1&involvement=<?php echo $involvement_filter; ?>&status=<?php echo $status_filter; ?>&sort=<?php echo $sort_order; ?>">First</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo ($page - 1); ?>&involvement=<?php echo $involvement_filter; ?>&status=<?php echo $status_filter; ?>&sort=<?php echo $sort_order; ?>">Previous</a>
                    </li>
                <?php endif; ?>

                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                    <li class="page-item <?php echo ($i === $page) ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&involvement=<?php echo $involvement_filter; ?>&status=<?php echo $status_filter; ?>&sort=<?php echo $sort_order; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo ($page + 1); ?>&involvement=<?php echo $involvement_filter; ?>&status=<?php echo $status_filter; ?>&sort=<?php echo $sort_order; ?>">Next</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $total_pages; ?>&involvement=<?php echo $involvement_filter; ?>&status=<?php echo $status_filter; ?>&sort=<?php echo $sort_order; ?>">Last</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</body>
</html>