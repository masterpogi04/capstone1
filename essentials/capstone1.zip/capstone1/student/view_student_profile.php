<?php
session_start();
include '../db.php';

// Ensure the user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];

$stmt = $connection->prepare("
    SELECT sp.*, s.department_id, s.course_id, d.name as department_name, c.name as course_name
    FROM student_profiles sp
    JOIN tbl_student ts ON sp.student_id = ts.student_id
    JOIN sections s ON ts.section_id = s.id
    JOIN departments d ON s.department_id = d.id
    JOIN courses c ON s.course_id = c.id
    WHERE sp.student_id = ?
");

if ($stmt === false) {
    die("Prepare failed: " . $connection->error);
}

$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$profile = $result->fetch_assoc();

// Close the database connection
$stmt->close();
$connection->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student Profile</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #FAF3E0;
            font-family: Arial, sans-serif;
        }
        .container {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1, h2 {
            color: #1A6E47;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            font-weight: bold;
        }
        .readonly-input {
            background-color: #e9ecef;
            cursor: not-allowed;
        }
        .signature-container {
            margin-top: 20px;
            text-align: center;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
        }
        .signature-image {
            max-width: 300px;
            max-height: 100px;
            margin-bottom: 10px;
        }
        .student-name {
            font-weight: bold;
            margin-top: 10px;
            border-top: 1px solid #ccc;
            padding-top: 10px;
        }
        .guidance-note {
            background-color: #f8f9fa;
            border-left: 5px solid #1A6E47;
            padding: 15px;
            margin-bottom: 20px;
        }
        .btn-back {
            background-color: #F4A261;
            border: none;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn-back:hover {
            background-color: #e76f51;
        }
        .header {
            background-color: #1A6E47;
            color: white;
            padding: 20px 0;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <h1 class="text-center">Student Profile Form for Inventory</h1>
        </div>
    </div>
    <div class="container">
        <div class="guidance-note">
            <h4>Need to make changes?</h4>
            <p>If you wish to update any information on this form, please visit the Guidance Office. Our staff will be happy to assist you with any necessary changes.</p>
        </div>

        <form>
            <h2>Personal Information</h2>
            <div class="form-group">
                <label for="full_name">Full Name:</label>
                <input type="text" class="form-control readonly-input" id="full_name" value="<?php echo htmlspecialchars($profile['last_name'] . ', ' . $profile['first_name'] . ' ' . $profile['middle_name']); ?>" readonly>
            </div>
            <?php
            $personal_info = ['student_id', 'gender', 'birthdate', 'age', 'civil_status', 'province', 'city', 'contact_number', 'email'];
            foreach ($personal_info as $key):
                if (isset($profile[$key])):
            ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo ucfirst(str_replace('_', ' ', $key)); ?>:</label>
                    <input type="text" class="form-control readonly-input" id="<?php echo $key; ?>" value="<?php echo htmlspecialchars($profile[$key]); ?>" readonly>
                </div>
            <?php 
                endif;
            endforeach;
            ?>

            <h2>Address Information</h2>
            <?php
            $address_info = ['permanent_address', 'current_address'];
            foreach ($address_info as $key):
                if (isset($profile[$key])):
            ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo ucfirst(str_replace('_', ' ', $key)); ?>:</label>
                    <input type="text" class="form-control readonly-input" id="<?php echo $key; ?>" value="<?php echo htmlspecialchars($profile[$key]); ?>" readonly>
                </div>
            <?php 
                endif;
            endforeach;
            ?>

            <h2>Educational Information</h2>
            <?php
            $educational_info = ['course_id', 'department_name', 'course_name', 'year_level', 'semester_first_enrolled'];
            foreach ($educational_info as $key):
                if (isset($profile[$key])):
            ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo ucfirst(str_replace('_', ' ', $key)); ?>:</label>
                    <input type="text" class="form-control readonly-input" id="<?php echo $key; ?>" value="<?php echo htmlspecialchars($profile[$key]); ?>" readonly>
                </div>
            <?php 
                endif;
            endforeach;
            ?>

            <h2>Family Background</h2>
            <?php
            $family_info = ['father_name', 'father_contact', 'father_occupation','mother_name', 'mother_contact', 'mother_occupation', 'guardian_name', 'guardian_relationship', 'guardian_contact', 'guardian_occupation', 'siblings', 'birth_order', 'family_income'];
            foreach ($family_info as $key):
                if (isset($profile[$key])):
            ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo ucfirst(str_replace('_', ' ', $key)); ?>:</label>
                    <input type="text" class="form-control readonly-input" id="<?php echo $key; ?>" value="<?php echo htmlspecialchars($profile[$key]); ?>" readonly>
                </div>
            <?php 
                endif;
            endforeach;
            ?>

            <h2>Educational Background</h2>
            <?php
            $educational_background = ['elementary', 'secondary', 'transferees'];
            foreach ($educational_background as $key):
                if (isset($profile[$key])):
            ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo ucfirst(str_replace('_', ' ', $key)); ?>:</label>
                    <input type="text" class="form-control readonly-input" id="<?php echo $key; ?>" value="<?php echo htmlspecialchars($profile[$key]); ?>" readonly>
                </div>
            <?php 
                endif;
            endforeach;
            ?>

            <h2>Career Information</h2>
            <?php
            $career_info = ['course_factors', 'career_concerns'];
            foreach ($career_info as $key):
                if (isset($profile[$key])):
            ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo ucfirst(str_replace('_', ' ', $key)); ?>:</label>
                    <textarea class="form-control readonly-input" id="<?php echo $key; ?>" rows="3" readonly><?php echo htmlspecialchars($profile[$key]); ?></textarea>
                </div>
            <?php 
                endif;
            endforeach;
            ?>

            <h2>Medical History</h2>
            <?php
            $medical_info = ['medications', 'medical_conditions', 'suicide_attempt', 'suicide_reason', 'problems', 'fitness_activity', 'fitness_frequency', 'stress_level'];
            foreach ($medical_info as $key):
                if (isset($profile[$key])):
            ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo ucfirst(str_replace('_', ' ', $key)); ?>:</label>
                    <?php if (in_array($key, ['suicide_reason', 'problems', 'medical_conditions'])): ?>
                        <textarea class="form-control readonly-input" id="<?php echo $key; ?>" rows="3" readonly><?php echo htmlspecialchars($profile[$key]); ?></textarea>
                    <?php else: ?>
                        <input type="text" class="form-control readonly-input" id="<?php echo $key; ?>" value="<?php echo htmlspecialchars($profile[$key]); ?>" readonly>
                    <?php endif; ?>
                </div>
            <?php 
                endif;
            endforeach;
            ?>

            <!-- Signature Section -->
            <div class="signature-container">
                <h3>Student Signature</h3>
                <p>I hereby attest that all information stated above is true and correct.</p>
                <?php if (!empty($profile['signature_path'])): ?>
                    <img src="<?php echo htmlspecialchars($profile['signature_path']); ?>" alt="Student Signature" class="signature-image">
                <?php else: ?>
                    <p>No signature available</p>
                <?php endif; ?>
                <p class="student-name">
                    <?php echo htmlspecialchars($profile['last_name'] . ', ' . $profile['first_name'] . ' ' . $profile['middle_name']); ?>
                </p>
            </div>

            <div class="text-center mt-4">
                <a href="student_homepage.php" class="btn btn-back">Back to Homepage</a>
            </div>
        </form>
    </div>
</body>
</html>