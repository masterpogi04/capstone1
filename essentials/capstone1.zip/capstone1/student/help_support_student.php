<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$stmt = $connection->prepare("SELECT first_name, last_name, profile_picture FROM tbl_student WHERE student_id = ?");
if ($stmt === false) {
    die("Prepare failed: " . $connection->error);
}
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $student = $result->fetch_assoc();
    $name = $student['first_name'] . ' ' . $student['last_name'];
    $profile_picture = $student['profile_picture'];
} else {
    die("Student not found.");
}

$connection->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CEIT - Guidance Office Help & Support</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <style>
    body {
      background-color: #FAF3E0;
      font-family: Arial, sans-serif;
      display: flex;
      min-height: 100vh;
    }
    .sidebar {
      background-color: #1A6E47;
      color: white;
      padding-top: 20px;
      width: 250px;
      position: fixed;
      height: 100%;
      overflow-y: auto;
    }
    .sidebar a {
      color: white;
      display: block;
      padding: 15px;
      text-decoration: none;
      transition: background-color 0.3s;
    }
    .sidebar a:hover, .sidebar a.active {
      background-color: #F2A54B;
    }
    .main-content {
      flex: 1;
      margin-left: 250px;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    .header {
      background-color: #F4A261;
      padding: 15px;
      color: black;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .footer {
      background-color: #F4A261;
      padding: 10px;
      color: black;
      text-align: center;
      margin-top: auto;
    }
    .profile-section {
      text-align: center;
      padding: 20px 15px;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .profile-section img {
      width: 100px;
      height: 100px;
      border: 3px solid white;
      border-radius: 50%;
      margin-bottom: 10px;
    }
    .profile-section p {
      margin-bottom: 0;
      font-weight: bold;
    }
    .notification-icon {
      font-size: 24px;
      color: #1A6E47;
      cursor: pointer;
      transition: color 0.3s;
    }
    .notification-icon:hover {
      color: #F2A54B;
    }
    .content-area {
      padding: 20px;
      background-color: white;
      margin: 20px;
      border-radius: 5px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .faq-section h3 {
      color: #1A6E47;
      margin-bottom: 20px;
    }
    .faq-section h5 {
      color: #1A6E47;
      margin-top: 15px;
    }
  </style>
</head>
<body>
  <nav class="sidebar">
    <div class="profile-section">
      <img src="<?php echo htmlspecialchars($profile_picture); ?>" alt="Profile Picture">
      <p><?php echo htmlspecialchars($name); ?></p>
    </div>
    <a href="student_homepage.php">Home</a>
    <a href="view_courses.php">View Courses</a>
    <a href="student_my_profile.php">My Profile</a>
    <a href="help_support_student.php" class="active">Help & Support</a>
    <a href="../login.php" onclick="return confirm('Are you sure you want to log out?')">Log Out</a>
  </nav>
  <div class="main-content">
    <header class="header">
      <h1>CEIT - GUIDANCE OFFICE</h1>
      <i class="fa fa-bell notification-icon"></i>
    </header>
    <main class="content-area">
      <h2>Help & Support for Students</h2>
      <div class="faq-section">
        <h3>Frequently Asked Questions (FAQs)</h3>
        <h5>1. How do I request a document from the Guidance Office?</h5>
        <p>To request a document, go to the "Request Document" section in your student dashboard. Fill out the required information and submit your request. You'll be notified when your document is ready for pickup.</p>
        
        <h5>2. How can I schedule an appointment with a guidance counselor?</h5>
        <p>You can schedule an appointment by visiting the "Counseling Services" section in your dashboard. Choose an available time slot that works for you and confirm your appointment.</p>
        
        <h5>3. What should I do if I'm experiencing academic difficulties?</h5>
        <p>If you're struggling academically, reach out to your academic advisor or visit the "Academic Support" section in your dashboard. You can find resources, tutoring services, and study groups to help improve your performance.</p>
        
        <h5>4. How do I update my personal information?</h5>
        <p>To update your personal information, go to "My Profile" in the sidebar. Make the necessary changes and save your updates. If you need to change critical information like your student ID, please contact the Registrar's Office.</p>
        
        <h5>5. Where can I find information about career services and job opportunities?</h5>
        <p>Check the "Career Services" section in your dashboard for information about job fairs, internships, and career counseling services. You can also find resources for resume writing and interview preparation.</p>
      </div>

      <div class="contact-section">
        <h3>Need More Help?</h3>
        <p>If you need further assistance, you can contact the CEIT Guidance Office:</p>
        <ul>
          <li>Email: guidance@cvsu-ceit.edu.ph</li>
          <li>Phone: (123) 456-7890</li>
          <li>Office Hours: Monday to Friday, 8:00 AM to 5:00 PM</li>
        </ul>
      </div>
    </main>
    <footer class="footer">
      <p>&copy; 2024 CEIT Guidance Office - All Rights Reserved</p>
    </footer>
  </div>
</body>
</html>