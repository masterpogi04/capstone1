<?php
session_start();
include '../db.php';

// Ensure the user is logged in as a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 10;
$offset = ($page - 1) * $records_per_page;

// Count total records for pagination
$count_query = "
    SELECT COUNT(*) as total 
    FROM incident_reports 
    WHERE reporters_id = ? AND reported_by_type = ?
";
$count_stmt = $connection->prepare($count_query);
$count_stmt->bind_param("is", $user_id, $user_type);
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_records = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_records / $records_per_page);

// Fetch incident reports submitted by this student
$query = "
    SELECT ir.*, 
           GROUP_CONCAT(DISTINCT sv.student_id) as involved_students,
           GROUP_CONCAT(DISTINCT iw.witness_name) as witnesses
    FROM incident_reports ir
    LEFT JOIN student_violations sv ON ir.id = sv.incident_report_id
    LEFT JOIN incident_witnesses iw ON ir.id = iw.incident_report_id
    WHERE ir.reporters_id = ? AND ir.reported_by_type = ?
    GROUP BY ir.id
    ORDER BY ir.date_reported DESC
    LIMIT ? OFFSET ?
";

$stmt = $connection->prepare($query);

if ($stmt === false) {
    die("Prepare failed: " . $connection->error);
}

$stmt->bind_param("isii", $user_id, $user_type, $records_per_page, $offset);

if (!$stmt->execute()) {
    die("Execute failed: " . $stmt->error);
}

$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Incident Reports</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <style>
    body {
        background: linear-gradient(135deg, #0d693e, #004d4d);
        min-height: 100vh;
        font-family: Arial, sans-serif;
        display: flex;
        flex-direction: column;
        margin: 0;
        color: #333;
    }
    .container {
        background-color: #ffffff;
        border-radius: 15px;
        padding: 30px;
        margin-top: 50px;
        margin-bottom: 50px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }
    h2 {
        color: #0d693e;
        border-bottom: 2px solid #0d693e;
        padding-bottom: 10px;
        margin-bottom: 20px;
    }
    dt {
        font-weight: bold;
        color: #0d693e;
    }
    dd {
        margin-bottom: 15px;
    }
    .btn-primary {
        background-color: #0d693e;
        border-color: #0d693e;
    }
    .btn-primary:hover {
        background-color: #094e2e;
        border-color: #094e2e;
    }
    .btn-secondary {
        background-color: #F4A261;
        border-color: #F4A261;
        color: #fff;
        padding: 10px 20px;
    }
    .btn-secondary:hover {
        background-color: #E76F51;
        border-color: #E76F51;
    }
    .pagination {
        justify-content: center;
        margin-top: 20px;
    }
    .page-item.active .page-link {
        background-color: #0d693e;
        border-color: #0d693e;
    }
    .page-link {
        color: #0d693e;
    }
    .page-link:hover {
        color: #094e2e;
    }
</style>
</head>
<body>
    <div class="container mt-5">
        <a href="student_homepage.php" class="btn btn-secondary mb-4">
            <i class="fas fa-arrow-left"></i> Back to Homepage
        </a>
        <h2>My Submitted Incident Reports</h2>
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Date Reported</th>
                    <th>Place, Date & Time of Incident</th>
                    <th>Description</th>
                    <th>Students Involved</th>
                    <th>Witnesses</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['date_reported']); ?></td>
                    <td><?php echo htmlspecialchars($row['place']); ?></td>
                    <td><?php echo htmlspecialchars(substr($row['description'], 0, 50)) . '...'; ?></td>
                    <td><?php echo htmlspecialchars($row['involved_students']); ?></td>
                    <td><?php echo htmlspecialchars($row['witnesses']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td>
                        <a href="view_incident_details-student.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">View Details</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <nav aria-label="Page navigation">
            <ul class="pagination">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=1" aria-label="First">
                            <span aria-hidden="true">&laquo;&laquo;</span>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php
                $start_page = max(1, $page - 2);
                $end_page = min($total_pages, $page + 2);

                for ($i = $start_page; $i <= $end_page; $i++):
                ?>
                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $total_pages; ?>" aria-label="Last">
                            <span aria-hidden="true">&raquo;&raquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</body>
</html>