<?php
session_start();
include '../db.php'; // Ensure database connection is established
// Ensure the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}
// Get the admin's ID from the session
$admin_id = $_SESSION['user_id'];
// Fetch the admin's details from the database
$stmt = $connection->prepare("SELECT name, profile_picture FROM tbl_admin WHERE id = ?");
if ($stmt === false) {
    die("Prepare failed: " . $connection->error); // Output the error message
}
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $admin = $result->fetch_assoc();
    $name = $admin['name'];
    $profile_picture = $admin['profile_picture'];
} else {
    die("Admin not found.");
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help & Support Dashboard</title>
    <link rel="stylesheet" type="text/css" href="admin_styles.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="header">
        CAVITE STATE UNIVERSITY-MAIN
    </div>
    <?php include 'admin_sidebar.php'; ?> 
    
    <div class="main-content">
        
            <br><br><br>
            <div class="container">
        <div class="dashboard-container">
            <h2>CEIT | Help & Support</h2>
           
            <h3>Frequently Asked Questions (FAQs)</h3>
            <div class="faq-section">
                <div class="faq-item">
                    <p class="faq-question">1. How do I reset my password?</p>
                    <p>To reset your password, please follow these steps:</p>
                    <ol>
                        <li>Navigate to the login page</li>
                        <li>Click on the "Forgot Password" link</li>
                        <li>Enter your registered email address</li>
                        <li>Follow the instructions sent to your email to complete the password reset process</li>
                    </ol>
                </div>
                
                <div class="faq-item">
                    <p class="faq-question">2. How do I update my profile information?</p>
                    <p>To update your profile information:</p>
                    <ol>
                        <li>Log into your account</li>
                        <li>Click on your profile icon at the top right corner</li>
                        <li>Select "Account Settings" from the dropdown menu</li>
                        <li>Make the necessary changes to your profile</li>
                        <li>Click "Save" to confirm your updates</li>
                    </ol>
                </div>
                
                <div class="faq-item">
                    <p class="faq-question">3. How do I contact support?</p>
                    <p>Our support team is available to assist you through the following channels:</p>
                    <ul>
                        <li>Email: support@cvsu.edu.ph</li>
                        <li>Phone: (123) 456-7890</li>
                        <li>Office Hours: Monday to Friday, 8:00 AM to 5:00 PM</li>
                    </ul>
                </div>
            </div>

        </div>
    </div>

    <div class="footer">
        <p>Contact number | Email | Copyright</p>
    </div>

    
</body>
</html>
