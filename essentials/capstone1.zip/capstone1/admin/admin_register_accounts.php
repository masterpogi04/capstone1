<?php
session_start();
include '../db.php';

// Ensure the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password
    $email = $_POST['email'];
    $name = $_POST['name'];
    $user_type = $_POST['user_type'];
    
    $table_name = "tbl_" . strtolower($user_type);
    
    // Check if the username or email already exists
    $check_stmt = $connection->prepare("SELECT * FROM $table_name WHERE username = ? OR email = ?");
    $check_stmt->bind_param("ss", $username, $email);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $message = "Error: Username or email already exists.";
    } else {
        $stmt = $connection->prepare("INSERT INTO $table_name (username, password, email, name, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())");
        $stmt->bind_param("ssss", $username, $password, $email, $name);
        
        if ($stmt->execute()) {
            $message = "New $user_type account created successfully";
            
           
            $_SESSION['new_account'] = [
                'user_type' => $user_type,
                'username' => $username,
                'email' => $email,
                'password' => $_POST['password'], 
                'name' => $name
            ];
            
           
            header("Location: admin_send_credentials_email.php");
            exit();
        } else {
            $message = "Error: " . $stmt->error;
        }
        
        $stmt->close();
    }
    
    $check_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register New Accounts</title>
    <link rel="stylesheet" type="text/css" href="admin_styles.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
        <style>

        .form-container {
            width: 100%;
            max-width: 600px; 
            margin: 2rem auto;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .form-container h2 {
            color: #003366;
            margin-bottom: 1.5rem; 
            text-align: center;
            font-size: 1.8rem; 
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .form-group {
            margin-bottom: 1.2rem;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.4rem; 
            font-weight: bold;
            color: #003366;
            transition: color 0.3s ease;
            font-size: 0.9rem; 
        }

        .form-control {
            width: 100%;
            padding: 0.6rem; 
            border: 2px solid #ccc;
            border-radius: 6px; 
            font-size: 0.9rem; 
            transition: all 0.3s ease;
            background-color: #f9f9f9;
        }
        select.form-control {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%23003366' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 12px;
            padding-right: 2.5rem;
        }
        .btn-primary {
            background-color: #4a90e2;
            color: white;
            padding: 0.9rem 2rem;
            border: none;
            border-radius: 25px; 
            cursor: pointer;
            font-size: 1.1rem; 
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1.5px; 
            position: relative;
            overflow: hidden;
            font-weight: 600; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.1); 
            width: auto; 
            min-width: 500px;
        }

        .btn-primary:hover {
            background-color: #3a7bc8;
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }

        .btn-primary:active {
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .btn-primary::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 5px;
            height: 5px;
            background: rgba(255,255,255,0.7);
            opacity: 0;
            border-radius: 100%;
            transform: scale(1, 1) translate(-50%);
            transform-origin: 50% 50%;
        }

        .btn-primary:focus:not(:active)::after {
            animation: ripple 1s ease-out;
        }

        @keyframes ripple {
            0% { transform: scale(0, 0); opacity: 1; }
            20% { transform: scale(25, 25); opacity: 1; }
            100% { opacity: 0; transform: scale(40, 40); }
        }

        /* Form Validation Styling */
        .form-control.is-invalid {
            border-color: #dc3545;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%23dc3545' viewBox='0 0 16 16'%3E%3Cpath d='M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8 4a.905.905 0 0 0-.9.995l.35 3.507a.552.552 0 0 0 1.1 0l.35-3.507A.905.905 0 0 0 8 4zm.002 6a1 1 0 1 0 0 2 1 1 0 0 0 0-2z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 12px;
            padding-right: 2.5rem;
        }

        .form-control.is-invalid:focus {
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
        }

        .invalid-feedback {
            display: none;
            width: 100%;
            margin-top: 0.25rem;
            font-size: 80%;
            color: #dc3545;
        }

        .form-control.is-invalid ~ .invalid-feedback {
            display: block;
        }

        /* Responsive Adjustments */
        @media (max-width: 992px) {
            .form-container {
                max-width: 90%;
                padding: 1.8rem;
            }
        }

        @media (max-width: 768px) {
            .form-container {
                max-width: 95%;
                padding: 1.5rem;
                margin: 1rem auto;
            }

            .form-container h2 {
                font-size: 1.5rem;
                margin-bottom: 1.2rem;
            }

            .btn-primary {
                padding: 0.8rem 1.8rem;
                font-size: 1rem;
                min-width: 180px;
            }

            .dashboard-container {
                margin: 1rem;
                padding: 1rem;
            }
            
            .form-control,
            .btn-primary {
                font-size: 16px; 
            }
        }

        @media (max-width: 480px) {
            .form-container {
                padding: 1rem;
            }

            .form-container h2 {
                font-size: 1.3rem;
                margin-bottom: 1rem;
            }

            .btn-primary {
                font-size: 0.9rem;
                padding: 0.7rem 1.5rem;
                min-width: 160px;
            }
        }
        </style>
<body>
    <div class="header">
        CAVITE STATE UNIVERSITY-MAIN
    </div>
    <?php include 'admin_sidebar.php'; ?>
    <div class="main-content">
        <br><br><br>
        <div class="form-container">
            <h2>Register New Accounts</h2>
            <form method="post" id="registrationForm">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="user_type">User Type:</label>
                    <select class="form-control" id="user_type" name="user_type" required>
                        <!-- <option value="admin">Admin</option> if we want to add a new admin-->
                        <option value="counselor">Counselor</option>
                        <option value="facilitator">Facilitator</option>
                        <option value="instructor">Instructor</option>
                        <option value="adviser">Adviser</option>
                        <option value="guard">UCSS Guard</option>
                    </select>
                </div>
                <center><button type="submit" class="btn btn-primary">Register Account</button></center>
            </form>
        </div>
    </div>
    <div class="footer">
        <p>Contact number | Email | Copyright</p>
    </div>

    <script>
    document.getElementById('registrationForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        Swal.fire({
            title: 'Confirm Registration',
            text: "Are you sure you want to register this account?",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, register it!'
        }).then((result) => {
            if (result.isConfirmed) {
                this.submit();
            }
        });
    });

    <?php if($message): ?>
    Swal.fire({
        title: 'Registration Status',
        text: "<?php echo $message; ?>",
        icon: '<?php echo strpos($message, "successfully") !== false ? "success" : "error"; ?>',
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'OK'
    });
    <?php endif; ?>
    </script>
</body>
</html>