<?php
// Ensure the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Define UPLOADS_URL if not already defined
if (!defined('UPLOADS_URL')) {
    define('UPLOADS_URL', '/capstone1/uploads/admin_profiles/'); //mababago based sa file path
}

// Get the profile picture path from the session
$profile_picture = isset($_SESSION['profile_picture']) ? $_SESSION['profile_picture'] : '';
$name = isset($_SESSION['name']) ? $_SESSION['name'] : '';

// If the profile picture is not set or doesn't exist, use a default image
$profile_picture_url = !empty($profile_picture) && file_exists($_SERVER['DOCUMENT_ROOT'] . UPLOADS_URL . basename($profile_picture))
    ? UPLOADS_URL . basename($profile_picture)
    : '/path/to/default/profile/image.jpg';
?>

<div class="sidebar" id="sidebar">
    <button id="sidebarToggle" class="sidebar-toggle">☰</button>
    <div class="sidebar-content">
        <div class="profile-section text-center">
            <img src="<?php echo htmlspecialchars($profile_picture_url); ?>" class="rounded-circle" alt="Profile Picture">
            <p><?php echo htmlspecialchars($name); ?></p>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="admin_manage_accounts.php">Manage Users</a></li>
            <li class="nav-item"><a class="nav-link" href="admin_register_accounts.php">Register New Accounts</a></li>
            <li class="nav-item"><a class="nav-link" href="admin_add_departments.php">Manage Departments</a></li>
            <li class="nav-item"><a class="nav-link" href="view_reports.php">View Reports</a></li>
            <li class="nav-item"><a class="nav-link" href="admin_profile.php">My Profile</a></li>
            <li class="nav-item"><a class="nav-link" href="help_support.php">Help & Support</a></li>
            <li class="nav-item"><a class="nav-link" href="../login.php" onclick="return confirmLogout()">Log Out</a></li>
        </ul>
    </div>
</div>

<style>
    .sidebar {
        background-color: #1A6E47;
        min-height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 100;
        transition: all 0.3s ease-in-out;
        width: 250px;
        overflow-y: auto;
    }

    .sidebar-content {
        padding: 15px;
    }

    .sidebar-toggle {
        display: none;
        background: none;
        border: none;
        color: white;
        font-size: 24px;
        cursor: pointer;
        position: absolute;
        top: 10px;
        right: 10px;
    }

    .profile-section {
        margin-bottom: 20px;
    }

    .profile-section img {
        width: 100px;
        height: 100px;
        object-fit: cover;
        margin-bottom: 10px;
    }

    .profile-section p {
        color: white;
        margin: 0;
    }

    .nav-link {
        color: rgba(255, 255, 255, 0.8);
        padding: 10px 15px;
        border-radius: 5px;
        transition: all 0.2s ease-in-out;
        display: block;
    }

    .nav-link:hover, .nav-link.active {
        color: #fff;
        background: rgba(255, 255, 255, 0.15);
        transform: translateX(5px);
    }

    @media (max-width: 768px) {
        .sidebar {
            width: 60px;
        }

        .sidebar.expanded {
            width: 250px;
        }

        .sidebar-toggle {
            display: block;
        }

        .sidebar:not(.expanded) .sidebar-content {
            display: none;
        }

        .sidebar.expanded .sidebar-content {
            display: block;
        }
    }
</style>

<script>
function confirmLogout() {
    return confirm('Are you sure you want to log out?');
}

document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');

    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('expanded');
    });
});
</script>