<?php
session_start();
include '../db.php';

// Define the external uploads path
define('UPLOADS_PATH', 'C:/xampp/htdocs/capstone1/uploads/admin_profiles/');
define('UPLOADS_URL', '/capstone1/uploads/admin_profiles/');

// Ensure the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];

// Fetch current admin details
$stmt = $connection->prepare("SELECT username, email, name, profile_picture FROM tbl_admin WHERE id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $admin = $result->fetch_assoc();
    $username = $admin['username'];
    $email = $admin['email'];
    $name = $admin['name'];
    $profile_picture = $admin['profile_picture'];
    $_SESSION['name'] = $name;
    $_SESSION['profile_picture'] = $profile_picture;
} else {
    die("Admin not found.");
}
$stmt->close();

$update_successful = false;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_name = trim($_POST['name']);
    $new_password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    // Update name
    if (!empty($new_name) && $new_name !== $name) {
        $update_stmt = $connection->prepare("UPDATE tbl_admin SET name = ?, updated_at = NOW() WHERE id = ?");
        $update_stmt->bind_param("si", $new_name, $admin_id);
        if ($update_stmt->execute()) {
            $name = $new_name;
            $_SESSION['name'] = $name;
            $update_successful = true;
        }
        $update_stmt->close();
    }
    
    // Update password
        if (!empty($new_password)) {
            if ($new_password === $confirm_password) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_stmt = $connection->prepare("UPDATE tbl_admin SET password = ?, updated_at = NOW() WHERE id = ?");
                $update_stmt->bind_param("si", $hashed_password, $admin_id);
                if ($update_stmt->execute()) {
                    $update_successful = true;
                }
                $update_stmt->close();
            } else {
                $error_message[] = "Passwords do not match.";
            }
        }
    
    // Handle file upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");
        $filename = $_FILES["profile_picture"]["name"];
        $filetype = $_FILES["profile_picture"]["type"];
        $filesize = $_FILES["profile_picture"]["size"];
    
        // Verify file extension
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        if (!array_key_exists($ext, $allowed)) {
            $error_message[] = "Error: Please select a valid file format.";
        }
    
        // Verify file size - 5MB maximum
        $maxsize = 5 * 1024 * 1024;
        if ($filesize > $maxsize) {
            $error_message[] = "Error: File size is larger than the allowed limit.";
        }
    
        // Verify MIME type of the file
        if (in_array($filetype, $allowed)) {
            // Generate a unique filename
            $new_filename = uniqid() . "." . $ext;
            $upload_path = UPLOADS_PATH . $new_filename;
            
            if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $upload_path)) {
                $db_path = 'admin_profiles/' . $new_filename; // Store relative path in database
                $update_stmt = $connection->prepare("UPDATE tbl_admin SET profile_picture = ?, updated_at = NOW() WHERE id = ?");
                $update_stmt->bind_param("si", $db_path, $admin_id);
                if ($update_stmt->execute()) {
                    // Delete old profile picture if it exists
                    if (!empty($profile_picture) && file_exists(UPLOADS_PATH . basename($profile_picture))) {
                        unlink(UPLOADS_PATH . basename($profile_picture));
                    }
                    $profile_picture = $db_path;
                    $_SESSION['profile_picture'] = $db_path;
                    $update_successful = true;
                }
                $update_stmt->close();
            } else {
                $error_message[] = "Error uploading file. Please try again.";
            }
        } else {
            $error_message[] = "Error: Invalid file type. Please try again.";
        }
    }
}

if ($update_successful) {
    // Refresh admin details
    $stmt = $connection->prepare("SELECT username, email, name, profile_picture FROM tbl_admin WHERE id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();
        $name = $admin['name'];
        $profile_picture = $admin['profile_picture'];
        $_SESSION['name'] = $name;
        $_SESSION['profile_picture'] = $profile_picture;
    }
    $stmt->close();
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <link rel="stylesheet" type="text/css" href="admin_styles.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="header">
        CAVITE STATE UNIVERSITY-MAIN
    </div>
    <?php include 'admin_sidebar.php'; ?>
    <div class="main-content">
        <div class="container mt-4">
            <br><br>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Update Profile</h1>
                </div>
                
                 <div class="card">
                    <div class="card-body">
                        <form id="updateProfileForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="username" class="form-label">Username:</label>
                                    <input type="text" class="form-control" id="username" value="<?php echo htmlspecialchars($username); ?>" readonly>
                                </div>
                                <div class="col-md-6">
                                    <label for="email" class="form-label">Email:</label>
                                    <input type="email" class="form-control" id="email" value="<?php echo htmlspecialchars($email); ?>" readonly>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Name:</label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>">
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="password" class="form-label">New Password:</label>
                                    <div class="input-group">
                                        <input type="password" class="form-control" id="password" name="password">
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                                <i class="fa fa-eye"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label for="confirm_password" class="form-label">Confirm New Password:</label>
                                    <div class="input-group">
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="button" id="toggleConfirmPassword">
                                                <i class="fa fa-eye"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                              <div class="form-group">
                            <label for="profile_picture">Profile Picture:</label>
                            <input type="file" class="form-control-file" id="profile_picture" name="profile_picture">
                        </div>
                        <?php if (!empty($profile_picture)): ?>
                            <img src="<?php echo htmlspecialchars(UPLOADS_URL . basename($profile_picture)); ?>" alt="Current Profile Picture" class="mb-3" style="max-width: 200px;">
                        <?php endif; ?>
                            <div>
                                <button type="submit" class="btn btn-primary">Update Profile</button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <div class="footer">
        <p>Contact number | Email | Copyright</p>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($update_successful): ?>
            Swal.fire({
                title: 'Success!',
                text: 'Your profile has been updated successfully.',
                icon: 'success',
                confirmButtonText: 'OK'
            });
            <?php endif; ?>

            <?php if (!empty($error_message)): ?>
            Swal.fire({
                title: 'Error!',
                text: '<?php echo implode(" ", $error_message); ?>',
                icon: 'error',
                confirmButtonText: 'OK'
            });
            <?php endif; ?>

            function togglePasswordVisibility(inputId, toggleId) {
                const input = document.getElementById(inputId);
                const toggle = document.getElementById(toggleId);
                
                toggle.addEventListener('click', function (e) {
                    e.preventDefault();
                    const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
                    input.setAttribute('type', type);
                    this.querySelector('i').classList.toggle('fa-eye');
                    this.querySelector('i').classList.toggle('fa-eye-slash');
                });
            }

            togglePasswordVisibility('password', 'togglePassword');
            togglePasswordVisibility('confirm_password', 'toggleConfirmPassword');

            document.getElementById('updateProfileForm').addEventListener('submit', function(e) {
                var password = document.getElementById('password').value;
                var confirmPassword = document.getElementById('confirm_password').value;

                if (password !== confirmPassword) {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Error!',
                        text: 'Passwords do not match.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
            });
        });
    </script>
</body>
</html>