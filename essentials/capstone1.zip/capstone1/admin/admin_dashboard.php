<!-- admin_dashboard -->



<?php
session_start();
include '../db.php'; // Ensure database connection is established
// Ensure the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}
// Get the admin's ID from the session
$admin_id = $_SESSION['user_id'];
// Fetch the admin's details from the database
$stmt = $connection->prepare("SELECT name, profile_picture FROM tbl_admin WHERE id = ?");
if ($stmt === false) {
    die("Prepare failed: " . $connection->error); // Output the error message
}
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $admin = $result->fetch_assoc();
    $name = $admin['name'];
    $profile_picture = $admin['profile_picture'];
} else {
    die("Admin not found.");
}

// Fetch user counts for each table
$user_tables = ['tbl_counselor', 'tbl_facilitator', 'tbl_adviser', 'tbl_instructor', 'tbl_dean', 'tbl_student', 'tbl_guard'];
$user_counts = [];

foreach ($user_tables as $table) {
    $count_query = "SELECT COUNT(*) as count FROM $table";
    $count_result = mysqli_query($connection, $count_query);
    if ($count_result) {
        $count_row = mysqli_fetch_assoc($count_result);
        $user_counts[$table] = $count_row['count'];
    } else {
        $user_counts[$table] = 0;
    }
}

mysqli_close($connection);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="admin_styles.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="header">
        CAVITE STATE UNIVERSITY-MAIN
    </div>
    <?php include 'admin_sidebar.php'; ?> <!-- Include sidebar with admin-specific links -->
    <main class="main-content">
    <div class="header1">
            <br><br>
            <h1>Welcome, <?php echo htmlspecialchars($name); ?>!</h1>
        </div>
        
        <div class="dashboard-container">
    <h2 class="dashboard-title mb-4">Admin Dashboard</h2>
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h3 class="card-title mb-0">User Analytics</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-striped">
                            <thead class="thead-dark">
                                <tr>
                                    <th>User Type</th>
                                    <th>Count</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($user_counts as $table => $count): ?>
                                    <tr>
                                        <td><?php echo ucwords(str_replace('tbl_', '', $table)); ?></td>
                                        <td><span><?php echo $count; ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h3 class="card-title mb-0">User Distribution</h3>
                </div>
                <div class="card-body">
                    <canvas id="userChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>
    <div class="footer">
        <p>Contact number | Email | Copyright</p>
    </div>

    <script>
        var ctx = document.getElementById('userChart').getContext('2d');
var userChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_map(function($table) { return ucwords(str_replace('tbl_', '', $table)); }, array_keys($user_counts))); ?>,
        datasets: [{
            label: 'Number of Users',
            data: <?php echo json_encode(array_values($user_counts)); ?>,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(199, 199, 199, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(199, 199, 199, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1,
                    callback: function(value) {
                        if (Math.floor(value) === value) {
                            return value;
                        }
                    }
                }
            }
        },
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'CEIT User Distribution'
            }
        }
    }
});
    </script>
</body>
</html>