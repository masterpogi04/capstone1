<?php
session_start();
include '../db.php';

// Check if the user is logged in as a guard
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'guard') {
    header("Location: login.php");
    exit();
}

$guard_id = $_SESSION['user_id'];

// Fetch guard's name
$stmt = $connection->prepare("SELECT name FROM tbl_guard WHERE id = ?");
$stmt->bind_param("i", $guard_id);
$stmt->execute();
$result = $stmt->get_result();
$guard = $result->fetch_assoc();
$guard_name = $guard['name'];
$reportedByType = $_SESSION['user_type'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date_reported = date('Y-m-d H:i:s');
    $place = $_POST['place'];
    $description = $_POST['description'];
    $reported_by = $guard_name;
    
    // Handle file upload
    $file_path = null;
    if (isset($_FILES['fileUpload']) && $_FILES['fileUpload']['error'] == 0) {
        $upload_dir = '../../uploads/incident_reports_proof/';
        $file_name = uniqid() . '_' . $_FILES['fileUpload']['name'];
        $file_path = $upload_dir . $file_name;
        
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        if (move_uploaded_file($_FILES['fileUpload']['tmp_name'], $file_path)) {
            $file_path = '../../uploads/incident_reports_proof/' . $file_name;
        } else {
            $error_message = "Failed to upload file.";
        }
    }
    
    // Insert into pending_incident_reports table
    $stmt = $connection->prepare("INSERT INTO pending_incident_reports (guard_id, date_reported, place, description, reported_by, reported_by_type, file_path) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssss", $guard_id, $date_reported, $place, $description, $reported_by, $reportedByType, $file_path);
    
    if ($stmt->execute()) {
        $pending_report_id = $stmt->insert_id;
        
        // Insert involved students
        $stmt_student = $connection->prepare("INSERT INTO pending_student_violations (pending_report_id, student_id, student_name) VALUES (?, ?, ?)");
        foreach ($_POST['personsInvolvedId'] as $index => $studentId) {
            $studentName = $_POST['personsInvolved'][$index];
            // If student ID is provided, use it, otherwise set to NULL
            $studentIdToInsert = !empty($studentId) ? $studentId : null;
            $stmt_student->bind_param("iss", $pending_report_id, $studentIdToInsert, $studentName);
            $stmt_student->execute();
        }
        
        // Insert witnesses
        $stmt_witness = $connection->prepare("INSERT INTO pending_incident_witnesses (pending_report_id, witness_type, witness_id, witness_name) VALUES (?, ?, ?, ?)");
        foreach ($_POST['witnessType'] as $index => $witnessType) {
            $witnessId = ($witnessType === 'student') ? $_POST['witnessId'][$index] : null;
            $witnessName = $_POST['witnesses'][$index];
            $stmt_witness->bind_param("isss", $pending_report_id, $witnessType, $witnessId, $witnessName);
            $stmt_witness->execute();
        }
        
        $_SESSION['report_submitted'] = true;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        $_SESSION['report_error'] = true;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incident Report Submission - Guard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #FAF3E0;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #F4A261;
            color: Black;
            padding: 20px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }
        .container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            margin-top: 30px;
            margin-bottom: 30px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        h2 {
            color: #1A6E47;
            border-bottom: 2px solid #1A6E47;
            padding-bottom: 10px;
            margin-bottom: 30px;
        }
        .form-group label {
            color: #1A6E47;
            font-weight: bold;
        }
        .form-control {
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #1A6E47;
            border-color: #1A6E47;
            padding: 10px 20px;
        }
        .btn-primary:hover {
            background-color: #145A3A;
            border-color: #145A3A;
        }
        .btn-secondary {
            background-color: #F4A261;
            border-color: #F4A261;
            color: #fff;
            padding: 10px 20px;
        }
        .btn-secondary:hover {
            background-color: #E76F51;
            border-color: #E76F51;
        }
        .person-involved-entry, .witness-entry {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        .btn-sm {
            font-size: 0.8rem;
            padding: 0.25rem 0.5rem;
        }
        .alert {
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">INCIDENT REPORT FORM - GUARD</h2>
        <a href="guard_homepage.php" class="btn btn-secondary mb-4">
            <i class="fas fa-arrow-left"></i> Back to Homepage
        </a>

        <form id="incidentReportForm" method="POST" enctype="multipart/form-data">
            <!-- Place of Incident -->
            <div class="form-group">
                <label for="incidentPlace"><i class="fas fa-map-marker-alt"></i> Place of Incident:</label>
                <input type="text" class="form-control" id="incidentPlace" name="incidentPlace" required>
            </div>

            
            <div class="form-group">
                <label for="incidentDate"><i class="far fa-calendar-alt"></i> Date of Incident:</label>
                <input type="date" class="form-control" id="incidentDate" name="incidentDate" required>
            </div>

            
            <div class="form-group">
                <label for="incidentTime"><i class="far fa-clock"></i> Time of Incident:</label>
                <input type="time" class="form-control" id="incidentTime" name="incidentTime" required>
            </div>

            
            <div class="form-group">
                <label for="place"><i class="fas fa-info-circle"></i> Place, Date & Time of Incident:</label>
                <input type="text" class="form-control" id="place" name="place" readonly>
            </div>


            <div class="form-group">
                <label><i class="fas fa-users"></i> Person/s Involved:</label>
                <div id="personsInvolvedContainer">
                    <div class="person-involved-entry">
                        <input type="text" class="form-control mb-2 student-id" name="personsInvolvedId[]" placeholder="Student ID (Optional)">
                        <input type="text" class="form-control mb-2" name="personsInvolved[]" placeholder="Name" required>
                    </div>
                </div>
                <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="addPersonInvolved()">
                    <i class="fas fa-plus"></i> Add Person
                </button>
            </div>
            <div class="form-group">
                <label><i class="fas fa-eye"></i> Witness/es:</label>
                <div id="witnessesContainer">
                    <div class="witness-entry">
                        <select class="form-control mb-2" name="witnessType[]" required>
                            <option value="">Select Witness Type</option>
                            <option value="student">Student</option>
                            <option value="staff">Staff</option>
                        </select>
                        <input type="text" class="form-control mb-2" name="witnessId[]" placeholder="Student ID (if student)">
                        <input type="text" class="form-control mb-2" name="witnesses[]" placeholder="Name" required>
                    </div>
                </div>
                <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="addWitnessField()">
                    <i class="fas fa-plus"></i> Add Witness
                </button>
            </div>

            <div class="form-group">
                <label for="description"><i class="fas fa-file-alt"></i> Brief Description of the Incident/Offense:</label>
                <textarea class="form-control" id="description" name="description" rows="5" required></textarea>
            </div>

            <div class="form-group">
                <label for="reportedBy"><i class="fas fa-user"></i> Reported by:</label>
                <input type="text" class="form-control" id="reportedBy" name="reportedBy" value="<?php echo htmlspecialchars($guard_name); ?>" readonly>
            </div>

            <div class="form-group">
                <label for="fileUpload"><i class="fas fa-file-upload"></i> Upload File or Picture:</label>
                <input type="file" class="form-control-file" id="fileUpload" name="fileUpload" accept="image/*,.pdf,.doc,.docx">
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-paper-plane"></i> Submit Report
                </button>
            </div>
        </form>
    </div>

<script>
$(document).ready(function() {
    // Check for success message from PHP session
    <?php if (isset($_SESSION['report_submitted']) && $_SESSION['report_submitted']): ?>
        Swal.fire({
            title: 'Success!',
            text: 'Incident report has been submitted successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
        }).then(() => {
            <?php unset($_SESSION['report_submitted']); ?>
        });
    <?php endif; ?>

    // Set max date to today
    const today = new Date().toISOString().split('T')[0];
    $('#incidentDate').attr('max', today);

    // Initial time restrictions
    updateTimeRestrictions();

    // Update time restrictions when date changes
    $('#incidentDate').on('change', function() {
        updateTimeRestrictions();
        // Reset time when date changes
        $('#incidentTime').val('');
    });

    // Time input handler
    $('#incidentTime').on('input', function() {
        const selectedDate = $('#incidentDate').val();
        const selectedTime = $(this).val();
        
        if (selectedDate === today) {
            const now = new Date();
            const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
            
            if (selectedTime > currentTime) {
                $(this).val('');
                Swal.fire({
                    title: 'Invalid Time',
                    text: 'You cannot select a future time for today\'s date.',
                    icon: 'warning',
                    confirmButtonText: 'OK'
                });
            }
        }
        updateCombinedField();
    });

    // Update combined field when any relevant input changes
    $('#incidentPlace, #incidentDate, #incidentTime').on('change', function() {
        updateCombinedField();
    });

    // Form submission handling
    $('#incidentReportForm').on('submit', async function(e) {
        e.preventDefault();

        const studentIds = [];
        let hasValidStudent = false;

        $('input[name="personsInvolvedId[]"]').each(function() {
            if ($(this).val()) {
                studentIds.push($(this).val());
            }
        });

        if (studentIds.length > 0) {
            for (const studentId of studentIds) {
                const isValid = await validateStudentId(studentId);
                if (isValid) {
                    hasValidStudent = true;
                }
            }
        } else {
            hasValidStudent = true;
        }

        if (!hasValidStudent) {
            Swal.fire({
                title: 'Error',
                text: 'At least one CEIT Student must be involved to submit this report.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
            return;
        }

        Swal.fire({
            title: 'Confirm Submission',
            text: 'Are you sure you want to submit this incident report?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, submit it!'
        }).then((result) => {
            if (result.isConfirmed) {
                const formData = new FormData(this);
                
                $.ajax({
                    url: $(this).attr('action'),
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        try {
                            const result = JSON.parse(response);
                            if (result.success) {
                                Swal.fire({
                                    title: 'Success!',
                                    text: 'Incident report has been submitted successfully.',
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                }).then(() => {
                                    window.location.reload();
                                });
                            } else {
                                Swal.fire({
                                    title: 'Error',
                                    text: result.message || 'An error occurred while submitting the report.',
                                    icon: 'error',
                                    confirmButtonText: 'OK'
                                });
                            }
                        } catch (e) {
                            window.location.reload(); // Fallback for non-JSON responses
                        }
                    },
                    error: function() {
                        Swal.fire({
                            title: 'Error',
                            text: 'An error occurred while submitting the report.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            }
        });
    });
});

function updateTimeRestrictions() {
    const dateInput = document.getElementById('incidentDate');
    const timeInput = document.getElementById('incidentTime');
    const selectedDate = dateInput.value;
    const now = new Date();
    const today = now.toISOString().split('T')[0];

    // If selected date is today, restrict time input
    if (selectedDate === today) {
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        timeInput.setAttribute('max', `${hours}:${minutes}`);
        
        // If current time selection is later than current time, reset it
        if (timeInput.value > `${hours}:${minutes}`) {
            timeInput.value = '';
        }
    } else {
        timeInput.removeAttribute('max');
    }
}

function updateCombinedField() {
    const place = $('#incidentPlace').val();
    const date = $('#incidentDate').val();
    const time = $('#incidentTime').val();
    
    if (place && date && time) {
        const selectedDate = new Date(date + 'T' + time);
        const formattedDate = selectedDate.toLocaleString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            hour12: true
        });
        $('#place').val(`${place} - ${formattedDate}`);
    }
}

function validateStudentId(studentId) {
    return new Promise((resolve) => {
        if (!studentId) {
            resolve(true);
            return;
        }

        $.ajax({
            url: 'check_student.php',
            method: 'POST',
            data: { student_id: studentId },
            success: function(response) {
                try {
                    const result = JSON.parse(response);
                    if (!result.exists) {
                        Swal.fire({
                            title: 'Student Not Found',
                            text: 'This student is not part of the CEIT Population. Kindly submit it manually.',
                            icon: 'warning',
                            confirmButtonText: 'OK'
                        });
                    }
                    resolve(result.exists);
                } catch (e) {
                    resolve(false);
                }
            },
            error: function() {
                resolve(false);
            }
        });
    });
}

function addPersonInvolved() {
    var container = document.getElementById('personsInvolvedContainer');
    var div = document.createElement('div');
    div.className = 'person-involved-entry';
    div.innerHTML = `
        <input type="text" class="form-control mb-2" name="personsInvolvedId[]" placeholder="Student ID" required>
        <input type="text" class="form-control mb-2" name="personsInvolved[]" placeholder="Name" required>
        <button type="button" class="btn btn-danger btn-sm mt-2" onclick="removeEntry(this)">
            <i class="fas fa-trash"></i> Remove
        </button>
    `;
    container.appendChild(div);
}

function addWitnessField() {
    var container = document.getElementById('witnessesContainer');
    var div = document.createElement('div');
    div.className = 'witness-entry';
    div.innerHTML = `
        <select class="form-control mb-2" name="witnessType[]" required>
            <option value="">Select Witness Type</option>
            <option value="student">Student</option>
            <option value="staff">Staff</option>
        </select>
        <input type="text" class="form-control mb-2" name="witnessId[]" placeholder="Student ID (if student)">
        <input type="text" class="form-control mb-2" name="witnesses[]" placeholder="Name" required>
        <button type="button" class="btn btn-danger btn-sm mt-2" onclick="removeEntry(this)">
            <i class="fas fa-trash"></i> Remove
        </button>
    `;
    container.appendChild(div);
}

function removeEntry(button) {
    button.closest('.person-involved-entry, .witness-entry').remove();
}
</script>
</body>
</html>